# PROJECT STRUCTURE — AI Hub Arabia

```text
ai-hub-arabia/
├── public/
│   ├── icons/
│   │   └── brand-mark.svg
│   ├── manifest.webmanifest
│   ├── offline.html
│   ├── robots.txt
│   ├── sitemap.xml
│   └── sw.js
├── scripts/
│   ├── phase10-quality-check.mjs
│   ├── phase10-route-smoke.mjs
│   ├── phase11-completion-check.mjs
│   ├── phase12-production-readiness.mjs
│   └── phase13-final-review.mjs
├── src/
│   ├── assets/brand/
│   ├── components/
│   │   ├── auth/
│   │   ├── common/
│   │   ├── domain/
│   │   ├── feedback/
│   │   ├── layout/
│   │   ├── system/
│   │   └── ui/
│   ├── config/
│   ├── constants/
│   ├── contexts/
│   ├── data/
│   ├── hooks/
│   ├── layouts/
│   ├── pages/
│   ├── routes/
│   ├── services/
│   │   └── repositories/
│   ├── styles/
│   ├── types/
│   └── utils/
├── CHANGELOG.md
├── DEPLOYMENT.md
├── INSTALL.md
├── PHASE_13_FINAL_REPORT.md
├── PROJECT_STRUCTURE.md
├── README.md
├── index.html
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── vite.config.ts
```

## Architecture Notes

- `src/pages` contains route-level screens and uses lazy loading through `src/routes/AppRoutes.tsx`.
- `src/layouts` contains public, auth, user dashboard, and admin shell layouts.
- `src/components/ui` contains reusable primitive UI components.
- `src/components/domain` contains AI-tool-specific components.
- `src/services` contains business logic and data operations.
- `src/services/repositories` isolates catalog/user persistence access patterns.
- `src/contexts` manages auth, theme, and locale state.
- `src/data/seedDatabase.ts` seeds the local demo database.
- `src/constants/catalogSeed.ts` contains the AI tools and categories baseline library.
- `public/sw.js`, `manifest.webmanifest`, `sitemap.xml`, and `robots.txt` support PWA and SEO.

## Data Layer

The current data layer is a localStorage adapter identified as `ai-hub-arabia-database-v13`, with migration support for earlier local versions. The service contracts are structured so a real backend can replace local storage with minimal UI changes.

## Testing and Review Scripts

- `test:phase10` checks UX/accessibility/performance essentials.
- `test:phase11` checks completion pages and workspace/admin additions.
- `test:phase12` checks production readiness.
- `test:phase13` checks final delivery completeness.
- `test:routes` starts a preview server and verifies key app routes return the SPA shell.
