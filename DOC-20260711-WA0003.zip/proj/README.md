# AI Hub Arabia 🌟

**منصة اكتشاف أدوات الذكاء الاصطناعي العربية**  
The Arabic AI Tools Discovery Platform

[![Version](https://img.shields.io/badge/version-1.1.0-blue)](package.json)
[![Phase](https://img.shields.io/badge/phase-15%20Final-green)](PHASE_15_FINAL_REPORT.md)
[![Status](https://img.shields.io/badge/status-production--ready-brightgreen)](#)
[![TypeScript](https://img.shields.io/badge/TypeScript-strict-blue)](tsconfig.app.json)
[![Firebase](https://img.shields.io/badge/Firebase-11.x-orange)](#)

---

## نبذة عن المشروع

AI Hub Arabia هي منصة رقمية ثنائية اللغة (عربي/إنجليزي) تُمكِّن المستخدمين العرب والعالميين من:

- 🔍 **اكتشاف** أدوات الذكاء الاصطناعي عبر 14 تصنيفًا و60 أداة حقيقية
- ⚖️ **مقارنة** الأدوات جنبًا إلى جنب لاتخاذ قرارات مستنيرة
- ❤️ **حفظ** الأدوات المفضَّلة وإدارة قوائم مخصَّصة
- ⭐ **تقييم** الأدوات وقراءة مراجعات المجتمع
- 🔎 **البحث المتقدَّم** مع فلاتر متعددة المعايير

---

## المميزات التقنية

| الميزة | التفاصيل |
|--------|---------|
| **الإطار** | React 18 + TypeScript Strict + Vite 8 |
| **التصميم** | Tailwind CSS 3 + RTL/LTR + Dark/Light Mode |
| **المصادقة** | Firebase Auth (Prod) / localStorage (Dev) |
| **قاعدة البيانات** | Firestore (Prod) / localStorage (Dev) |
| **التخزين** | Firebase Storage للصور |
| **الأداء** | Lazy Routes + Code Splitting + PWA |
| **SEO** | OG Tags + JSON-LD + Sitemap + Robots |
| **الأمان** | CSP + Security Rules + Audit Log |

---

## المتطلبات

- **Node.js** 20 أو أحدث
- **npm** 10+ (مُرفق مع Node 20)
- **Firebase Project** (للإنتاج فقط — التطوير يعمل بدون Firebase)

---

## التثبيت السريع

```bash
# 1. استنساخ أو فك ضغط المشروع
# 2. تثبيت التبعيات
npm install

# 3. إعداد متغيرات البيئة (للتطوير بدون Firebase)
cp .env.example .env
# الإعداد الافتراضي VITE_USE_FIREBASE=false يعمل فورًا

# 4. تشغيل بيئة التطوير
npm run dev
# → http://localhost:5173
```

---

## التشغيل مع Firebase (الإنتاج)

```bash
# 1. أنشئ مشروع Firebase على https://console.firebase.google.com
# 2. عدِّل ملف .env بإعداداتك:
VITE_USE_FIREBASE=true
VITE_FIREBASE_API_KEY=AIzaSy...
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abc

# 3. ارفع قواعد الأمان
npm install -g firebase-tools
firebase login
firebase deploy --only firestore:rules,storage,firestore:indexes

# 4. ابنِ وانشر
npm run build
firebase deploy --only hosting
```

### بذر قاعدة البيانات بالأدوات الـ 60 (Seed Firestore)

بعد إعداد Firebase، ارفع كتالوج الأدوات الـ 60 الحقيقي والتصنيفات الـ 14 دفعة واحدة إلى Firestore:

```bash
# 1. Firebase Console → Project Settings → Service accounts → Generate new private key
#    احفظ الملف باسم serviceAccountKey.json في جذر المشروع (مُستثنى من Git تلقائيًا)

# 2. شغّل سكربت البذر
npm run seed:firestore
```

السكربت (`scripts/seed-firestore.ts`) يقرأ البيانات مباشرة من `src/constants/catalogSeed.ts` (نفس مصدر الحقيقة
المستخدَم في وضع localStorage)، يحسب `toolsCount` الحقيقي لكل تصنيف تلقائيًا، ويستخدم batched writes آمنة.
تشغيله عدة مرات آمن (idempotent) — يُحدِّث نفس السجلات دون تكرارها.

---

## أوامر npm

| الأمر | الوظيفة |
|-------|---------|
| `npm run dev` | بيئة التطوير المحلية |
| `npm run build` | بناء الإنتاج |
| `npm run preview` | معاينة بناء الإنتاج |
| `npm run typecheck` | فحص TypeScript |
| `npm run test:phase15` | الفحص النهائي الشامل |
| `npm run test:all` | جميع الفحوصات بالتسلسل |
| `npm run seed:firestore` | رفع 60 أداة + 14 تصنيف إلى Firestore |
| `npm run firebase:deploy` | نشر كامل على Firebase |
| `npm run firebase:deploy:rules` | رفع قواعد الأمان فقط |
| `npm run firebase:emulators` | تشغيل Firebase محليًا |

---

## بنية المشروع

```
ai-hub-arabia/
├── src/
│   ├── components/          # مكونات UI قابلة لإعادة الاستخدام
│   │   ├── ui/             # Button, Input, Modal, Toast, Card, Badge...
│   │   ├── layout/         # Navbar, Sidebar, Footer
│   │   ├── domain/         # ToolCard, CategoryCard, CompareCard...
│   │   ├── auth/           # ProtectedRoute, PublicOnlyRoute
│   │   └── feedback/       # EmptyState, ErrorState
│   ├── pages/              # 29 صفحة كاملة
│   ├── contexts/           # AuthContext, ToastContext, ThemeContext...
│   ├── services/           # Business logic + Repository pattern
│   ├── firebase/           # Firebase adapters (Auth, Firestore, Storage)
│   ├── hooks/              # Custom hooks
│   ├── utils/              # Security, validation, helpers
│   ├── types/              # TypeScript type definitions
│   ├── config/             # Production readiness, seed data
│   └── routes/             # AppRoutes
├── public/                 # Static assets (manifest, sw.js, sitemap...)
├── scripts/                # Quality check scripts (phases 10-15)
├── firestore.rules         # Firestore security rules
├── storage.rules           # Firebase Storage security rules
├── firebase.json           # Firebase Hosting config
├── firestore.indexes.json  # Firestore composite indexes
├── .env.example            # Environment variables template
└── PHASE_15_FINAL_REPORT.md # Final project report
```

---

## وضعا التشغيل

### وضع التطوير (localStorage)
```
VITE_USE_FIREBASE=false   ← الافتراضي
```
يعمل فورًا بدون أي إعداد خارجي. البيانات تُخزَّن في متصفحك.

### وضع الإنتاج (Firebase)
```
VITE_USE_FIREBASE=true
VITE_FIREBASE_API_KEY=...
```
يتصل بـ Firebase Auth + Firestore + Storage.  
**لا تعديل على الكود** — نمط المحوِّل يُدير التبديل تلقائيًا.

---

## حساب المشرف (التطوير)

```
البريد: admin@aihubarabia.com
كلمة المرور: Admin@2026!
```
> ⚠️ غيِّر هذه البيانات في الإنتاج وأنشئ حساب مشرف عبر Firebase Console.

---

## التوثيق

| الملف | الوصف |
|-------|-------|
| [INSTALL.md](INSTALL.md) | تعليمات التثبيت التفصيلية |
| [DEPLOYMENT.md](DEPLOYMENT.md) | دليل النشر على Firebase وغيره |
| [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) | شرح بنية المشروع |
| [CHANGELOG.md](CHANGELOG.md) | سجل التغييرات لكل المراحل |
| [PHASE_15_FINAL_REPORT.md](PHASE_15_FINAL_REPORT.md) | التقرير النهائي |

---

## الترخيص

هذا المشروع مُعَدٌّ للاستخدام الخاص. جميع الحقوق محفوظة.

---

*بُنيت بـ ❤️ لمجتمع الذكاء الاصطناعي العربي — Phase 15 Final Release*
