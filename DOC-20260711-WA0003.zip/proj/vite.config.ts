import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

// ══════════════════════════════════════════════════════════════════════════════
// Vite Configuration — AI Hub Arabia
// Phase 14: Real Services Integration
// ══════════════════════════════════════════════════════════════════════════════

// CSP مُحدَّث ليشمل نطاقات Firebase
const FIREBASE_CSP_CONNECT = [
  'https://*.googleapis.com',
  'https://*.firebaseio.com',
  'https://*.cloudfunctions.net',
  'wss://*.firebaseio.com',
  'https://securetoken.googleapis.com',
  'https://identitytoolkit.googleapis.com',
  'https://*.firebaseapp.com',
  'https://firestore.googleapis.com',
].join(' ');

const FIREBASE_CSP_IMG = [
  'https://firebasestorage.googleapis.com',
  'https://lh3.googleusercontent.com',
].join(' ');

const CSP_HEADER = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline'",
  `style-src 'self' 'unsafe-inline' https://fonts.googleapis.com`,
  `font-src 'self' https://fonts.gstatic.com`,
  `img-src 'self' data: blob: https: ${FIREBASE_CSP_IMG}`,
  `connect-src 'self' ${FIREBASE_CSP_CONNECT}`,
  "frame-src 'none'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join('; ');

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 5173,
    host: true,
    strictPort: true,
  },
  preview: {
    port: 4173,
    host: true,
    strictPort: true,
    headers: {
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'SAMEORIGIN',
      'X-XSS-Protection': '1; mode=block',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
      'Content-Security-Policy': CSP_HEADER,
    },
  },
  build: {
    target: 'es2020',
    sourcemap: false,
    chunkSizeWarningLimit: 700,
    cssCodeSplit: true,
    reportCompressedSize: true,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (
            id.includes('node_modules/react') ||
            id.includes('node_modules/react-dom') ||
            id.includes('node_modules/react-router-dom')
          )
            return 'react';
          if (id.includes('node_modules/lucide-react')) return 'icons';
          if (
            id.includes('node_modules/firebase/app') ||
            id.includes('node_modules/firebase/auth') ||
            id.includes('node_modules/firebase/firestore') ||
            id.includes('node_modules/firebase/storage') ||
            id.includes('node_modules/@firebase')
          )
            return 'firebase';
          if (id.includes('/src/pages/Admin')) return 'admin';
          return undefined;
        },
      },
    },
  },
});
