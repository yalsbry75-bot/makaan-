# Changelog — AI Hub Arabia

جميع التغييرات الجوهرية مُوثَّقة في هذا الملف وفق [Keep a Changelog](https://keepachangelog.com/ar/1.0.0/).

---

## [1.1.0] — 2026-07-09 — Phase 15: Final Production Release

### مضاف (Added)
- صفحة سياسة خصوصية شاملة ثنائية اللغة (عربي/إنجليزي) مع 10 أقسام قانونية كاملة
- صفحة شروط الاستخدام شاملة ثنائية اللغة مع 11 بندًا قانونيًا كاملًا
- `scripts/phase15-final-check.mjs` — سكربت الفحص النهائي الشامل (80+ فحص)
- `PHASE_15_FINAL_REPORT.md` — التقرير النهائي الرسمي للمشروع كاملًا
- تحديث `src/config/production.ts` للمرحلة 15 مع `totalFeatures: 156` و`totalPages: 29`

### مُعدَّل (Changed)
- `src/pages/PrivacyPage.tsx` — محتوى قانوني حقيقي بدلًا من النص التجريبي
- `src/pages/TermsPage.tsx` — محتوى قانوني حقيقي بدلًا من النص التجريبي
- `package.json` — إضافة سكربت `test:phase15`

---

## [1.1.0-rc.1] — 2026-07-09 — Phase 14: Firebase Production Integration

### مضاف (Added)
- `src/firebase/config.ts` — تهيئة Firebase App (Singleton) مع فحص متغيرات البيئة
- `src/firebase/auth.ts` — Firebase Authentication Adapter
- `src/firebase/db.ts` — Firestore Database Adapter
- `src/firebase/storage.ts` — Firebase Storage Adapter
- `src/firebase/index.ts` — Barrel export
- `firestore.rules` — قواعد أمان Firestore لـ 11 Collection
- `storage.rules` — قواعد أمان Firebase Storage
- `firebase.json` — إعدادات Firebase Hosting مع Security Headers وCSP
- `firestore.indexes.json` — 15 فهرس مُركَّب
- `.firebaserc` — إعداد مشروع Firebase
- `.env.example` — توثيق كامل لمتغيرات البيئة
- `scripts/phase14-production-check.mjs` — فحص Phase 14
- `PHASE_14_REPORT.md` — تقرير Phase 14

### مُعدَّل (Changed)
- `src/services/databaseService.ts` — إضافة Firestore adapter بنمط المحوِّل
- `src/services/authService.ts` — إضافة Firebase Auth adapter
- `src/contexts/AuthContext.tsx` — إضافة `onAuthStateChanged` listener مع cleanup صحيح
- `src/vite-env.d.ts` — أنواع TypeScript لمتغيرات البيئة
- `vite.config.ts` — CSP لنطاقات Firebase + Firebase code chunk
- `package.json` — إضافة Firebase SDK `^11.10.0`

---

## [1.0.0] — 2026-07-08 — Phase 13: Final Review

### مضاف (Added)
- مراجعة شاملة لكل المكونات والصفحات والخدمات
- `scripts/phase13-final-review.mjs` — سكربت مراجعة Phase 13
- `PHASE_13_FINAL_REPORT.md` — تقرير مراجعة شاملة

---

## [0.13.0] — Phase 12: Production Readiness

### مضاف (Added)
- تحسينات الإنتاج: SEO، PWA، أمان، أداء
- `public/sw.js` — Service Worker مع offline shell
- `public/offline.html` — صفحة خطأ offline
- Security Headers في vite.config.ts
- `scripts/phase12-production-readiness.mjs`

---

## [0.12.0] — Phase 11: Admin Panel Complete

### مضاف (Added)
- لوحة إدارة كاملة (AdminDashboardPage, AdminToolsPage, AdminUsersPage, AdminReviewsPage, AdminMessagesPage, AdminStatsPage, AdminSettingsPage, AdminSystemPage)
- نظام صلاحيات متدرِّج (user, moderator, admin)
- `scripts/phase11-completion-check.mjs`

---

## [0.11.0] — Phase 10: Quality Assurance

### مضاف (Added)
- فحوصات جودة شاملة
- `scripts/phase10-quality-check.mjs`
- `scripts/phase10-route-smoke.mjs`

---

## [0.10.0] — Phase 9: User Dashboard

### مضاف (Added)
- لوحة تحكم المستخدم الكاملة
- صفحات: UserDashboardPage, UserComparisonsPage, UserReviewsPage
- نظام تفضيلات المستخدم

---

## [0.9.0] — Phase 8: Features

### مضاف (Added)
- نظام المقارنة جنبًا إلى جنب
- نظام المفضلة
- نظام التقييمات والمراجعات

---

## [0.8.0] — Phase 7: Search

### مضاف (Added)
- البحث المتقدَّم مع فلترة متعددة المعايير
- SearchPage + SearchResultsPage

---

## [0.7.0] — Phase 6: Tools & Categories

### مضاف (Added)
- صفحة الأدوات مع فلترة وترتيب
- صفحة تفاصيل الأداة
- صفحة التصنيفات
- بيانات 60 أداة AI حقيقية

---

## [0.6.0] — Phase 5: Authentication

### مضاف (Added)
- نظام المصادقة الكامل (تسجيل، دخول، خروج، استعادة كلمة المرور)
- ProtectedRoute و PublicOnlyRoute
- AuthContext و authService

---

## [0.5.0] — Phase 4: Core Infrastructure

### مضاف (Added)
- databaseService مع localStorage
- نظام Repositories
- Audit Log ونظام الأمان

---

## [0.4.0] — Phase 3: UI Components

### مضاف (Added)
- مكتبة مكونات UI شاملة (Button, Input, Modal, Toast, Card, Badge, إلخ)
- دعم RTL/LTR ثنائي الاتجاه
- دعم Dark/Light Mode

---

## [0.3.0] — Phase 2: Layout

### مضاف (Added)
- Navbar مع البحث وقائمة المستخدم
- Sidebar للتنقل
- Footer شامل
- تخطيطات: MainLayout, DashboardLayout, AdminLayout, AuthLayout

---

## [0.2.0] — Phase 1: Foundation

### مضاف (Added)
- البنية الأساسية للمشروع (React + Vite + TypeScript + Tailwind)
- التوجيه بـ React Router
- نظام الـ Locale (عربي/إنجليزي)
- نظام الثيم (فاتح/مظلم)
