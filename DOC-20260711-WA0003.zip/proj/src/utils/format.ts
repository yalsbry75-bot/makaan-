import type { Locale, Pricing } from '@/types';

export function formatRating(rating: number, locale: Locale) {
  return new Intl.NumberFormat(locale === 'ar' ? 'ar-SA' : 'en-US', {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  }).format(rating);
}

export function pricingLabel(pricing: Pricing | string, locale: Locale) {
  const labels: Record<string, { ar: string; en: string }> = {
    free: { ar: 'مجاني', en: 'Free' },
    freemium: { ar: 'مجاني جزئيًا', en: 'Freemium' },
    paid: { ar: 'مدفوع', en: 'Paid' },
    enterprise: { ar: 'للشركات', en: 'Enterprise' },
  };

  return labels[pricing]?.[locale] ?? pricing;
}

export function categoryName(slug: string, locale: Locale) {
  const names: Record<string, { ar: string; en: string }> = {
    writing: { ar: 'كتابة المحتوى', en: 'Content Writing' },
    design: { ar: 'التصميم والصور', en: 'Design & Images' },
    images: { ar: 'تصميم الصور', en: 'Image Design' },
    video: { ar: 'الفيديو', en: 'Video' },
    coding: { ar: 'البرمجة', en: 'Coding' },
    marketing: { ar: 'التسويق', en: 'Marketing' },
    education: { ar: 'التعليم', en: 'Education' },
    audio: { ar: 'الصوت', en: 'Audio' },
    translation: { ar: 'الترجمة', en: 'Translation' },
    productivity: { ar: 'الإنتاجية', en: 'Productivity' },
    business: { ar: 'الأعمال', en: 'Business' },
    data: { ar: 'تحليل البيانات', en: 'Data Analysis' },
    research: { ar: 'البحث العلمي', en: 'Research' },
    automation: { ar: 'الأتمتة', en: 'Automation' },
    security: { ar: 'الأمن والامتثال', en: 'Security & Compliance' },
  };

  return names[slug]?.[locale] ?? slug;
}

export function localizeNumber(value: number | string, locale: Locale) {
  const numeric = Number(value);
  if (Number.isNaN(numeric)) return String(value);
  return new Intl.NumberFormat(locale === 'ar' ? 'ar-SA' : 'en-US').format(numeric);
}
