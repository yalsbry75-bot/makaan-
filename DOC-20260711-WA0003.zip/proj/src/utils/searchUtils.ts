export function normalizeSearchText(value: string) {
  return value
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[^a-z0-9\u0600-\u06FF]+/g, ' ')
    .trim();
}

export function editDistance(a: string, b: string) {
  const source = normalizeSearchText(a);
  const target = normalizeSearchText(b);
  if (source === target) return 0;
  if (!source.length) return target.length;
  if (!target.length) return source.length;
  const previous = Array.from({ length: target.length + 1 }, (_, index) => index);
  for (let i = 1; i <= source.length; i += 1) {
    let diagonal = previous[0];
    previous[0] = i;
    for (let j = 1; j <= target.length; j += 1) {
      const temp = previous[j];
      const substitution = diagonal + (source[i - 1] === target[j - 1] ? 0 : 1);
      previous[j] = Math.min(previous[j] + 1, previous[j - 1] + 1, substitution);
      diagonal = temp;
    }
  }
  return previous[target.length];
}
