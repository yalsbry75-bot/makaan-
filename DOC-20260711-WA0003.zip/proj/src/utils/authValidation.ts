import type { FieldErrors, PasswordChangePayload, ProfileUpdatePayload, SignInPayload, SignUpPayload } from '@/types/auth';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const STRONG_PASSWORD_PATTERN = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

export function isValidEmail(email: string) {
  return EMAIL_PATTERN.test(email.trim());
}

export function validateSignIn(payload: SignInPayload): FieldErrors<keyof SignInPayload> {
  const errors: FieldErrors<keyof SignInPayload> = {};
  if (!payload.email.trim()) errors.email = 'البريد الإلكتروني مطلوب.';
  else if (!isValidEmail(payload.email)) errors.email = 'صيغة البريد الإلكتروني غير صحيحة.';
  if (!payload.password) errors.password = 'كلمة المرور مطلوبة.';
  return errors;
}

export function validateSignUp(payload: SignUpPayload): FieldErrors<keyof SignUpPayload> {
  const errors: FieldErrors<keyof SignUpPayload> = {};
  if (!payload.name.trim()) errors.name = 'الاسم الكامل مطلوب.';
  else if (payload.name.trim().length < 3) errors.name = 'الاسم يجب أن يحتوي على 3 أحرف على الأقل.';
  if (!payload.email.trim()) errors.email = 'البريد الإلكتروني مطلوب.';
  else if (!isValidEmail(payload.email)) errors.email = 'صيغة البريد الإلكتروني غير صحيحة.';
  if (!payload.password) errors.password = 'كلمة المرور مطلوبة.';
  else if (!STRONG_PASSWORD_PATTERN.test(payload.password)) errors.password = 'كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على حرف كبير وحرف صغير ورقم.';
  if (!payload.confirmPassword) errors.confirmPassword = 'تأكيد كلمة المرور مطلوب.';
  else if (payload.password !== payload.confirmPassword) errors.confirmPassword = 'كلمتا المرور غير متطابقتين.';
  return errors;
}

export function validateProfile(payload: ProfileUpdatePayload): FieldErrors<keyof ProfileUpdatePayload> {
  const errors: FieldErrors<keyof ProfileUpdatePayload> = {};
  if (!payload.name.trim()) errors.name = 'الاسم مطلوب.';
  if (!payload.email.trim()) errors.email = 'البريد الإلكتروني مطلوب.';
  else if (!isValidEmail(payload.email)) errors.email = 'صيغة البريد الإلكتروني غير صحيحة.';
  return errors;
}

export function validatePasswordChange(payload: PasswordChangePayload): FieldErrors<keyof PasswordChangePayload> {
  const errors: FieldErrors<keyof PasswordChangePayload> = {};
  if (!payload.currentPassword) errors.currentPassword = 'كلمة المرور الحالية مطلوبة.';
  if (!payload.newPassword) errors.newPassword = 'كلمة المرور الجديدة مطلوبة.';
  else if (!STRONG_PASSWORD_PATTERN.test(payload.newPassword)) errors.newPassword = 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل وتحتوي على حرف كبير وحرف صغير ورقم.';
  if (!payload.confirmPassword) errors.confirmPassword = 'تأكيد كلمة المرور مطلوب.';
  else if (payload.newPassword !== payload.confirmPassword) errors.confirmPassword = 'كلمتا المرور غير متطابقتين.';
  return errors;
}

export function hasErrors(errors: FieldErrors) {
  return Object.keys(errors).length > 0;
}
