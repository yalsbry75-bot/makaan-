export function nowIso() {
  return new Date().toISOString();
}

export function addHours(date: Date, hours: number) {
  const next = new Date(date);
  next.setHours(next.getHours() + hours);
  return next;
}

export function addDays(date: Date, days: number) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

export function normalizeEmail(email: string) {
  return sanitizeText(email).toLowerCase();
}

export function createId(prefix: string) {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return `${prefix}_${crypto.randomUUID()}`;
  }
  return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

export function safeJsonParse<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

export function sanitizeText(value: string, maxLength = 5000) {
  return value
    .replace(/[<>]/g, '')
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .trim()
    .slice(0, maxLength);
}

export function sanitizeOptionalUrl(value: string | undefined) {
  if (!value) return undefined;
  const sanitized = sanitizeText(value, 2048);
  try {
    const url = new URL(sanitized);
    if (!['http:', 'https:'].includes(url.protocol)) return undefined;
    return url.toString();
  } catch {
    return undefined;
  }
}

export function sanitizeRecord<T>(record: T): T {
  if (Array.isArray(record)) return record.map((item) => sanitizeRecord(item)) as T;
  if (!record || typeof record !== 'object') {
    return typeof record === 'string' ? (sanitizeText(record) as T) : record;
  }

  const output: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(record as Record<string, unknown>)) {
    if (typeof value === 'string') {
      output[key] = key.toLowerCase().includes('url') || key === 'website' ? sanitizeOptionalUrl(value) ?? sanitizeText(value, 2048) : sanitizeText(value);
      continue;
    }
    output[key] = sanitizeRecord(value);
  }
  return output as T;
}

function toBase64(value: string) {
  if (typeof btoa !== 'undefined') return btoa(unescape(encodeURIComponent(value)));
  return value;
}

// Local-only placeholder hashing for the browser adapter. Replace with server-side password hashing when a real backend is attached.
export function hashPassword(password: string) {
  return toBase64(`ai-hub-arabia::${password}`);
}

export function isSessionFresh(expiresAt: string) {
  const expiry = new Date(expiresAt).getTime();
  return Number.isFinite(expiry) && expiry > Date.now();
}

export function createSecurityHeadersMeta() {
  return {
    referrerPolicy: 'strict-origin-when-cross-origin',
    permissionsPolicy: 'camera=(), microphone=(), geolocation=(), payment=()',
  };
}
