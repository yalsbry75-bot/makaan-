import type { AITool, ToolCategory, ToolPlatform, ToolVisibilityStatus } from '@/types';
import type { ReviewRecord } from '@/types/database';
import { nowIso } from '@/utils/security';

const platformByCategory: Record<string, ToolPlatform[]> = {
  writing: ['web', 'api'],
  design: ['web', 'ios', 'android'],
  images: ['web', 'ios', 'android'],
  video: ['web', 'desktop'],
  coding: ['web', 'api', 'desktop'],
  marketing: ['web', 'api'],
  education: ['web', 'android', 'ios'],
  audio: ['web', 'api'],
  translation: ['web', 'desktop', 'ios', 'android', 'api'],
  productivity: ['web', 'ios', 'android', 'desktop'],
  business: ['web', 'api'],
  data: ['web', 'api', 'desktop'],
  research: ['web'],
  automation: ['web', 'api'],
  security: ['web', 'api'],
};

function makeDateFromYear(year: string, fallbackMonth = '01') {
  const parsedYear = /^\d{4}$/.test(year) ? year : '2025';
  return `${parsedYear}-${fallbackMonth}-15T09:00:00.000Z`;
}

export function normalizeTool(tool: AITool, reviews: ReviewRecord[] = []): AITool {
  const approvedReviews = reviews.filter((review) => review.toolId === tool.id && review.status === 'approved');
  const rating = approvedReviews.length
    ? Number((approvedReviews.reduce((sum, review) => sum + review.rating, 0) / approvedReviews.length).toFixed(1))
    : tool.rating;

  return {
    ...tool,
    platform: tool.platform?.length ? tool.platform : platformByCategory[tool.categorySlug] ?? ['web'],
    reviewsCount: tool.reviewsCount ?? approvedReviews.length,
    visibilityStatus: tool.visibilityStatus ?? 'active',
    addedAt: tool.addedAt ?? makeDateFromYear(tool.launchYear, '03'),
    lastUpdatedAt: tool.lastUpdatedAt ?? nowIso(),
    fullDescriptionAr: tool.fullDescriptionAr ?? `${tool.descriptionAr} تشمل الأداة خصائص عملية، حالات استخدام واضحة، وتكاملات مناسبة للفرق التي تريد تجربة ذكاء اصطناعي موثوقة وقابلة للتقييم قبل الاعتماد.` ,
    fullDescriptionEn: tool.fullDescriptionEn ?? `${tool.descriptionEn} The tool includes practical capabilities, clear use cases, and relevant integrations for teams that need a reliable AI product before adoption.`,
    rating,
  };
}

export function normalizeTools(tools: AITool[], reviews: ReviewRecord[] = []) {
  return tools.map((tool) => normalizeTool(tool, reviews));
}

export function normalizeCategories(categories: ToolCategory[], tools: AITool[]): ToolCategory[] {
  const timestamp = nowIso();
  return categories.map((category) => ({
    ...category,
    toolsCount: tools.filter((tool) => tool.categorySlug === category.slug && (tool.visibilityStatus ?? 'active') === 'active').length || category.toolsCount,
    status: category.status ?? 'active' as ToolVisibilityStatus,
    createdAt: category.createdAt ?? timestamp,
    updatedAt: category.updatedAt ?? timestamp,
  }));
}

export function slugifyToolName(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\u0600-\u06FF]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 72) || `tool-${Date.now()}`;
}

export function platformLabel(platform: ToolPlatform, locale: 'ar' | 'en') {
  const labels: Record<ToolPlatform, { ar: string; en: string }> = {
    web: { ar: 'ويب', en: 'Web' },
    android: { ar: 'أندرويد', en: 'Android' },
    ios: { ar: 'iOS', en: 'iOS' },
    api: { ar: 'API', en: 'API' },
    desktop: { ar: 'سطح المكتب', en: 'Desktop' },
  };
  return labels[platform][locale];
}
