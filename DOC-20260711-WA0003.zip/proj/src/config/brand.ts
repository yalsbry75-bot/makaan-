export const brand = {
  colors: {
    primary: '#0F766E',
    cyan: '#67E8F9',
    gold: '#F59E0B',
    slate: '#0F172A',
    background: '#F8FAFC',
  },
  radius: {
    card: '1.35rem',
    panel: '2rem',
  },
  typography: {
    arabic: 'Tajawal',
    english: 'Inter',
    display: 'Plus Jakarta Sans',
  },
};
