export type ProductionReadinessItem = {
  id: string;
  labelAr: string;
  labelEn: string;
  area: 'security' | 'performance' | 'seo' | 'pwa' | 'quality' | 'documentation' | 'firebase' | 'legal' | 'ux';
  required: boolean;
};

export const productionReadinessChecklist: ProductionReadinessItem[] = [
  // ── الأمان ──────────────────────────────────────────────────────────────────
  { id: 'protected-routes', labelAr: 'حماية المسارات الخاصة والإدارية', labelEn: 'Protected private and admin routes', area: 'security', required: true },
  { id: 'input-validation', labelAr: 'التحقق من المدخلات قبل حفظ البيانات', labelEn: 'Input validation before data persistence', area: 'security', required: true },
  { id: 'audit-log', labelAr: 'سجل تدقيق للأحداث الأمنية المهمة', labelEn: 'Audit log for important security events', area: 'security', required: true },
  { id: 'env-secrets', labelAr: 'حماية المتغيرات السرية بملف .env', labelEn: 'Secret variables protected in .env file', area: 'security', required: true },
  { id: 'firestore-rules', labelAr: 'قواعد أمان Firestore مُعرَّفة', labelEn: 'Firestore security rules defined', area: 'firebase', required: true },
  { id: 'storage-rules', labelAr: 'قواعد أمان Storage مُعرَّفة', labelEn: 'Storage security rules defined', area: 'firebase', required: true },

  // ── الأداء ──────────────────────────────────────────────────────────────────
  { id: 'lazy-routes', labelAr: 'تحميل الصفحات عند الحاجة (Lazy Loading)', labelEn: 'Lazy-loaded application routes', area: 'performance', required: true },
  { id: 'manual-chunks', labelAr: 'تقسيم حزم الإنتاج (Code Splitting)', labelEn: 'Production bundle code splitting', area: 'performance', required: true },
  { id: 'firebase-chunk', labelAr: 'Firebase SDK في حزمة منفصلة', labelEn: 'Firebase SDK in a separate chunk', area: 'performance', required: true },

  // ── SEO والPWA ──────────────────────────────────────────────────────────────
  { id: 'seo-assets', labelAr: 'ملفات Sitemap وRobots وبيانات SEO', labelEn: 'Sitemap, robots, and SEO metadata', area: 'seo', required: true },
  { id: 'og-meta', labelAr: 'OpenGraph وTwitter meta tags مكتملة', labelEn: 'OpenGraph and Twitter meta tags complete', area: 'seo', required: true },
  { id: 'structured-data', labelAr: 'Schema.org JSON-LD للبحث', labelEn: 'Schema.org JSON-LD structured data', area: 'seo', required: true },
  { id: 'pwa-shell', labelAr: 'Manifest وService Worker وتجربة Offline', labelEn: 'Manifest, service worker, and offline shell', area: 'pwa', required: true },

  // ── تجربة المستخدم ───────────────────────────────────────────────────────────
  { id: '404-page', labelAr: 'صفحة 404 مع توجيه للرئيسية', labelEn: '404 page with navigation to home', area: 'ux', required: true },
  { id: 'responsive', labelAr: 'تصميم متجاوب على جميع الأجهزة', labelEn: 'Responsive design across all devices', area: 'ux', required: true },
  { id: 'rtl-ltr', labelAr: 'دعم RTL للعربية وLTR للإنجليزية', labelEn: 'RTL Arabic and LTR English support', area: 'ux', required: true },
  { id: 'dark-mode', labelAr: 'الوضع المظلم والفاتح ويعمل بكل الصفحات', labelEn: 'Dark and light mode across all pages', area: 'ux', required: true },
  { id: 'accessibility', labelAr: 'دعم ARIA وتنقل بلوحة المفاتيح', labelEn: 'ARIA support and keyboard navigation', area: 'ux', required: true },

  // ── القانوني ─────────────────────────────────────────────────────────────────
  { id: 'privacy-policy', labelAr: 'سياسة خصوصية شاملة ومكتملة', labelEn: 'Comprehensive privacy policy', area: 'legal', required: true },
  { id: 'terms-of-service', labelAr: 'شروط استخدام شاملة ومكتملة', labelEn: 'Comprehensive terms of service', area: 'legal', required: true },
  { id: 'contact-page', labelAr: 'صفحة تواصل فعَّالة ومربوطة بقاعدة البيانات', labelEn: 'Functional contact page connected to database', area: 'legal', required: true },

  // ── الجودة ──────────────────────────────────────────────────────────────────
  { id: 'quality-scripts', labelAr: 'فحوصات جودة ومسارات قابلة للتشغيل', labelEn: 'Runnable quality and route checks', area: 'quality', required: true },
  { id: 'env-example', labelAr: 'ملف .env.example لتوثيق المتغيرات', labelEn: '.env.example file documenting all variables', area: 'quality', required: true },
  { id: 'typescript-strict', labelAr: 'TypeScript Strict Mode مُفعَّل', labelEn: 'TypeScript strict mode enabled', area: 'quality', required: true },

  // ── Firebase ─────────────────────────────────────────────────────────────────
  { id: 'firebase-config', labelAr: 'ملفات إعداد Firebase جاهزة', labelEn: 'Firebase configuration files ready', area: 'firebase', required: true },
  { id: 'firebase-auth', labelAr: 'Firebase Authentication مُهيَّأ', labelEn: 'Firebase Authentication configured', area: 'firebase', required: true },
  { id: 'firestore-indexes', labelAr: 'فهارس Firestore مُعرَّفة', labelEn: 'Firestore composite indexes defined', area: 'firebase', required: true },
  { id: 'firebase-hosting', labelAr: 'إعدادات Firebase Hosting جاهزة', labelEn: 'Firebase Hosting config ready', area: 'firebase', required: true },

  // ── التوثيق ──────────────────────────────────────────────────────────────────
  { id: 'developer-docs', labelAr: 'توثيق التشغيل والبنية والنشر', labelEn: 'Install, structure, and deployment documentation', area: 'documentation', required: true },
  { id: 'phase-reports', labelAr: 'تقارير المراحل 1-15 مكتملة', labelEn: 'Phase 1–15 reports complete', area: 'documentation', required: true },
];

export const productionRelease = {
  version: '1.1.0',
  phase: 15,
  status: 'production-ready',
  releaseName: 'AI Hub Arabia — Final Production Release',
  recommendedNode: '20+',
  firebaseRequired: true,
  storageMode: 'firestore',
  totalFeatures: 156,
  totalPages: 29,
  totalRoutes: 31,
};
