import { BarChart3, Boxes, FileText, Heart, HelpCircle, Home, LayoutDashboard, Mail, MessageSquareText, Scale, Search, ShieldCheck, UserRound } from 'lucide-react';

export const siteConfig = {
  name: 'AI Hub Arabia',
  nameAr: 'منصة AI Hub Arabia',
  descriptionAr: 'دليل عربي احترافي لاكتشاف ومقارنة أدوات الذكاء الاصطناعي.',
  descriptionEn: 'A professional bilingual hub for discovering and comparing AI tools.',
  supportEmail: 'support@aihubarabia.com',
  nav: [
    { labelAr: 'الرئيسية', labelEn: 'Home', href: '/', icon: Home },
    { labelAr: 'الأدوات', labelEn: 'Tools', href: '/tools', icon: Boxes },
    { labelAr: 'التصنيفات', labelEn: 'Categories', href: '/categories', icon: BarChart3 },
    { labelAr: 'البحث', labelEn: 'Search', href: '/search', icon: Search },
    { labelAr: 'المقارنة', labelEn: 'Compare', href: '/compare', icon: Scale },
    { labelAr: 'من نحن', labelEn: 'About', href: '/about', icon: HelpCircle },
  ],
  footerNav: [
    { labelAr: 'تواصل معنا', labelEn: 'Contact', href: '/contact', icon: Mail },
    { labelAr: 'سياسة الخصوصية', labelEn: 'Privacy Policy', href: '/privacy', icon: ShieldCheck },
    { labelAr: 'الشروط والأحكام', labelEn: 'Terms', href: '/terms', icon: FileText },
  ],
  dashboardNav: [
    { labelAr: 'لوحة المستخدم', labelEn: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { labelAr: 'الملف الشخصي', labelEn: 'Profile', href: '/profile', icon: UserRound },
    { labelAr: 'المفضلة', labelEn: 'Favorites', href: '/favorites', icon: Heart },
    { labelAr: 'مقارناتي', labelEn: 'My comparisons', href: '/my-comparisons', icon: Scale },
    { labelAr: 'مراجعاتي', labelEn: 'My reviews', href: '/my-reviews', icon: MessageSquareText },
    { labelAr: 'لوحة الإدارة', labelEn: 'Admin', href: '/admin', icon: ShieldCheck },
  ],
};

export const seoDefaults = {
  title: 'AI Hub Arabia | Discover AI Tools',
  description: 'Discover, compare, and organize AI tools in Arabic and English.',
  siteUrl: 'https://aihubarabia.com',
};
