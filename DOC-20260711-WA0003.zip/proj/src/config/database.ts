import type { CollectionName } from '@/types/database';

export const databaseCollections: Array<{ name: CollectionName; descriptionAr: string; descriptionEn: string; indexes: string[] }> = [
  { name: 'users', descriptionAr: 'حسابات المستخدمين والصلاحيات.', descriptionEn: 'User accounts and roles.', indexes: ['email', 'role', 'status'] },
  { name: 'tools', descriptionAr: 'أدوات الذكاء الاصطناعي ومعلوماتها.', descriptionEn: 'AI tools and their metadata.', indexes: ['slug', 'categorySlug', 'pricing', 'platform', 'tags', 'rating', 'addedAt', 'users'] },
  { name: 'categories', descriptionAr: 'تصنيفات الأدوات.', descriptionEn: 'Tool categories.', indexes: ['slug'] },
  { name: 'favorites', descriptionAr: 'الأدوات المحفوظة لكل مستخدم.', descriptionEn: 'Saved tools per user.', indexes: ['userId', 'toolId'] },
  { name: 'reviews', descriptionAr: 'مراجعات الأدوات وحالة الاعتماد.', descriptionEn: 'Tool reviews and moderation status.', indexes: ['toolId', 'userId', 'status'] },
  { name: 'comparisons', descriptionAr: 'المقارنات المحفوظة.', descriptionEn: 'Saved comparisons.', indexes: ['userId'] },
  { name: 'settings', descriptionAr: 'إعدادات المنصة العامة.', descriptionEn: 'Platform-wide settings.', indexes: ['key'] },
  { name: 'contactMessages', descriptionAr: 'رسائل نموذج التواصل.', descriptionEn: 'Contact form messages.', indexes: ['email', 'status'] },
  { name: 'reports', descriptionAr: 'البلاغات وطلبات المراجعة.', descriptionEn: 'Reports and moderation requests.', indexes: ['reporterId', 'targetType', 'status'] },
  { name: 'notifications', descriptionAr: 'تنبيهات المستخدمين.', descriptionEn: 'User notifications.', indexes: ['userId', 'read', 'type'] },
  { name: 'auditLogs', descriptionAr: 'سجل الأمان والأخطاء المهمة.', descriptionEn: 'Security and important error audit log.', indexes: ['actorId', 'event', 'severity', 'resource'] },
];
