/**
 * Auth Context — AI Hub Arabia
 * Phase 14: Real Services Integration
 *
 * يدعم وضعَي التشغيل:
 * - Firebase Mode  → يستخدم onAuthStateChanged لمتابعة جلسة Firebase تلقائيًا
 * - LocalStorage Mode → يقرأ الجلسة من localStorage/sessionStorage
 */

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import * as authService from '@/services/authService';
import type {
  AccountSettingsPayload,
  AuthStatus,
  AuthUser,
  FieldErrors,
  PasswordChangePayload,
  PasswordResetPayload,
  ProfileUpdatePayload,
  SignInPayload,
  SignUpPayload,
  UserRole,
} from '@/types/auth';
import { AuthServiceError } from '@/types/auth';
import { isFirebaseConfigured } from '@/firebase/config';
import { firebaseOnAuthStateChanged } from '@/firebase/auth';
import { getUserById } from '@/services/repositories/userRepository';

export type AuthActionResult = {
  success: boolean;
  message: string;
  fieldErrors?: FieldErrors;
};

type AuthContextValue = {
  user: AuthUser | null;
  status: AuthStatus;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (payload: SignInPayload) => Promise<AuthActionResult>;
  register: (payload: SignUpPayload) => Promise<AuthActionResult>;
  logout: () => Promise<void>;
  resetPassword: (payload: PasswordResetPayload) => Promise<AuthActionResult>;
  updateProfile: (payload: ProfileUpdatePayload) => Promise<AuthActionResult>;
  changePassword: (payload: PasswordChangePayload) => Promise<AuthActionResult>;
  updateAccountSettings: (payload: AccountSettingsPayload) => Promise<AuthActionResult>;
  canAccess: (roles?: UserRole[]) => boolean;
};

const AuthContext = createContext<AuthContextValue | null>(null);

function toActionError(error: unknown, fallback: string): AuthActionResult {
  if (error instanceof AuthServiceError) {
    return { success: false, message: error.message, fieldErrors: error.fieldErrors };
  }
  return { success: false, message: fallback };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [status, setStatus] = useState<AuthStatus>('loading');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // ── استرداد الجلسة عند التحميل ─────────────────────────────────────────

  useEffect(() => {
    if (isFirebaseConfigured()) {
      // وضع Firebase: استخدام onAuthStateChanged لمتابعة الجلسة تلقائيًا
      let isMounted = true;

      const unsubscribe = firebaseOnAuthStateChanged(async (fbUser) => {
        if (!fbUser) {
          if (isMounted) {
            setUser(null);
            setStatus('guest');
          }
          return;
        }

        try {
          // جلب بيانات المستخدم الكاملة من Firestore
          const storedUser = await getUserById(fbUser.uid);
          if (!isMounted) return; // تجنُّب التحديث إذا فُكَّ ارتباط المكون

          if (!storedUser || storedUser.status !== 'active') {
            setUser(null);
            setStatus('guest');
            return;
          }

          const { passwordHash: _ph, ...authUser } = storedUser;
          setUser(authUser);
          setStatus('authenticated');
        } catch {
          if (isMounted) {
            setUser(null);
            setStatus('guest');
          }
        }
      });

      return () => {
        isMounted = false;
        unsubscribe();
      };
    }

    // وضع localStorage: قراءة الجلسة مرة واحدة
    let isMounted = true;
    authService
      .getCurrentSession()
      .then((session) => {
        if (!isMounted) return;
        setUser(session?.user ?? null);
        setStatus(session ? 'authenticated' : 'guest');
      })
      .catch(() => {
        if (!isMounted) return;
        setUser(null);
        setStatus('guest');
      });

    return () => {
      isMounted = false;
    };
  }, []);

  // ── عمليات المصادقة ────────────────────────────────────────────────────

  const login = useCallback(async (payload: SignInPayload): Promise<AuthActionResult> => {
    setIsSubmitting(true);
    try {
      const session = await authService.signIn(payload);

      if (!isFirebaseConfigured()) {
        // في وضع localStorage، نُحدِّث الحالة يدويًا
        setUser(session.user);
        setStatus('authenticated');
      }
      // في وضع Firebase، onAuthStateChanged يُحدِّث الحالة تلقائيًا

      return { success: true, message: 'تم تسجيل الدخول بنجاح.' };
    } catch (error) {
      return toActionError(error, 'تعذر تسجيل الدخول حاليًا.');
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const register = useCallback(async (payload: SignUpPayload): Promise<AuthActionResult> => {
    setIsSubmitting(true);
    try {
      const session = await authService.signUp(payload);

      if (!isFirebaseConfigured()) {
        setUser(session.user);
        setStatus('authenticated');
      }
      // في وضع Firebase، onAuthStateChanged يُحدِّث الحالة تلقائيًا

      return { success: true, message: 'تم إنشاء الحساب بنجاح.' };
    } catch (error) {
      return toActionError(error, 'تعذر إنشاء الحساب حاليًا.');
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const logout = useCallback(async () => {
    setIsSubmitting(true);
    try {
      await authService.signOut();
      setUser(null);
      setStatus('guest');
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const resetPassword = useCallback(async (payload: PasswordResetPayload): Promise<AuthActionResult> => {
    setIsSubmitting(true);
    try {
      await authService.requestPasswordReset(payload);
      return {
        success: true,
        message: isFirebaseConfigured()
          ? 'تم إرسال رابط استعادة كلمة المرور إلى بريدك الإلكتروني.'
          : 'تم تسجيل طلب الاستعادة. تحقق من بريدك عند ربط خدمة البريد.',
      };
    } catch (error) {
      return toActionError(error, 'تعذر إرسال طلب استعادة كلمة المرور.');
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const updateProfile = useCallback(
    async (payload: ProfileUpdatePayload): Promise<AuthActionResult> => {
      if (!user) return { success: false, message: 'يجب تسجيل الدخول أولًا.' };
      setIsSubmitting(true);
      try {
        const updatedUser = await authService.updateProfile(user.id, payload);
        setUser(updatedUser);
        return { success: true, message: 'تم تحديث الملف الشخصي بنجاح.' };
      } catch (error) {
        return toActionError(error, 'تعذر تحديث الملف الشخصي.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [user],
  );

  const changePassword = useCallback(
    async (payload: PasswordChangePayload): Promise<AuthActionResult> => {
      if (!user) return { success: false, message: 'يجب تسجيل الدخول أولًا.' };
      setIsSubmitting(true);
      try {
        await authService.changePassword(user.id, payload);
        return { success: true, message: 'تم تغيير كلمة المرور بنجاح.' };
      } catch (error) {
        return toActionError(error, 'تعذر تغيير كلمة المرور.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [user],
  );

  const updateAccountSettings = useCallback(
    async (payload: AccountSettingsPayload): Promise<AuthActionResult> => {
      if (!user) return { success: false, message: 'يجب تسجيل الدخول أولًا.' };
      setIsSubmitting(true);
      try {
        const updatedUser = await authService.updateAccountSettings(user.id, payload);
        setUser(updatedUser);
        return { success: true, message: 'تم حفظ إعدادات الحساب.' };
      } catch (error) {
        return toActionError(error, 'تعذر حفظ إعدادات الحساب.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [user],
  );

  const canAccess = useCallback((roles?: UserRole[]) => authService.userHasRole(user, roles), [user]);

  const value = useMemo(
    () => ({
      user,
      status,
      isAuthenticated: status === 'authenticated' && Boolean(user),
      isLoading: status === 'loading' || isSubmitting,
      login,
      register,
      logout,
      resetPassword,
      updateProfile,
      changePassword,
      updateAccountSettings,
      canAccess,
    }),
    [user, status, isSubmitting, login, register, logout, resetPassword, updateProfile, changePassword, updateAccountSettings, canAccess],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside AuthProvider');
  return context;
}
