import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type { ThemeMode } from '@/types';

type ThemeContextValue = {
  theme: ThemeMode;
  resolvedTheme: 'light' | 'dark';
  setTheme: (theme: ThemeMode) => void;
  toggleTheme: () => void;
};

const ThemeContext = createContext<ThemeContextValue | null>(null);

/**
 * AI Hub Arabia ships a premium dark emerald/gold identity by default.
 * "system" preference is intentionally ignored for the resolved theme so the
 * brand experience is consistent — users can still opt into light mode manually.
 */
function getSystemTheme(): 'light' | 'dark' {
  return 'dark';
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    const saved = window.localStorage.getItem('ai-hub-theme') as ThemeMode | null;
    return saved ?? 'dark';
  });
  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>(() => (theme === 'light' ? 'light' : 'dark'));

  useEffect(() => {
    const root = document.documentElement;
    const nextResolvedTheme = theme === 'light' ? 'light' : 'dark';
    setResolvedTheme(nextResolvedTheme);
    root.classList.toggle('dark', nextResolvedTheme === 'dark');
    root.classList.toggle('light', nextResolvedTheme === 'light');
    root.dataset.theme = nextResolvedTheme;
    window.localStorage.setItem('ai-hub-theme', theme);
  }, [theme]);

  const setTheme = useCallback((nextTheme: ThemeMode) => setThemeState(nextTheme), []);
  const toggleTheme = useCallback(() => {
    setThemeState((current) => {
      const currentResolved = current === 'system' ? getSystemTheme() : current;
      return currentResolved === 'dark' ? 'light' : 'dark';
    });
  }, []);

  const value = useMemo(
    () => ({ theme, resolvedTheme, setTheme, toggleTheme }),
    [theme, resolvedTheme, setTheme, toggleTheme],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used inside ThemeProvider');
  }
  return context;
}
