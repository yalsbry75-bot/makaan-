import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type { Direction, Locale } from '@/types';

const dictionary = {
  ar: {
    'auth.login': 'تسجيل الدخول',
    'auth.register': 'إنشاء حساب',
    'auth.forgotPassword': 'استعادة كلمة المرور',
    'common.search': 'ابحث عن أداة أو تصنيف',
    'common.viewDetails': 'عرض التفاصيل',
    'common.getStarted': 'ابدأ الآن',
    'common.exploreTools': 'استكشف الأدوات',
    'common.featured': 'مميز',
    'common.verified': 'موثق',
    'common.rating': 'التقييم',
    'common.users': 'المستخدمون',
    'common.save': 'حفظ',
    'common.compare': 'قارن',
  },
  en: {
    'auth.login': 'Login',
    'auth.register': 'Create account',
    'auth.forgotPassword': 'Reset password',
    'common.search': 'Search tools or categories',
    'common.viewDetails': 'View details',
    'common.getStarted': 'Get started',
    'common.exploreTools': 'Explore tools',
    'common.featured': 'Featured',
    'common.verified': 'Verified',
    'common.rating': 'Rating',
    'common.users': 'Users',
    'common.save': 'Save',
    'common.compare': 'Compare',
  },
} as const;

type DictionaryKey = keyof typeof dictionary.ar;

type LocaleContextValue = {
  locale: Locale;
  direction: Direction;
  setLocale: (locale: Locale) => void;
  toggleLocale: () => void;
  t: (key: DictionaryKey) => string;
};

const LocaleContext = createContext<LocaleContextValue | null>(null);

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => {
    const saved = window.localStorage.getItem('ai-hub-locale') as Locale | null;
    return saved ?? 'ar';
  });

  const direction: Direction = locale === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = direction;
    window.localStorage.setItem('ai-hub-locale', locale);
  }, [locale, direction]);

  const setLocale = useCallback((nextLocale: Locale) => setLocaleState(nextLocale), []);
  const toggleLocale = useCallback(() => setLocaleState((value) => (value === 'ar' ? 'en' : 'ar')), []);
  const t = useCallback((key: DictionaryKey) => dictionary[locale][key], [locale]);

  const value = useMemo(
    () => ({ locale, direction, setLocale, toggleLocale, t }),
    [locale, direction, setLocale, toggleLocale, t],
  );

  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}

export function useLocale() {
  const context = useContext(LocaleContext);
  if (!context) {
    throw new Error('useLocale must be used inside LocaleProvider');
  }
  return context;
}
