import { categories, comparisonItems, favoriteSlugs, tools } from '@/constants/catalogSeed';
import { normalizeCategories, normalizeTools } from '@/utils/toolNormalization';
import type { AuditLogRecord, DatabaseSchema, FavoriteRecord, NotificationRecord, ReviewRecord } from '@/types/database';
import type { StoredUser, UserRole } from '@/types/auth';
import { createId, hashPassword, nowIso } from '@/utils/security';

function createDemoUser(role: UserRole): StoredUser {
  const createdAt = nowIso();
  const isAdmin = role === 'admin';
  return {
    id: isAdmin ? 'admin-demo' : 'user-demo',
    name: isAdmin ? 'AI Hub Admin' : 'AI Hub User',
    email: isAdmin ? 'admin@aihubarabia.com' : 'user@aihubarabia.com',
    role,
    status: 'active',
    title: isAdmin ? 'Platform Administrator' : 'AI Tools Explorer',
    company: isAdmin ? 'AI Hub Arabia' : 'Personal Workspace',
    bio: isAdmin ? 'Demo administrator account for testing protected admin interfaces.' : 'Demo user account for testing profile and dashboard flows.',
    createdAt,
    updatedAt: createdAt,
    preferences: {
      locale: 'ar',
      theme: 'system',
      newsletter: true,
      productUpdates: true,
    },
    passwordHash: hashPassword(isAdmin ? 'Admin@12345' : 'User@12345'),
  };
}

const userDemo = createDemoUser('user');
const adminDemo = createDemoUser('admin');

const seededFavorites: FavoriteRecord[] = tools
  .filter((tool) => favoriteSlugs.includes(tool.slug))
  .map((tool, index) => ({
    id: `fav-demo-${index + 1}`,
    userId: userDemo.id,
    toolId: tool.id,
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }));

const seededReviews: ReviewRecord[] = tools.slice(0, 18).map((tool, index) => ({
  id: `review-demo-${index + 1}`,
  userId: index % 2 === 0 ? userDemo.id : adminDemo.id,
  toolId: tool.id,
  rating: Math.max(4, Math.round(tool.rating)),
  title: index % 2 === 0 ? 'تجربة مفيدة' : 'Ready for publishing',
  comment: index % 2 === 0 ? 'الأداة واضحة وسهلة التجربة وتستحق المتابعة.' : 'Reviewed against platform quality checks.',
  status: index % 6 === 5 ? 'pending' : 'approved',
  createdAt: nowIso(),
  updatedAt: nowIso(),
}));

const seededNotifications: NotificationRecord[] = [
  {
    id: 'notification-demo-1',
    userId: userDemo.id,
    titleAr: 'تم تحديث مكتبة الأدوات',
    titleEn: 'Tool library updated',
    bodyAr: 'تمت إضافة أدوات جديدة في تصنيفي التعليم والإنتاجية.',
    bodyEn: 'New tools were added to Education and Productivity categories.',
    read: false,
    type: 'system',
    createdAt: nowIso(),
    updatedAt: nowIso(),
  },
  {
    id: 'notification-demo-2',
    userId: userDemo.id,
    titleAr: 'اقتراح مناسب لك',
    titleEn: 'Recommended tool',
    bodyAr: 'جرّب Prototype Flow بناءً على أدواتك المفضلة.',
    bodyEn: 'Try Prototype Flow based on your favorites.',
    read: false,
    type: 'favorite',
    createdAt: nowIso(),
    updatedAt: nowIso(),
  },
  {
    id: 'notification-admin-1',
    userId: adminDemo.id,
    titleAr: 'مراجعة معلقة',
    titleEn: 'Pending review',
    bodyAr: 'توجد مراجعة جديدة تحتاج اعتمادًا إداريًا.',
    bodyEn: 'A new review needs admin approval.',
    read: false,
    type: 'review',
    createdAt: nowIso(),
    updatedAt: nowIso(),
  },
];


const seededAuditLogs: AuditLogRecord[] = [
  {
    id: 'audit-demo-1',
    actorId: adminDemo.id,
    event: 'database_seeded',
    severity: 'info',
    resource: 'database',
    metadata: { version: '13.0.0' },
    createdAt: nowIso(),
    updatedAt: nowIso(),
  },
];

export function createInitialDatabase(): DatabaseSchema {
  const normalizedTools = normalizeTools(tools, seededReviews);
  const normalizedCategories = normalizeCategories(categories, normalizedTools);

  return {
    users: [adminDemo, userDemo],
    tools: normalizedTools,
    categories: normalizedCategories,
    favorites: seededFavorites,
    reviews: seededReviews,
    comparisons: comparisonItems.length
      ? [
          {
            id: 'comparison-demo-1',
            userId: userDemo.id,
            name: 'Core AI stack',
            toolIds: comparisonItems.map((item) => item.id),
            createdAt: nowIso(),
            updatedAt: nowIso(),
          },
        ]
      : [],
    settings: [
      { id: 'setting-platform-name', key: 'platformName', value: 'AI Hub Arabia', createdAt: nowIso(), updatedAt: nowIso() },
      { id: 'setting-logo', key: 'logo', value: 'brand-mark.svg', createdAt: nowIso(), updatedAt: nowIso() },
      { id: 'setting-platform-description', key: 'platformDescription', value: 'Arabic-first SaaS directory for AI tools discovery and comparison.', createdAt: nowIso(), updatedAt: nowIso() },
      { id: 'setting-review-mode', key: 'reviewModeration', value: true, createdAt: nowIso(), updatedAt: nowIso() },
      { id: 'setting-default-locale', key: 'defaultLocale', value: 'ar', createdAt: nowIso(), updatedAt: nowIso() },
      { id: 'setting-supported-languages', key: 'supportedLanguages', value: ['ar', 'en'], createdAt: nowIso(), updatedAt: nowIso() },
      { id: 'setting-seo-title', key: 'seoTitle', value: 'AI Hub Arabia | Discover AI Tools', createdAt: nowIso(), updatedAt: nowIso() },
      { id: 'setting-seo-description', key: 'seoDescription', value: 'Discover, compare, and organize AI tools in Arabic and English.', createdAt: nowIso(), updatedAt: nowIso() },
    ],
    contactMessages: [
      {
        id: 'contact-demo-1',
        name: 'Demo Visitor',
        email: 'visitor@example.com',
        message: 'أرغب في اقتراح أداة جديدة للمنصة.',
        status: 'new',
        createdAt: nowIso(),
        updatedAt: nowIso(),
      },
      {
        id: 'contact-demo-2',
        name: 'SaaS Founder',
        email: 'founder@example.com',
        message: 'We would like to submit our AI research assistant for review.',
        status: 'read',
        createdAt: nowIso(),
        updatedAt: nowIso(),
      },
    ],
    reports: [
      {
        id: 'report-demo-1',
        reporterId: userDemo.id,
        targetType: 'tool',
        targetId: tools[0]?.id ?? 'tool-01',
        reason: 'Requesting data verification before public listing.',
        status: 'open',
        createdAt: nowIso(),
        updatedAt: nowIso(),
      },
      {
        id: 'report-demo-2',
        reporterId: userDemo.id,
        targetType: 'review',
        targetId: 'review-demo-4',
        reason: 'Potentially promotional review needs moderation.',
        status: 'investigating',
        createdAt: nowIso(),
        updatedAt: nowIso(),
      },
    ],
    notifications: seededNotifications,
    auditLogs: seededAuditLogs,
  };
}

export function ensureCoreSeeds(database: DatabaseSchema): DatabaseSchema {
  const next = { ...database };
  if (!next.users.some((user) => user.email === adminDemo.email)) next.users = [...next.users, adminDemo];
  if (!next.users.some((user) => user.email === userDemo.email)) next.users = [...next.users, userDemo];

  const toolBySlug = new Map((next.tools ?? []).map((tool) => [tool.slug, tool]));
  const mergedTools = tools.map((seedTool) => ({ ...seedTool, ...(toolBySlug.get(seedTool.slug) ?? {}) }));
  const customTools = (next.tools ?? []).filter((tool) => !tools.some((seedTool) => seedTool.slug === tool.slug));
  const normalizedTools = normalizeTools([...mergedTools, ...customTools], next.reviews ?? []);
  next.tools = normalizedTools;

  const categoryBySlug = new Map((next.categories ?? []).map((category) => [category.slug, category]));
  const mergedCategories = categories.map((seedCategory) => ({ ...seedCategory, ...(categoryBySlug.get(seedCategory.slug) ?? {}) }));
  const customCategories = (next.categories ?? []).filter((category) => !categories.some((seedCategory) => seedCategory.slug === category.slug));
  next.categories = normalizeCategories([...mergedCategories, ...customCategories], normalizedTools);

  const requiredSettings = createInitialDatabase().settings;
  const existingSettingKeys = new Set((next.settings ?? []).map((setting) => setting.key));
  next.settings = [...(next.settings ?? []), ...requiredSettings.filter((setting) => !existingSettingKeys.has(setting.key))];
  next.contactMessages = next.contactMessages?.length ? next.contactMessages : createInitialDatabase().contactMessages;
  next.reports = next.reports?.length ? next.reports : createInitialDatabase().reports;
  next.notifications = next.notifications?.length ? next.notifications : createInitialDatabase().notifications;
  next.auditLogs = next.auditLogs?.length ? next.auditLogs : createInitialDatabase().auditLogs;
  return next;
}

export function makeRecordId(prefix: string) {
  return createId(prefix);
}
