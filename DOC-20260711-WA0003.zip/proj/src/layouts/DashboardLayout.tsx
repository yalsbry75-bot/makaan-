import { NavLink, Outlet } from 'react-router-dom';
import { Sidebar } from '@/components/layout/Sidebar';
import { siteConfig } from '@/config/site';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { cn } from '@/utils/cn';

export function DashboardLayout() {
  const { user } = useAuth();
  const { locale } = useLocale();
  const visibleNav = siteConfig.dashboardNav.filter((item) => item.href !== '/admin' || user?.role === 'admin');

  return (
    <div className="container flex min-h-[calc(100vh-5rem)] gap-6 py-6">
      <Sidebar />
      <section className="min-w-0 flex-1">
        <nav className="mb-5 flex gap-2 overflow-x-auto rounded-2xl border bg-card p-2 lg:hidden" aria-label="Mobile dashboard navigation">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.href}
                to={item.href}
                className={({ isActive }) => cn('inline-flex shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground', isActive && 'bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground')}
              >
                <Icon className="h-4 w-4" />
                {locale === 'ar' ? item.labelAr : item.labelEn}
              </NavLink>
            );
          })}
        </nav>
        <Outlet />
      </section>
    </div>
  );
}
