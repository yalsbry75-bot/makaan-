import { Outlet } from 'react-router-dom';
import { BrandLogo } from '@/assets/brand/BrandLogo';
import { useLocale } from '@/hooks/useLocale';

export function AuthLayout() {
  const { locale } = useLocale();
  return (
    <div className="container grid min-h-[calc(100vh-5rem)] items-center gap-10 py-10 lg:grid-cols-[1fr_28rem]">
      <section className="hidden lg:block">
        <BrandLogo />
        <h1 className="mt-8 max-w-xl text-4xl font-extrabold tracking-tight lg:text-5xl">
          {locale === 'ar' ? 'ادخل إلى مركز أدواتك الذكية في ' : 'Access your AI tools hub on '}
          <span className="gradient-text">AI Hub Arabia</span>
        </h1>
        <p className="mt-5 max-w-xl text-lg leading-8 text-muted-foreground">
          {locale === 'ar'
            ? 'نظام دخول وتجربة حساب متكاملة مع تحقق من المدخلات، جلسات محمية، وصلاحيات قابلة للتوسع.'
            : 'An integrated account experience with validation, protected sessions, and scalable permissions.'}
        </p>
      </section>
      <Outlet />
    </div>
  );
}
