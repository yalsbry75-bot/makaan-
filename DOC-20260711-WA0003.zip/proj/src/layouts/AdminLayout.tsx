import { useEffect, useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { Activity, BarChart3, Bell, Boxes, Gauge, MailWarning, Menu, MessageSquareText, Search, Settings, ShieldCheck, Tags, UsersRound, X } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { useLocale } from '@/hooks/useLocale';
import { cn } from '@/utils/cn';
import { getAdminNotifications, getAdminOverviewStats } from '@/services/adminService';
import type { NotificationRecord } from '@/types/database';

const adminNav = [
  { href: '/admin', labelAr: 'الرئيسية', labelEn: 'Overview', icon: Gauge, end: true },
  { href: '/admin/tools', labelAr: 'الأدوات والتصنيفات', labelEn: 'Tools & categories', icon: Boxes },
  { href: '/admin/users', labelAr: 'المستخدمون', labelEn: 'Users', icon: UsersRound },
  { href: '/admin/reviews', labelAr: 'التقييمات', labelEn: 'Reviews', icon: MessageSquareText },
  { href: '/admin/messages', labelAr: 'الرسائل والبلاغات', labelEn: 'Messages & reports', icon: MailWarning },
  { href: '/admin/stats', labelAr: 'الإحصائيات', labelEn: 'Statistics', icon: BarChart3 },
  { href: '/admin/settings', labelAr: 'إعدادات الموقع', labelEn: 'Site settings', icon: Settings },
  { href: '/admin/system', labelAr: 'صحة النظام', labelEn: 'System health', icon: Activity },
];

export function AdminLayout() {
  const { locale } = useLocale();
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [counts, setCounts] = useState({ pendingReviews: 0, openReports: 0 });

  useEffect(() => {
    Promise.all([getAdminNotifications(), getAdminOverviewStats()]).then(([items, stats]) => {
      setNotifications(items.slice(0, 3));
      setCounts({ pendingReviews: stats.pendingReviewsCount, openReports: stats.openReportsCount });
    }).catch(() => undefined);
  }, []);

  const sidebar = (
    <aside className="flex h-full min-h-[calc(100vh-7rem)] flex-col rounded-3xl border bg-card p-4 shadow-card">
      <div className="mb-5 rounded-2xl bg-gradient-to-br from-primary/15 to-cyan-500/10 p-4">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-primary text-primary-foreground"><ShieldCheck className="h-5 w-5" /></div>
          <div>
            <p className="text-sm font-bold">{locale === 'ar' ? 'لوحة الإدارة' : 'Admin console'}</p>
            <p className="text-xs text-muted-foreground">{locale === 'ar' ? 'تحكم كامل وآمن' : 'Secure control center'}</p>
          </div>
        </div>
      </div>
      <nav className="grid gap-1">
        {adminNav.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.href}
              to={item.href}
              end={item.end}
              onClick={() => setOpen(false)}
              className={({ isActive }) => cn('flex items-center gap-3 rounded-2xl px-3 py-3 text-sm font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground', isActive && 'bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground')}
            >
              <Icon className="h-4 w-4" />
              {locale === 'ar' ? item.labelAr : item.labelEn}
            </NavLink>
          );
        })}
      </nav>
      <div className="mt-auto rounded-2xl border bg-muted/40 p-4 text-xs leading-6 text-muted-foreground">
        {locale === 'ar' ? 'كل عمليات الإدارة تمر عبر طبقة بيانات موحدة مع تحقق صلاحيات المشرف.' : 'Admin actions use the shared data layer with role-gated access.'}
      </div>
    </aside>
  );

  return (
    <section className="container py-6">
      <div className="mb-5 flex flex-col gap-3 rounded-3xl border bg-card p-4 shadow-card lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary">AI Hub Arabia</p>
            <h1 className="text-2xl font-black tracking-tight">{locale === 'ar' ? 'مركز التحكم الإداري' : 'Administration center'}</h1>
          </div>
          <Button className="lg:hidden" variant="outline" size="sm" onClick={() => setOpen(true)}><Menu className="h-5 w-5" /></Button>
        </div>
        <div className="grid gap-3 md:grid-cols-[minmax(16rem,24rem)_auto] md:items-center">
          <Input aria-label="Admin search" placeholder={locale === 'ar' ? 'بحث داخل لوحة الإدارة...' : 'Search admin console...'} className="h-10" />
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="warning"><Bell className="h-3.5 w-3.5" /> {notifications.filter((item) => !item.read).length}</Badge>
            <Badge variant="muted">{locale === 'ar' ? 'مراجعات' : 'Reviews'} {counts.pendingReviews}</Badge>
            <Badge variant="muted">{locale === 'ar' ? 'بلاغات' : 'Reports'} {counts.openReports}</Badge>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[19rem_minmax(0,1fr)]">
        <div className="hidden lg:block">{sidebar}</div>
        <div className="min-w-0"><Outlet /></div>
      </div>

      {open ? (
        <div className="fixed inset-0 z-50 bg-slate-950/60 p-4 backdrop-blur-sm lg:hidden">
          <Card className="ml-auto h-full max-w-sm overflow-y-auto p-4">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-bold"><Tags className="h-4 w-4" /> {locale === 'ar' ? 'تنقل الإدارة' : 'Admin navigation'}</div>
              <Button size="sm" variant="ghost" onClick={() => setOpen(false)}><X className="h-5 w-5" /></Button>
            </div>
            {sidebar}
          </Card>
        </div>
      ) : null}
    </section>
  );
}
