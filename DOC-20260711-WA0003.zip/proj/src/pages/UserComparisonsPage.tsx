import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, GitCompare, Pencil, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { EmptyState } from '@/components/feedback/EmptyState';
import { deleteUserComparison, getUserComparisonsWithTools, renameUserComparison } from '@/services/userWorkspaceService';
import type { UserComparisonWithTools } from '@/services/userWorkspaceService';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import { pricingLabel } from '@/utils/format';

export function UserComparisonsPage() {
  const { locale } = useLocale();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [comparisons, setComparisons] = useState<UserComparisonWithTools[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftName, setDraftName] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  useSeo(locale === 'ar' ? 'مقارناتي' : 'My comparisons');

  useEffect(() => {
    if (!user) return;
    let mounted = true;
    setIsLoading(true);
    getUserComparisonsWithTools(user.id)
      .then((items) => {
        if (mounted) setComparisons(items);
      })
      .finally(() => {
        if (mounted) setIsLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, [user]);

  async function saveName(comparisonId: string) {
    if (!user) return;
    const updated = await renameUserComparison(user.id, comparisonId, draftName);
    setComparisons((current) => current.map((item) => item.id === updated.id ? { ...item, name: updated.name, updatedAt: updated.updatedAt } : item));
    setEditingId(null);
    showToast({ title: locale === 'ar' ? 'تم تحديث اسم المقارنة' : 'Comparison renamed', tone: 'success' });
  }

  async function removeComparison(comparisonId: string) {
    if (!user) return;
    await deleteUserComparison(user.id, comparisonId);
    setComparisons((current) => current.filter((comparison) => comparison.id !== comparisonId));
    showToast({ title: locale === 'ar' ? 'تم حذف المقارنة' : 'Comparison deleted', tone: 'success' });
  }

  function compareUrl(comparison: UserComparisonWithTools) {
    const params = comparison.tools.map((tool) => `tool=${encodeURIComponent(tool.slug)}`).join('&');
    return `/compare${params ? `?${params}` : ''}`;
  }

  return (
    <div className="grid gap-6">
      <SectionHeader
        title={locale === 'ar' ? 'مقارناتي المحفوظة' : 'Saved comparisons'}
        description={locale === 'ar' ? 'حافظ على مجموعات المقارنة المهمة وافتحها لاحقًا بسرعة.' : 'Keep important comparison sets and reopen them quickly.'}
        action={<Link className="focus-ring inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground" to="/compare"><GitCompare className="h-4 w-4" /> {locale === 'ar' ? 'مقارنة جديدة' : 'New comparison'}</Link>}
      />

      {isLoading ? (
        <div className="grid gap-4">{Array.from({ length: 3 }).map((_, index) => <Skeleton key={index} className="h-40" />)}</div>
      ) : comparisons.length ? (
        <div className="grid gap-4">
          {comparisons.map((comparison) => (
            <Card key={comparison.id} className="p-5">
              <div className="grid gap-5 lg:grid-cols-[1fr_auto] lg:items-start">
                <div>
                  {editingId === comparison.id ? (
                    <div className="flex max-w-lg flex-col gap-2 sm:flex-row">
                      <Input value={draftName} onChange={(event) => setDraftName(event.target.value)} aria-label={locale === 'ar' ? 'اسم المقارنة' : 'Comparison name'} />
                      <Button onClick={() => saveName(comparison.id)}>{locale === 'ar' ? 'حفظ' : 'Save'}</Button>
                    </div>
                  ) : (
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-lg font-bold">{comparison.name}</h2>
                      <Badge variant="muted">{comparison.tools.length} {locale === 'ar' ? 'أدوات' : 'tools'}</Badge>
                    </div>
                  )}
                  <p className="mt-2 text-sm text-muted-foreground">{locale === 'ar' ? 'آخر تحديث:' : 'Updated:'} {new Date(comparison.updatedAt).toLocaleDateString(locale === 'ar' ? 'ar' : 'en')}</p>
                  <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                    {comparison.tools.map((tool) => (
                      <Link key={tool.id} className="rounded-2xl border p-4 transition hover:bg-muted" to={`/tools/${tool.slug}`}>
                        <div className={`mb-3 grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br ${tool.logoGradient} text-xs font-extrabold text-white`}>{tool.name.slice(0, 2).toUpperCase()}</div>
                        <p className="font-semibold">{tool.name}</p>
                        <p className="mt-1 text-xs text-muted-foreground">{pricingLabel(tool.pricing, locale)} · {tool.rating.toFixed(1)}/5</p>
                      </Link>
                    ))}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 lg:justify-end">
                  <Button variant="outline" onClick={() => { setEditingId(comparison.id); setDraftName(comparison.name); }}><Pencil className="h-4 w-4" /> {locale === 'ar' ? 'تسمية' : 'Rename'}</Button>
                  <Link className="focus-ring inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-background px-4 text-sm font-semibold transition hover:bg-muted" to={compareUrl(comparison)}><ExternalLink className="h-4 w-4" /> {locale === 'ar' ? 'فتح' : 'Open'}</Link>
                  <Button variant="ghost" onClick={() => removeComparison(comparison.id)}><Trash2 className="h-4 w-4" /> {locale === 'ar' ? 'حذف' : 'Delete'}</Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState title={locale === 'ar' ? 'لا توجد مقارنات محفوظة' : 'No saved comparisons'} description={locale === 'ar' ? 'أنشئ مقارنة بين أداتين أو أكثر ثم احفظها داخل حسابك.' : 'Create a comparison between two or more tools and save it to your account.'} action={<GitCompare className="h-5 w-5 text-primary" />} />
      )}
    </div>
  );
}
