import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Check, Minus, Plus, Save, Search, Trash2, X } from 'lucide-react';
import type { AITool } from '@/types';
import { EmptyState } from '@/components/feedback/EmptyState';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { getUserComparisons, saveComparison } from '@/services/comparisonService';
import { getTools } from '@/services/toolService';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import { categoryName, formatRating, pricingLabel } from '@/utils/format';
import { platformLabel } from '@/utils/toolNormalization';
import { normalizeSearchText } from '@/utils/searchUtils';

function intersectionCount(a: string[], b: string[]) {
  const lookup = new Set(a.map(normalizeSearchText));
  return b.filter((item) => lookup.has(normalizeSearchText(item))).length;
}

export function ComparePage() {
  const { locale } = useLocale();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [searchParams] = useSearchParams();
  const [allTools, setAllTools] = useState<AITool[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const selectedTools = useMemo(() => selectedIds.map((id) => allTools.find((tool) => tool.id === id)).filter(Boolean) as AITool[], [allTools, selectedIds]);
  const availableTools = useMemo(() => {
    const query = normalizeSearchText(search);
    return allTools
      .filter((tool) => !selectedIds.includes(tool.id))
      .filter((tool) => !query || normalizeSearchText([tool.name, tool.categorySlug, tool.pricing, ...(tool.platform ?? []), ...tool.tags].join(' ')).includes(query))
      .slice(0, 8);
  }, [allTools, search, selectedIds]);
  const sharedTags = useMemo(() => selectedTools.length ? Array.from(new Set(selectedTools.flatMap((tool) => tool.tags))).filter((tag) => selectedTools.every((tool) => tool.tags.map(normalizeSearchText).includes(normalizeSearchText(tag)))) : [], [selectedTools]);
  useSeo(locale === 'ar' ? 'مقارنة الأدوات' : 'Compare tools');

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);
    Promise.all([getTools({ status: 'active', sort: 'featured' }), user ? getUserComparisons(user.id) : Promise.resolve([])])
      .then(([tools, comparisons]) => {
        if (!isMounted) return;
        setAllTools(tools);
        const queryToolSlugs = searchParams.getAll('tool').filter(Boolean);
        const queryToolIds = queryToolSlugs
          .map((slug) => tools.find((tool) => tool.slug === slug)?.id)
          .filter(Boolean) as string[];
        const savedToolIds = comparisons[0]?.toolIds?.filter((toolId) => tools.some((tool) => tool.id === toolId)).slice(0, 4) ?? [];
        const fallbackIds = savedToolIds.length >= 2 ? savedToolIds : tools.slice(0, 3).map((tool) => tool.id);
        setSelectedIds(queryToolIds.length ? [...new Set([...queryToolIds, ...fallbackIds])].slice(0, 4) : fallbackIds);
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, [searchParams, user]);

  function addTool(toolId: string) {
    setSelectedIds((current) => {
      if (current.includes(toolId)) return current;
      if (current.length >= 4) {
        showToast({ title: locale === 'ar' ? 'الحد الأقصى 4 أدوات' : 'Maximum is 4 tools', tone: 'error' });
        return current;
      }
      return [...current, toolId];
    });
  }

  function removeTool(toolId: string) {
    setSelectedIds((current) => current.filter((id) => id !== toolId));
  }

  async function handleSaveComparison() {
    if (!user) {
      showToast({ title: locale === 'ar' ? 'سجّل الدخول أولًا' : 'Login required', description: locale === 'ar' ? 'يجب تسجيل الدخول لحفظ المقارنة.' : 'You need to sign in to save comparisons.', tone: 'error' });
      return;
    }
    if (selectedIds.length < 2) {
      showToast({ title: locale === 'ar' ? 'اختر أداتين على الأقل' : 'Select at least two tools', tone: 'error' });
      return;
    }
    await saveComparison(user.id, `Comparison ${new Date().toLocaleDateString('en-US')}`, selectedIds);
    showToast({ title: locale === 'ar' ? 'تم حفظ المقارنة' : 'Comparison saved', tone: 'success' });
  }

  return (
    <section className="section-padding">
      <div className="container">
        <SectionHeader
          eyebrow={locale === 'ar' ? 'مقارنة ذكية' : 'Smart comparison'}
          title={locale === 'ar' ? 'قارن بين أدوات الذكاء الاصطناعي' : 'Compare AI tools'}
          description={locale === 'ar' ? 'اختر من أداتين إلى أربع أدوات وقارن المميزات والأسعار والمنصات والتقييمات والوسوم المشتركة.' : 'Select two to four tools and compare features, pricing, platforms, ratings, and shared tags.'}
          action={<Button onClick={handleSaveComparison}><Save className="h-4 w-4" /> {locale === 'ar' ? 'حفظ المقارنة' : 'Save comparison'}</Button>}
        />

        {isLoading ? (
          <div className="grid gap-5 lg:grid-cols-3">{Array.from({ length: 3 }).map((_, index) => <Skeleton key={index} className="h-72" />)}</div>
        ) : (
          <>
            <Card className="mb-8 p-5">
              <div className="grid gap-4 lg:grid-cols-[1fr_2fr]">
                <div>
                  <h2 className="text-lg font-bold">{locale === 'ar' ? 'إضافة أداة للمقارنة' : 'Add a tool to compare'}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{locale === 'ar' ? 'ابحث بالاسم أو التصنيف أو الوسم أو المنصة.' : 'Search by name, category, tag, or platform.'}</p>
                </div>
                <div>
                  <div className="relative">
                    <Search className="absolute start-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input className="px-10" placeholder={locale === 'ar' ? 'ابحث داخل أدوات المقارنة...' : 'Search comparison tools...'} value={search} onChange={(event) => setSearch(event.target.value)} />
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {availableTools.map((tool) => (
                      <button key={tool.id} className="inline-flex items-center gap-2 rounded-full border px-3 py-2 text-sm transition hover:bg-muted" type="button" onClick={() => addTool(tool.id)}>
                        <Plus className="h-3.5 w-3.5" /> {tool.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            {selectedTools.length ? (
              <>
                <div className="mb-8 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
                  {selectedTools.map((tool) => (
                    <Card key={tool.id} className="p-5">
                      <div className={`mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${tool.logoGradient} text-sm font-extrabold text-white`}>{tool.name.slice(0, 2).toUpperCase()}</div>
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="font-bold">{tool.name}</h3>
                          <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{locale === 'ar' ? tool.taglineAr : tool.taglineEn}</p>
                        </div>
                        <button className="rounded-full p-2 text-muted-foreground transition hover:bg-muted hover:text-destructive" type="button" onClick={() => removeTool(tool.id)} aria-label="Remove tool"><X className="h-4 w-4" /></button>
                      </div>
                    </Card>
                  ))}
                </div>

                <Card className="overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[900px] text-sm">
                      <thead className="bg-muted text-muted-foreground">
                        <tr>
                          <th className="p-4 text-start">{locale === 'ar' ? 'المعيار' : 'Criteria'}</th>
                          {selectedTools.map((tool) => <th key={tool.id} className="p-4 text-start">{tool.name}</th>)}
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-t"><td className="p-4 font-semibold">{locale === 'ar' ? 'السعر' : 'Pricing'}</td>{selectedTools.map((tool) => <td key={tool.id} className="p-4">{pricingLabel(tool.pricing, locale)}</td>)}</tr>
                        <tr className="border-t"><td className="p-4 font-semibold">{locale === 'ar' ? 'المنصات' : 'Platforms'}</td>{selectedTools.map((tool) => <td key={tool.id} className="p-4"><div className="flex flex-wrap gap-1">{(tool.platform ?? ['web']).map((platform) => <Badge key={platform} variant="muted">{platformLabel(platform, locale)}</Badge>)}</div></td>)}</tr>
                        <tr className="border-t"><td className="p-4 font-semibold">{locale === 'ar' ? 'التقييم' : 'Rating'}</td>{selectedTools.map((tool) => <td key={tool.id} className="p-4">{tool.rating.toFixed(1)} / 5</td>)}</tr>
                        <tr className="border-t"><td className="p-4 font-semibold">{locale === 'ar' ? 'عدد المراجعات' : 'Reviews'}</td>{selectedTools.map((tool) => <td key={tool.id} className="p-4">{tool.reviewsCount ?? 0}</td>)}</tr>
                        <tr className="border-t"><td className="p-4 font-semibold">{locale === 'ar' ? 'التصنيف' : 'Category'}</td>{selectedTools.map((tool) => <td key={tool.id} className="p-4">{categoryName(tool.categorySlug, locale)}</td>)}</tr>
                        <tr className="border-t"><td className="p-4 font-semibold">{locale === 'ar' ? 'المميزات' : 'Features'}</td>{selectedTools.map((tool) => <td key={tool.id} className="p-4"><ul className="grid gap-2">{(locale === 'ar' ? tool.featuresAr : tool.featuresEn).slice(0, 4).map((feature) => <li key={feature} className="flex items-start gap-2"><Check className="mt-0.5 h-3.5 w-3.5 text-primary" />{feature}</li>)}</ul></td>)}</tr>
                        <tr className="border-t"><td className="p-4 font-semibold">{locale === 'ar' ? 'الوسوم المشتركة' : 'Shared tags'}</td>{selectedTools.map((tool) => <td key={tool.id} className="p-4">{intersectionCount(sharedTags, tool.tags) ? <div className="flex flex-wrap gap-1">{sharedTags.map((tag) => <Badge key={tag} variant="success">{tag}</Badge>)}</div> : <Badge variant="muted"><Minus className="h-3.5 w-3.5" /> {locale === 'ar' ? 'لا يوجد' : 'None'}</Badge>}</td>)}</tr>
                      </tbody>
                    </table>
                  </div>
                </Card>

                <div className="mt-5 flex justify-end">
                  <Button variant="outline" onClick={() => setSelectedIds([])}><Trash2 className="h-4 w-4" /> {locale === 'ar' ? 'مسح المقارنة' : 'Clear comparison'}</Button>
                </div>
              </>
            ) : (
              <EmptyState title={locale === 'ar' ? 'لا توجد أدوات للمقارنة' : 'No tools selected'} description={locale === 'ar' ? 'أضف أداتين على الأقل من مربع البحث أعلاه.' : 'Add at least two tools from the search box above.'} />
            )}
          </>
        )}
      </div>
    </section>
  );
}
