import { useEffect, useState } from 'react';
import { Activity, BarChart3, Bell, Heart, MessageSquareText, Search, Scale, ShieldCheck } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import type { DashboardData } from '@/types/database';
import { ToolCard } from '@/components/domain/ToolCard';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { StatCard } from '@/components/ui/StatCard';
import { useToast } from '@/components/ui/Toast';
import { getUserDashboardData } from '@/services/dashboardService';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

export function UserDashboardPage() {
  const { locale } = useLocale();
  const { user, logout } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  useSeo(locale === 'ar' ? 'لوحة المستخدم' : 'User dashboard');

  const icons = [<Heart className="h-5 w-5" />, <Scale className="h-5 w-5" />, <Activity className="h-5 w-5" />, <BarChart3 className="h-5 w-5" />];
  const denied = Boolean((location.state as { denied?: boolean } | null)?.denied);

  useEffect(() => {
    if (!user) return;
    let isMounted = true;
    setIsLoading(true);
    getUserDashboardData(user.id)
      .then((data) => {
        if (isMounted) setDashboardData(data);
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, [user]);

  const handleLogout = async () => {
    await logout();
    showToast({ title: locale === 'ar' ? 'تم تسجيل الخروج' : 'Signed out', tone: 'success' });
    navigate('/');
  };

  return (
    <div className="grid gap-8">
      {denied ? (
        <Card className="flex flex-wrap items-center justify-between gap-4 border-amber-300 bg-amber-50 p-4 text-amber-900 dark:border-amber-700 dark:bg-amber-950/30 dark:text-amber-200">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-5 w-5" />
            <p className="text-sm font-semibold">{locale === 'ar' ? 'لا تملك صلاحية الدخول إلى لوحة الإدارة.' : 'You do not have permission to access the admin dashboard.'}</p>
          </div>
          <Link className="text-sm font-bold underline" to="/profile">{locale === 'ar' ? 'راجع إعدادات الحساب' : 'Review account settings'}</Link>
        </Card>
      ) : null}

      <SectionHeader
        title={locale === 'ar' ? `مرحبًا، ${user?.name ?? 'مستخدم'}` : `Welcome, ${user?.name ?? 'User'}`}
        description={locale === 'ar' ? 'لوحة المستخدم تقرأ الآن إحصاءات الحساب، المفضلة، المقارنات، والتنبيهات من طبقة البيانات.' : 'The user dashboard now reads account stats, favorites, comparisons, and notifications from the data layer.'}
        action={<Link className="focus-ring inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground" to="/search"><Search className="h-4 w-4" /> {locale === 'ar' ? 'بحث جديد' : 'New search'}</Link>}
      />

      <Card className="grid gap-4 p-5 md:grid-cols-[1fr_auto] md:items-center">
        <div>
          <p className="text-sm font-semibold text-primary">{locale === 'ar' ? 'حالة الجلسة' : 'Session status'}</p>
          <h2 className="mt-1 text-xl font-bold">{locale === 'ar' ? 'جلسة نشطة ومحمية' : 'Active protected session'}</h2>
          <p className="mt-1 text-sm text-muted-foreground">{locale === 'ar' ? `الصلاحية الحالية: ${user?.role === 'admin' ? 'مدير النظام' : 'مستخدم'}` : `Current role: ${user?.role === 'admin' ? 'Administrator' : 'User'}`}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => navigate('/profile')}>{locale === 'ar' ? 'تعديل الحساب' : 'Edit account'}</Button>
          <Button variant="ghost" onClick={handleLogout}>{locale === 'ar' ? 'تسجيل الخروج' : 'Logout'}</Button>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-3">
        {[
          { href: '/favorites', icon: <Heart className="h-5 w-5" />, ar: 'إدارة المفضلة', en: 'Manage favorites' },
          { href: '/my-comparisons', icon: <Scale className="h-5 w-5" />, ar: 'مقارناتي', en: 'My comparisons' },
          { href: '/my-reviews', icon: <MessageSquareText className="h-5 w-5" />, ar: 'مراجعاتي', en: 'My reviews' },
        ].map((item) => (
          <Link key={item.href} className="focus-ring flex items-center justify-between gap-3 rounded-2xl border bg-card p-5 font-semibold shadow-card transition hover:-translate-y-0.5 hover:bg-muted" to={item.href}>
            <span className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">{item.icon}</span>{locale === 'ar' ? item.ar : item.en}</span>
          </Link>
        ))}
      </div>

      {isLoading || !dashboardData ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 4 }).map((_, index) => <Skeleton key={index} className="h-32" />)}</div>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {dashboardData.stats.map((stat, index) => <StatCard key={stat.labelEn} label={locale === 'ar' ? stat.labelAr : stat.labelEn} value={stat.value} change={stat.change} icon={icons[index]} />)}
          </div>
          <div className="grid gap-6 xl:grid-cols-[1fr_22rem]">
            <div>
              <h2 className="mb-4 text-xl font-bold">{locale === 'ar' ? 'اقتراحات مناسبة لك' : 'Recommended for you'}</h2>
              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{dashboardData.recommendedTools.map((tool) => <ToolCard key={tool.id} tool={tool} compact />)}</div>
            </div>
            <div className="grid gap-5">
              <Card className="p-5">
                <h2 className="mb-4 text-xl font-bold">{locale === 'ar' ? 'آخر النشاط' : 'Recent activity'}</h2>
                <div className="grid gap-4">
                  {dashboardData.recentActivity.map((activity) => <div key={`${activity.time}-${activity.en}`} className="rounded-2xl bg-muted p-4"><Badge className="mb-2" variant="muted">{activity.time}</Badge><p className="text-sm text-muted-foreground">{locale === 'ar' ? activity.ar : activity.en}</p></div>)}
                </div>
              </Card>
              <Card className="p-5">
                <h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><Bell className="h-5 w-5 text-primary" /> {locale === 'ar' ? 'التنبيهات' : 'Notifications'}</h2>
                <div className="grid gap-3">
                  {dashboardData.notifications.map((notification) => <div key={notification.id} className="rounded-2xl border p-3"><p className="font-semibold">{locale === 'ar' ? notification.titleAr : notification.titleEn}</p><p className="mt-1 text-sm text-muted-foreground">{locale === 'ar' ? notification.bodyAr : notification.bodyEn}</p></div>)}
                </div>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
