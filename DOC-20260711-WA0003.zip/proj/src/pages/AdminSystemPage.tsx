import { useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, CheckCircle2, Database, FileSearch, Gauge, LockKeyhole, RefreshCw } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { StatCard } from '@/components/ui/StatCard';
import { useToast } from '@/components/ui/Toast';
import { getSystemHealthSummary } from '@/services/systemHealthService';
import type { SystemHealthSummary, SystemHealthStatus } from '@/services/systemHealthService';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

function statusLabel(status: SystemHealthStatus, locale: 'ar' | 'en') {
  const labels = {
    healthy: { ar: 'سليم', en: 'Healthy' },
    attention: { ar: 'يحتاج متابعة', en: 'Needs attention' },
    critical: { ar: 'حرج', en: 'Critical' },
  };
  return labels[status][locale];
}

function statusVariant(status: SystemHealthStatus) {
  if (status === 'healthy') return 'success' as const;
  if (status === 'attention') return 'warning' as const;
  return 'muted' as const;
}

export function AdminSystemPage() {
  const { locale } = useLocale();
  const { showToast } = useToast();
  const [summary, setSummary] = useState<SystemHealthSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  useSeo(locale === 'ar' ? 'صحة النظام' : 'System health');

  const loadSummary = async () => {
    setIsLoading(true);
    try {
      const data = await getSystemHealthSummary();
      setSummary(data);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadSummary();
  }, []);

  const stats = useMemo(() => {
    if (!summary) return [];
    return [
      { label: locale === 'ar' ? 'درجة الجاهزية' : 'Readiness score', value: `${summary.score}%`, icon: <Gauge className="h-5 w-5" /> },
      { label: locale === 'ar' ? 'الأدوات' : 'Tools', value: String(summary.counters.tools), icon: <Database className="h-5 w-5" /> },
      { label: locale === 'ar' ? 'مراجعات معلقة' : 'Pending reviews', value: String(summary.counters.pendingReviews), icon: <FileSearch className="h-5 w-5" /> },
      { label: locale === 'ar' ? 'أحداث التدقيق' : 'Audit events', value: String(summary.counters.auditLogs), icon: <Activity className="h-5 w-5" /> },
    ];
  }, [locale, summary]);

  const refresh = async () => {
    await loadSummary();
    showToast({ title: locale === 'ar' ? 'تم تحديث حالة النظام' : 'System status refreshed', tone: 'success' });
  };

  return (
    <div className="grid gap-6">
      <SectionHeader
        eyebrow={locale === 'ar' ? 'المرحلة 13' : 'Phase 13'}
        title={locale === 'ar' ? 'صحة النظام وجاهزية الإطلاق' : 'System health and launch readiness'}
        description={locale === 'ar' ? 'مراجعة موحدة للأمان، البيانات، SEO/PWA، قائمة المراجعة، وسجل التدقيق.' : 'A unified review of security, data, SEO/PWA, moderation queues, and audit events.'}
        action={<Button variant="outline" onClick={refresh} disabled={isLoading}><RefreshCw className="h-4 w-4" /> {locale === 'ar' ? 'تحديث' : 'Refresh'}</Button>}
      />

      {isLoading || !summary ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 4 }).map((_, index) => <Skeleton key={index} className="h-32" />)}</div>
      ) : (
        <>
          <Card className="overflow-hidden p-6">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <Badge variant={statusVariant(summary.status)}>{statusLabel(summary.status, locale)}</Badge>
                <h2 className="mt-3 text-3xl font-black tracking-tight">{summary.score}%</h2>
                <p className="mt-1 max-w-2xl text-sm leading-6 text-muted-foreground">
                  {locale === 'ar' ? 'هذه الدرجة مبنية على فحوصات داخلية للبيانات، الأمان، المراجعات، إعدادات SEO/PWA، وسجل التدقيق.' : 'This score is based on internal checks for data, security, moderation, SEO/PWA settings, and audit logs.'}
                </p>
              </div>
              <div className="rounded-3xl border bg-muted/50 p-4 text-sm text-muted-foreground">
                <p><strong className="text-foreground">{locale === 'ar' ? 'قاعدة البيانات:' : 'Database:'}</strong> {summary.database.version}</p>
                <p><strong className="text-foreground">{locale === 'ar' ? 'المحول:' : 'Adapter:'}</strong> {summary.database.storage}</p>
                <p><strong className="text-foreground">{locale === 'ar' ? 'المجموعات:' : 'Collections:'}</strong> {summary.database.collections.length}</p>
              </div>
            </div>
          </Card>

          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {stats.map((stat) => <StatCard key={stat.label} label={stat.label} value={stat.value} change={locale === 'ar' ? 'مباشر' : 'live'} icon={stat.icon} />)}
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            {summary.checks.map((check) => (
              <Card key={check.id} className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <span className="grid h-11 w-11 place-items-center rounded-2xl bg-primary/10 text-primary">
                      {check.status === 'healthy' ? <CheckCircle2 className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}
                    </span>
                    <div>
                      <h3 className="font-bold">{locale === 'ar' ? check.labelAr : check.labelEn}</h3>
                      <p className="mt-1 text-sm leading-6 text-muted-foreground">{locale === 'ar' ? check.descriptionAr : check.descriptionEn}</p>
                    </div>
                  </div>
                  <Badge variant={statusVariant(check.status)}>{check.score}%</Badge>
                </div>
              </Card>
            ))}
          </div>

          <Card className="overflow-hidden">
            <div className="flex items-center justify-between border-b p-5">
              <div className="flex items-center gap-2"><LockKeyhole className="h-5 w-5 text-primary" /><h2 className="text-xl font-bold">{locale === 'ar' ? 'سجل التدقيق الأخير' : 'Recent audit log'}</h2></div>
              <Badge variant="muted">{summary.auditLogs.length}</Badge>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-sm">
                <thead className="bg-muted text-muted-foreground">
                  <tr>
                    <th className="p-4 text-start">{locale === 'ar' ? 'الحدث' : 'Event'}</th>
                    <th className="p-4 text-start">{locale === 'ar' ? 'الشدة' : 'Severity'}</th>
                    <th className="p-4 text-start">{locale === 'ar' ? 'المورد' : 'Resource'}</th>
                    <th className="p-4 text-start">{locale === 'ar' ? 'التاريخ' : 'Date'}</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.auditLogs.slice(0, 10).map((log) => (
                    <tr key={log.id} className="border-t">
                      <td className="p-4 font-semibold">{log.event}</td>
                      <td className="p-4"><Badge variant={log.severity === 'info' ? 'muted' : log.severity === 'warning' ? 'warning' : 'default'}>{log.severity}</Badge></td>
                      <td className="p-4 text-muted-foreground">{log.resource ?? '-'}</td>
                      <td className="p-4 text-muted-foreground">{new Date(log.createdAt).toLocaleString(locale === 'ar' ? 'ar' : 'en')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
