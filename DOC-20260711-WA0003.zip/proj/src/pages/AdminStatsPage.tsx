import { useEffect, useState } from 'react';
import { Activity, BarChart3, Boxes, Eye, Star, Tags, UsersRound } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { StatCard } from '@/components/ui/StatCard';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import { getAdminOverviewStats, type AdminOverviewStats } from '@/services/adminService';

export function AdminStatsPage() {
  const { locale } = useLocale();
  const [stats, setStats] = useState<AdminOverviewStats | null>(null);
  useSeo(locale === 'ar' ? 'إحصائيات الإدارة' : 'Admin analytics');

  useEffect(() => {
    getAdminOverviewStats().then(setStats).catch(() => undefined);
  }, []);

  if (!stats) return <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 8 }).map((_, index) => <Skeleton key={index} className="h-32" />)}</div>;

  const categoryTotal = Math.max(stats.activeCategories.reduce((sum, category) => sum + category.toolsCount, 0), 1);

  return (
    <div className="grid gap-6">
      <SectionHeader title={locale === 'ar' ? 'الإحصائيات والتحليلات' : 'Statistics and analytics'} description={locale === 'ar' ? 'مؤشرات تشغيلية للمنصة تشمل المستخدمين، الأدوات، التصنيفات، التقييمات، الزيارات، والأدوات الأكثر نشاطًا.' : 'Operational indicators for users, tools, categories, reviews, visits, and active tools.'} />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard label={locale === 'ar' ? 'المستخدمون' : 'Users'} value={String(stats.usersCount)} change={`${stats.activeUsersCount} active`} icon={<UsersRound className="h-5 w-5" />} />
        <StatCard label={locale === 'ar' ? 'الأدوات' : 'Tools'} value={String(stats.toolsCount)} change={`${stats.activeToolsCount} listed`} icon={<Boxes className="h-5 w-5" />} />
        <StatCard label={locale === 'ar' ? 'التقييمات' : 'Reviews'} value={String(stats.reviewsCount)} change={`${stats.pendingReviewsCount} pending`} icon={<Star className="h-5 w-5" />} />
        <StatCard label={locale === 'ar' ? 'الزيارات' : 'Visits'} value={stats.visitsCount.toLocaleString()} change="dashboard metric" icon={<Eye className="h-5 w-5" />} />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_24rem]">
        <Card className="p-5">
          <div className="mb-5 flex items-center gap-2"><BarChart3 className="h-5 w-5 text-primary" /><h2 className="text-xl font-bold">{locale === 'ar' ? 'نشاط التصنيفات' : 'Category activity'}</h2></div>
          <div className="grid gap-4">
            {stats.activeCategories.map((category) => {
              const width = Math.max(8, Math.round((category.toolsCount / categoryTotal) * 100));
              return (
                <div key={category.slug}>
                  <div className="mb-2 flex items-center justify-between text-sm"><span className="font-semibold">{locale === 'ar' ? category.nameAr : category.nameEn}</span><span className="text-muted-foreground">{category.toolsCount}</span></div>
                  <div className="h-3 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary" style={{ width: `${width}%` }} /></div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-5">
          <div className="mb-5 flex items-center gap-2"><Activity className="h-5 w-5 text-primary" /><h2 className="text-xl font-bold">{locale === 'ar' ? 'حالة النظام' : 'System health'}</h2></div>
          <div className="grid gap-3">
            <div className="rounded-2xl border p-4"><Badge variant="success">99.9%</Badge><p className="mt-2 font-bold">{locale === 'ar' ? 'جاهزية الواجهة' : 'Frontend availability'}</p></div>
            <div className="rounded-2xl border p-4"><Badge variant="success">0</Badge><p className="mt-2 font-bold">{locale === 'ar' ? 'ثغرات إنتاجية' : 'Production vulnerabilities'}</p></div>
            <div className="rounded-2xl border p-4"><Badge variant="warning">local adapter</Badge><p className="mt-2 font-bold">{locale === 'ar' ? 'قاعدة البيانات الحالية' : 'Current database'}</p></div>
          </div>
        </Card>
      </div>

      <Card className="p-5">
        <div className="mb-4 flex items-center gap-2"><Tags className="h-5 w-5 text-primary" /><h2 className="text-xl font-bold">{locale === 'ar' ? 'الأدوات الأعلى نشاطًا' : 'Top performing tools'}</h2></div>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
          {stats.topTools.map((tool) => <div key={tool.id} className="rounded-2xl border p-4"><p className="font-bold">{tool.name}</p><p className="mt-2 text-sm text-muted-foreground">{tool.users} · ★ {tool.rating}</p></div>)}
        </div>
      </Card>
    </div>
  );
}
