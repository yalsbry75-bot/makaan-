import { useEffect, useState } from 'react';
import { Search, Sparkles, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { ToolCategory } from '@/types';
import { CategoryCard } from '@/components/domain/CategoryCard';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { SearchBar } from '@/components/ui/SearchBar';
import { Skeleton } from '@/components/ui/Skeleton';
import { getCategories } from '@/services/toolService';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

const popular = ['Arabic writing', 'image generator', 'coding assistant', 'meeting summary', 'data dashboard'];

export function SearchPage() {
  const { locale } = useLocale();
  const [categories, setCategories] = useState<ToolCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  useSeo(locale === 'ar' ? 'البحث' : 'Search');

  useEffect(() => {
    let isMounted = true;
    getCategories()
      .then((loadedCategories) => {
        if (isMounted) setCategories(loadedCategories);
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <section className="section-padding">
      <div className="container">
        <div className="mx-auto max-w-4xl text-center">
          <Badge className="mb-4"><Search className="h-3.5 w-3.5" /> {locale === 'ar' ? 'بحث متقدم' : 'Advanced search'}</Badge>
          <h1 className="text-4xl font-extrabold md:text-5xl">{locale === 'ar' ? 'ابحث عن الأداة المناسبة' : 'Search for the right tool'}</h1>
          <p className="mt-4 text-muted-foreground">{locale === 'ar' ? 'ابحث باسم الأداة، التصنيف، الوسوم، السعر، المنصة، أو الكلمات المفتاحية.' : 'Search by tool name, category, tags, pricing, platform, or keywords.'}</p>
          <SearchBar className="mt-8" showButton />
        </div>

        <div className="mt-10 grid gap-5 lg:grid-cols-[1fr_22rem]">
          <Card className="p-6">
            <div className="mb-5 flex items-center gap-2"><TrendingUp className="h-5 w-5 text-primary" /><h2 className="font-bold">{locale === 'ar' ? 'عمليات بحث شائعة' : 'Popular searches'}</h2></div>
            <div className="flex flex-wrap gap-2">
              {popular.map((item) => <Link key={item} className="rounded-full border px-4 py-2 text-sm transition hover:bg-muted" to={`/search/results?q=${encodeURIComponent(item)}`}>{item}</Link>)}
            </div>
          </Card>
          <Card className="p-6">
            <div className="mb-5 flex items-center gap-2"><Sparkles className="h-5 w-5 text-accent" /><h2 className="font-bold">{locale === 'ar' ? 'يدعم البحث' : 'Search supports'}</h2></div>
            <div className="grid gap-2 text-sm text-muted-foreground">
              <span>{locale === 'ar' ? 'التصنيف والسعر والمنصة' : 'Category, pricing, and platform'}</span>
              <span>{locale === 'ar' ? 'الوسوم وحالات الاستخدام' : 'Tags and use cases'}</span>
              <span>{locale === 'ar' ? 'الترتيب والتقييم' : 'Sorting and rating filters'}</span>
            </div>
          </Card>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {isLoading ? Array.from({ length: 4 }).map((_, index) => <Skeleton key={index} className="h-56" />) : categories.slice(0, 4).map((category) => <CategoryCard key={category.id} category={category} />)}
        </div>
      </div>
    </section>
  );
}
