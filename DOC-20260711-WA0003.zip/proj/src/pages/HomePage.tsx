import { useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, Gem, Layers3, PlayCircle, Rocket, ShieldCheck, Sparkles, Wand2, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import { CategoryCard } from '@/components/domain/CategoryCard';
import { ToolCard } from '@/components/domain/ToolCard';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { SearchBar } from '@/components/ui/SearchBar';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { StatCard } from '@/components/ui/StatCard';
import { heroMetrics } from '@/constants/catalogSeed';
import { getCategories, getFeaturedTools, getLatestTools, getMostUsedTools, getTools } from '@/services/toolService';
import type { AITool, ToolCategory } from '@/types';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

const steps = [
  { ar: 'ابحث عن الاحتياج', en: 'Search by need' },
  { ar: 'راجع التصنيف والتقييم', en: 'Review category and rating' },
  { ar: 'قارن الأدوات المناسبة', en: 'Compare shortlisted tools' },
  { ar: 'احفظ اختيارك في حسابك', en: 'Save the best fit' },
];

const whyUs = [
  { icon: ShieldCheck, ar: { title: 'مراجعة موثوقة', body: 'كل أداة تخضع لمعايير جودة وتقييمات حقيقية قبل ظهورها في الدليل.' }, en: { title: 'Vetted quality', body: 'Every tool is reviewed against real quality signals before it appears in the directory.' } },
  { icon: Zap, ar: { title: 'بحث فوري وذكي', body: 'محرك بحث يفهم الأخطاء الإملائية والمرادفات ويقترح النتائج الأقرب فورًا.' }, en: { title: 'Instant smart search', body: 'A search engine that understands typos and synonyms, surfacing the closest match instantly.' } },
  { icon: Gem, ar: { title: 'تجربة عربية أولاً', body: 'واجهة ثنائية اللغة مصممة خصيصًا لتجربة عربية سلسة، وليست ترجمة لواجهة أجنبية.' }, en: { title: 'Arabic-first experience', body: 'A bilingual interface designed for a fluent Arabic experience — not a translated afterthought.' } },
  { icon: Rocket, ar: { title: 'تحديث مستمر', body: 'إضافة أدوات جديدة وتحديث البيانات القائمة بشكل دوري لتبقى المنصة حديثة.' }, en: { title: 'Always current', body: 'New tools and refreshed data land regularly, so the catalog never feels stale.' } },
];

const faqItems = [
  { ar: { q: 'هل استخدام AI Hub Arabia مجاني؟', a: 'نعم، تصفح الدليل والمقارنة بين الأدوات مجاني بالكامل. بعض الأدوات المدرجة قد تكون مدفوعة من مزوّديها الأصليين.' }, en: { q: 'Is AI Hub Arabia free to use?', a: 'Yes, browsing the directory and comparing tools is completely free. Some listed tools may have their own paid plans from their original providers.' } },
  { ar: { q: 'كيف يتم اختيار الأدوات المضافة؟', a: 'نراجع كل أداة من حيث الاستقرار، جودة الاستخدام، والقيمة الفعلية قبل نشرها في أي تصنيف.' }, en: { q: 'How are new tools selected?', a: 'Every tool is reviewed for reliability, usability, and real-world value before being published under a category.' } },
  { ar: { q: 'هل يمكنني اقتراح أداة جديدة؟', a: 'بالتأكيد، يمكنك التواصل معنا من صفحة التواصل واقتراح أي أداة تراها مناسبة للمنصة.' }, en: { q: 'Can I suggest a new tool?', a: 'Absolutely — reach out through the contact page and suggest any tool you think belongs on the platform.' } },
  { ar: { q: 'هل بياناتي وحسابي محميان؟', a: 'نعم، نستخدم قواعد أمان صارمة على مستوى قاعدة البيانات لضمان أن كل مستخدم يصل فقط إلى بياناته الخاصة.' }, en: { q: 'Is my account and data secure?', a: 'Yes — strict database-level security rules ensure every user can only access their own data.' } },
];

export function HomePage() {
  const { locale, direction, t } = useLocale();
  const ArrowIcon = direction === 'rtl' ? ArrowLeft : ArrowRight;
  const [tools, setTools] = useState<AITool[]>([]);
  const [featuredTools, setFeaturedTools] = useState<AITool[]>([]);
  const [latestTools, setLatestTools] = useState<AITool[]>([]);
  const [mostUsedTools, setMostUsedTools] = useState<AITool[]>([]);
  const [categories, setCategories] = useState<ToolCategory[]>([]);
  useSeo(locale === 'ar' ? 'الرئيسية' : 'Home');

  useEffect(() => {
    let isMounted = true;
    Promise.all([
      getTools({ sort: 'top-rated', limit: 4 }),
      getFeaturedTools(),
      getCategories(),
      getLatestTools(3),
      getMostUsedTools(3),
    ]).then(([loadedTools, loadedFeaturedTools, loadedCategories, loadedLatest, loadedMostUsed]) => {
      if (!isMounted) return;
      setTools(loadedTools);
      setFeaturedTools(loadedFeaturedTools);
      setCategories(loadedCategories);
      setLatestTools(loadedLatest);
      setMostUsedTools(loadedMostUsed);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <>
      <section className="relative overflow-hidden border-b border-white/10">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_left,rgba(16,185,129,0.20),transparent_36%),radial-gradient(circle_at_bottom_right,rgba(242,194,74,0.14),transparent_32%)]" />
        <div className="absolute -top-24 start-1/2 -z-10 h-72 w-72 -translate-x-1/2 animate-float rounded-full bg-primary-500/20 blur-3xl" />
        <div className="container grid gap-10 py-20 md:py-28 lg:grid-cols-[1.05fr_.95fr] lg:items-center">
          <div className="animate-fade-up">
            <Badge variant="success" className="mb-5"><Sparkles className="me-1 h-3.5 w-3.5" /> {locale === 'ar' ? 'الجيل الجديد من دليل أدوات الذكاء الاصطناعي' : 'The next generation AI tools directory'}</Badge>
            <h1 className="max-w-4xl text-4xl font-extrabold tracking-tight md:text-6xl">
              {locale === 'ar' ? 'اكتشف أدوات الذكاء الاصطناعي المناسبة لعملك بسرعة.' : 'Discover the right AI tools for your workflow faster.'}
              <span className="block gold-text">AI Hub Arabia</span>
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-muted-foreground">
              {locale === 'ar'
                ? 'منصة SaaS عربية وإنجليزية لتصفح الأدوات، البحث داخل التصنيفات، المقارنة، وإدارة الأدوات المفضلة من مكان واحد.'
                : 'A bilingual SaaS interface to browse tools, search categories, compare options, and manage saved tools from one place.'}
            </p>
            <div className="mt-8 max-w-2xl"><SearchBar showButton /></div>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link className="focus-ring btn-gold inline-flex h-12 items-center justify-center gap-2 rounded-xl px-6 text-base font-bold" to="/tools">
                {t('common.exploreTools')} <ArrowIcon className="h-5 w-5" />
              </Link>
              <Link className="focus-ring inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/[0.03] px-6 text-base font-semibold backdrop-blur transition hover:bg-white/[0.08]" to="/compare">
                {locale === 'ar' ? 'جرّب المقارنة' : 'Try comparison'}
              </Link>
            </div>
          </div>
          <Card className="glass-panel p-5">
            <div className="rounded-3xl bg-gradient-to-br from-primary-500/15 via-transparent to-accent/10 p-5">
              <div className="mb-5 flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{locale === 'ar' ? 'لوحة اكتشاف مباشرة' : 'Live discovery panel'}</p>
                  <h2 className="text-xl font-extrabold">{locale === 'ar' ? 'الأدوات الأعلى طلبًا' : 'Top requested tools'}</h2>
                </div>
                <PlayCircle className="h-9 w-9 text-accent" />
              </div>
              <div className="grid gap-4">
                {tools.slice(0, 4).map((tool) => (
                  <Link key={tool.id} to={`/tools/${tool.slug}`} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 shadow-card backdrop-blur transition hover:-translate-y-0.5 hover:border-primary-400/30">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <span className={`grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br ${tool.logoGradient} text-xs font-extrabold text-white`}>{tool.name.slice(0, 2)}</span>
                        <div>
                          <h3 className="font-bold">{tool.name}</h3>
                          <p className="mt-1 text-sm text-muted-foreground">{locale === 'ar' ? tool.taglineAr : tool.taglineEn}</p>
                        </div>
                      </div>
                      <Badge>{tool.rating}</Badge>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </section>

      <section className="section-padding">
        <div className="container grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {heroMetrics.map((metric) => <StatCard key={metric.value} label={locale === 'ar' ? metric.labelAr : metric.labelEn} value={metric.value} icon={<Layers3 className="h-5 w-5" />} />)}
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          <SectionHeader
            eyebrow={locale === 'ar' ? 'تصنيفات منظمة' : 'Curated taxonomy'}
            title={locale === 'ar' ? 'التصنيفات الرئيسية' : 'Main categories'}
            description={locale === 'ar' ? 'تنظيم واضح يساعد المستخدم على الوصول للأداة المناسبة بدون تشتت.' : 'Clear organization to help users reach the right tool without friction.'}
            action={<Link className="focus-ring inline-flex h-11 items-center justify-center rounded-xl border border-white/15 bg-white/[0.03] px-4 text-sm font-semibold backdrop-blur transition hover:bg-white/[0.08]" to="/categories">{locale === 'ar' ? 'كل التصنيفات' : 'All categories'}</Link>}
          />
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            {categories.slice(0, 8).map((category) => <CategoryCard key={category.id} category={category} />)}
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          <SectionHeader
            eyebrow={locale === 'ar' ? 'أدوات مقترحة' : 'Featured tools'}
            title={locale === 'ar' ? 'بطاقات أدوات حديثة ومهيأة للتوسع' : 'Modern tool cards ready to scale'}
            description={locale === 'ar' ? 'كل بطاقة تعرض المعلومات الأساسية، التصنيف، السعر، التقييم، والحالة.' : 'Each card presents core details, category, pricing, rating, and status.'}
          />
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {featuredTools.slice(0, 6).map((tool) => <ToolCard key={tool.id} tool={tool} />)}
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container grid gap-10 lg:grid-cols-2">
          <div>
            <SectionHeader
              eyebrow={locale === 'ar' ? 'الأكثر استخدامًا' : 'Most used'}
              title={locale === 'ar' ? 'الأدوات الأكثر استخدامًا' : 'Most used tools'}
              description={locale === 'ar' ? 'الأدوات التي يعتمد عليها المستخدمون بشكل يومي.' : 'The tools users rely on the most, day to day.'}
            />
            <div className="grid gap-4">{mostUsedTools.map((tool) => <ToolCard key={tool.id} tool={tool} compact />)}</div>
          </div>
          <div>
            <SectionHeader
              eyebrow={locale === 'ar' ? 'وصل حديثًا' : 'Fresh arrivals'}
              title={locale === 'ar' ? 'أحدث الأدوات' : 'Latest tools'}
              description={locale === 'ar' ? 'آخر الإضافات إلى الدليل — دائمًا محدّث.' : 'The newest additions to the directory — always current.'}
            />
            <div className="grid gap-4">{latestTools.map((tool) => <ToolCard key={tool.id} tool={tool} compact />)}</div>
          </div>
        </div>
      </section>

      <section className="section-padding border-y border-white/10 bg-black/30">
        <div className="container grid gap-8 lg:grid-cols-[.9fr_1.1fr] lg:items-center">
          <div>
            <Badge className="mb-4"><Wand2 className="h-3.5 w-3.5" /> {locale === 'ar' ? 'رحلة استخدام بسيطة' : 'Simple user journey'}</Badge>
            <h2 className="text-3xl font-extrabold">{locale === 'ar' ? 'من البحث إلى الاختيار في خطوات واضحة' : 'From search to decision in clear steps'}</h2>
            <p className="mt-4 leading-7 text-muted-foreground">{locale === 'ar' ? 'تم بناء الواجهات لتخدم رحلة مستخدم سريعة: بحث، فلترة، تفاصيل، مقارنة، ثم حفظ أو تواصل.' : 'The UI supports a fast flow: search, filter, inspect details, compare, then save or contact.'}</p>
          </div>
          <div className="grid gap-3">
            {steps.map((step, index) => (
              <Card key={step.en} className="flex items-center gap-4 p-4">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-primary-400 to-primary-700 text-sm font-bold text-white">{index + 1}</span>
                <span className="font-semibold">{locale === 'ar' ? step.ar : step.en}</span>
                <CheckCircle2 className="ms-auto h-5 w-5 text-accent" />
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          <SectionHeader
            centered
            eyebrow={locale === 'ar' ? 'لماذا AI Hub Arabia' : 'Why AI Hub Arabia'}
            title={locale === 'ar' ? 'صُنعت لتكون مرجعك الموثوق لأدوات الذكاء الاصطناعي' : 'Built to be your trusted AI tools reference'}
          />
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            {whyUs.map((item) => {
              const Icon = item.icon;
              const copy = locale === 'ar' ? item.ar : item.en;
              return (
                <Card key={copy.title} className="p-6">
                  <div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-primary-500/20 to-accent/20 text-accent"><Icon className="h-6 w-6" /></div>
                  <h3 className="text-lg font-bold">{copy.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-muted-foreground">{copy.body}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      <section className="section-padding bg-black/30">
        <div className="container max-w-3xl">
          <SectionHeader centered eyebrow={locale === 'ar' ? 'الأسئلة الشائعة' : 'FAQ'} title={locale === 'ar' ? 'أسئلة يتكرر سؤالها' : 'Frequently asked questions'} />
          <div className="grid gap-3">
            {faqItems.map((item) => {
              const copy = locale === 'ar' ? item.ar : item.en;
              return (
                <details key={copy.q} className="group premium-card px-5 py-4">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold">
                    {copy.q}
                    <span className="text-accent transition group-open:rotate-45">+</span>
                  </summary>
                  <p className="mt-3 text-sm leading-6 text-muted-foreground">{copy.a}</p>
                </details>
              );
            })}
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          <Card className="glass-panel relative overflow-hidden p-10 text-center md:p-16">
            <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_center,rgba(242,194,74,0.14),transparent_60%)]" />
            <h2 className="text-3xl font-extrabold md:text-4xl">{locale === 'ar' ? 'جاهز لاكتشاف أداتك التالية؟' : 'Ready to find your next tool?'}</h2>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">{locale === 'ar' ? 'انضم إلى AI Hub Arabia وابدأ رحلتك في اكتشاف ومقارنة أفضل أدوات الذكاء الاصطناعي.' : 'Join AI Hub Arabia and start discovering and comparing the best AI tools available today.'}</p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <Link className="focus-ring btn-gold inline-flex h-12 items-center justify-center gap-2 rounded-xl px-8 text-base font-bold" to="/register">
                {locale === 'ar' ? 'أنشئ حسابك مجانًا' : 'Create your free account'} <ArrowIcon className="h-5 w-5" />
              </Link>
              <Link className="focus-ring inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/[0.03] px-8 text-base font-semibold backdrop-blur transition hover:bg-white/[0.08]" to="/tools">
                {locale === 'ar' ? 'تصفح كل الأدوات' : 'Browse all tools'}
              </Link>
            </div>
          </Card>
        </div>
      </section>
    </>
  );
}
