import { FormEvent, useEffect, useState } from 'react';
import { CheckCircle2, MessageSquareText, Search, ShieldX, Star, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import type { ReviewRecord } from '@/types/database';
import { deleteReview, searchReviews, updateReviewStatus } from '@/services/adminService';

type ReviewView = ReviewRecord & { userName: string; toolName: string };

export function AdminReviewsPage() {
  const { locale } = useLocale();
  const { showToast } = useToast();
  const [reviews, setReviews] = useState<ReviewView[]>([]);
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [loading, setLoading] = useState(true);
  useSeo(locale === 'ar' ? 'إدارة التقييمات' : 'Review moderation');

  async function refresh() {
    setLoading(true);
    const result = await searchReviews({ query, status });
    setReviews(result as ReviewView[]);
    setLoading(false);
  }

  useEffect(() => { refresh().catch(() => setLoading(false)); }, []);

  async function applySearch(event: FormEvent) {
    event.preventDefault();
    await refresh();
  }

  async function updateStatus(review: ReviewView, nextStatus: ReviewRecord['status']) {
    await updateReviewStatus(review.id, nextStatus);
    await refresh();
    showToast({ title: locale === 'ar' ? 'تم تحديث حالة التقييم' : 'Review status updated', tone: 'success' });
  }

  async function remove(review: ReviewView) {
    await deleteReview(review.id);
    await refresh();
    showToast({ title: locale === 'ar' ? 'تم حذف التقييم' : 'Review deleted', tone: 'success' });
  }

  function statusBadge(reviewStatus: ReviewRecord['status']) {
    if (reviewStatus === 'approved') return <Badge variant="success">{locale === 'ar' ? 'معتمد' : 'Approved'}</Badge>;
    if (reviewStatus === 'rejected') return <Badge variant="warning">{locale === 'ar' ? 'مرفوض' : 'Rejected'}</Badge>;
    return <Badge variant="default">{locale === 'ar' ? 'بانتظار المراجعة' : 'Pending'}</Badge>;
  }

  return (
    <div className="grid gap-6">
      <SectionHeader title={locale === 'ar' ? 'إدارة التقييمات والمراجعات' : 'Review moderation'} description={locale === 'ar' ? 'مراجعة التعليقات، اعتمادها، رفضها، أو حذف التقييمات المخالفة.' : 'Review comments, approve, reject, or delete inappropriate ratings.'} />

      <Card className="p-5">
        <form className="grid gap-3 md:grid-cols-[minmax(0,1fr)_12rem_auto]" onSubmit={applySearch}>
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={locale === 'ar' ? 'بحث في التقييمات أو أسماء الأدوات...' : 'Search reviews or tools...'} />
          <select className="h-11 rounded-xl border bg-background px-3 text-sm" value={status} onChange={(e) => setStatus(e.target.value)}><option value="all">{locale === 'ar' ? 'كل الحالات' : 'All statuses'}</option><option value="pending">pending</option><option value="approved">approved</option><option value="rejected">rejected</option></select>
          <Button type="submit"><Search className="h-4 w-4" /> {locale === 'ar' ? 'بحث' : 'Search'}</Button>
        </form>
      </Card>

      {loading ? <div className="grid gap-3">{Array.from({ length: 4 }).map((_, index) => <Skeleton key={index} className="h-32" />)}</div> : (
        <div className="grid gap-4">
          {reviews.map((review) => (
            <Card key={review.id} className="p-5">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                <div className="min-w-0">
                  <div className="mb-2 flex flex-wrap items-center gap-2"><MessageSquareText className="h-4 w-4 text-primary" /><h2 className="font-bold">{review.title}</h2>{statusBadge(review.status)}<Badge variant="muted"><Star className="h-3.5 w-3.5" /> {review.rating}/5</Badge></div>
                  <p className="text-sm leading-7 text-muted-foreground">{review.comment}</p>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs text-muted-foreground"><span>{locale === 'ar' ? 'المستخدم:' : 'User:'} {review.userName}</span><span>·</span><span>{locale === 'ar' ? 'الأداة:' : 'Tool:'} {review.toolName}</span><span>·</span><span>{new Date(review.createdAt).toLocaleDateString(locale === 'ar' ? 'ar' : 'en')}</span></div>
                </div>
                <div className="flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => updateStatus(review, 'approved')}><CheckCircle2 className="h-4 w-4" /> {locale === 'ar' ? 'اعتماد' : 'Approve'}</Button><Button size="sm" variant="ghost" onClick={() => updateStatus(review, 'rejected')}><ShieldX className="h-4 w-4" /> {locale === 'ar' ? 'رفض' : 'Reject'}</Button><Button size="sm" variant="danger" onClick={() => remove(review)}><Trash2 className="h-4 w-4" /></Button></div>
              </div>
            </Card>
          ))}
          {!reviews.length ? <Card className="p-8 text-center text-muted-foreground">{locale === 'ar' ? 'لا توجد مراجعات مطابقة.' : 'No matching reviews.'}</Card> : null}
        </div>
      )}
    </div>
  );
}
