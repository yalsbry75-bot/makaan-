import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { useToast } from '@/components/ui/Toast';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import type { FieldErrors, SignUpPayload } from '@/types/auth';

export function RegisterPage() {
  const { locale, t } = useLocale();
  const { register, isLoading } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState<SignUpPayload>({ name: '', email: '', password: '', confirmPassword: '' });
  const [errors, setErrors] = useState<FieldErrors<keyof SignUpPayload>>({});
  useSeo(t('auth.register'));

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    const result = await register(form);
    if (!result.success) {
      setErrors(result.fieldErrors as FieldErrors<keyof SignUpPayload>);
      showToast({ title: locale === 'ar' ? 'تعذر إنشاء الحساب' : 'Registration failed', description: result.message, tone: 'error' });
      return;
    }
    showToast({ title: locale === 'ar' ? 'تم إنشاء الحساب' : 'Account created', description: result.message, tone: 'success' });
    navigate('/dashboard', { replace: true });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">{t('auth.register')}</CardTitle>
        <p className="text-sm text-muted-foreground">{locale === 'ar' ? 'أنشئ حسابًا لإدارة المفضلة والمقارنات والملف الشخصي.' : 'Create an account to manage favorites, comparisons, and profile.'}</p>
      </CardHeader>
      <CardContent>
        <form className="grid gap-4" onSubmit={submit} noValidate>
          <Input
            label={locale === 'ar' ? 'الاسم الكامل' : 'Full name'}
            name="name"
            autoComplete="name"
            placeholder={locale === 'ar' ? 'مثال: أحمد محمد' : 'Example: Ahmed Mohammed'}
            value={form.name}
            onChange={(event) => setForm((current) => ({ ...current, name: event.target.value }))}
            error={errors.name}
          />
          <Input
            label={locale === 'ar' ? 'البريد الإلكتروني' : 'Email'}
            name="email"
            type="email"
            autoComplete="email"
            placeholder="name@example.com"
            value={form.email}
            onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))}
            error={errors.email}
          />
          <Input
            label={locale === 'ar' ? 'كلمة المرور' : 'Password'}
            name="password"
            type="password"
            autoComplete="new-password"
            placeholder="••••••••"
            helperText={locale === 'ar' ? '8 أحرف على الأقل مع حرف كبير وصغير ورقم.' : 'At least 8 characters with uppercase, lowercase, and a number.'}
            value={form.password}
            onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))}
            error={errors.password}
          />
          <Input
            label={locale === 'ar' ? 'تأكيد كلمة المرور' : 'Confirm password'}
            name="confirmPassword"
            type="password"
            autoComplete="new-password"
            placeholder="••••••••"
            value={form.confirmPassword}
            onChange={(event) => setForm((current) => ({ ...current, confirmPassword: event.target.value }))}
            error={errors.confirmPassword}
          />
          <Button type="submit" fullWidth isLoading={isLoading} loadingLabel={locale === 'ar' ? 'جاري إنشاء الحساب...' : 'Creating account...'}>
            <UserPlus className="h-4 w-4" />
            {t('auth.register')}
          </Button>
        </form>
        <p className="mt-6 text-center text-sm text-muted-foreground">
          {locale === 'ar' ? 'لديك حساب بالفعل؟ ' : 'Already have an account? '}
          <Link className="font-semibold text-primary" to="/login">{t('auth.login')}</Link>
        </p>
      </CardContent>
    </Card>
  );
}
