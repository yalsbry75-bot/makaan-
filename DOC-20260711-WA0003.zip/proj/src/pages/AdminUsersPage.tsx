import { FormEvent, useEffect, useMemo, useState } from 'react';
import { Edit3, Lock, Search, Trash2, UserCheck, UsersRound } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import type { StoredUser, UserRole, AccountStatus } from '@/types/auth';
import { deleteAdminUser, searchAdminUsers, updateAdminUser } from '@/services/adminService';

type UserForm = {
  name: string;
  email: string;
  role: UserRole;
  status: AccountStatus;
  title: string;
  company: string;
  bio: string;
};

function userToForm(user: StoredUser): UserForm {
  return {
    name: user.name,
    email: user.email,
    role: user.role,
    status: user.status,
    title: user.title ?? '',
    company: user.company ?? '',
    bio: user.bio ?? '',
  };
}

export function AdminUsersPage() {
  const { locale } = useLocale();
  const { showToast } = useToast();
  const [users, setUsers] = useState<StoredUser[]>([]);
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingUser, setEditingUser] = useState<StoredUser | null>(null);
  const [form, setForm] = useState<UserForm | null>(null);
  useSeo(locale === 'ar' ? 'إدارة المستخدمين' : 'User management');

  async function refresh() {
    setLoading(true);
    const result = await searchAdminUsers({ query, status });
    setUsers(result);
    setLoading(false);
  }

  useEffect(() => { refresh().catch(() => setLoading(false)); }, []);
  const filteredUsers = useMemo(() => users, [users]);

  async function applySearch(event: FormEvent) {
    event.preventDefault();
    await refresh();
  }

  function openEdit(user: StoredUser) {
    setEditingUser(user);
    setForm(userToForm(user));
  }

  function updateForm<K extends keyof UserForm>(key: K, value: UserForm[K]) {
    setForm((current) => current ? { ...current, [key]: value } : current);
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!editingUser || !form) return;
    setSaving(true);
    try {
      await updateAdminUser(editingUser.id, form);
      setEditingUser(null);
      setForm(null);
      await refresh();
      showToast({ title: locale === 'ar' ? 'تم تحديث المستخدم' : 'User updated', tone: 'success' });
    } catch (error) {
      showToast({ title: locale === 'ar' ? 'تعذر تحديث المستخدم' : 'Could not update user', description: error instanceof Error ? error.message : undefined, tone: 'error' });
    } finally {
      setSaving(false);
    }
  }

  async function toggleStatus(user: StoredUser) {
    await updateAdminUser(user.id, { status: user.status === 'active' ? 'locked' : 'active' });
    await refresh();
    showToast({ title: locale === 'ar' ? 'تم تحديث حالة الحساب' : 'Account status updated', tone: 'success' });
  }

  async function removeUser(user: StoredUser) {
    if (user.role === 'admin') {
      showToast({ title: locale === 'ar' ? 'لا يمكن حذف حساب مشرف تجريبي' : 'Demo admin cannot be deleted', tone: 'error' });
      return;
    }
    await deleteAdminUser(user.id);
    await refresh();
    showToast({ title: locale === 'ar' ? 'تم حذف المستخدم' : 'User deleted', tone: 'success' });
  }

  return (
    <div className="grid gap-6">
      <SectionHeader
        title={locale === 'ar' ? 'إدارة المستخدمين' : 'User management'}
        description={locale === 'ar' ? 'عرض المستخدمين، البحث، تعديل البيانات، تعطيل الحسابات، وتحديد الصلاحيات.' : 'Browse users, search accounts, edit profile data, disable accounts, and manage roles.'}
      />

      <Card className="p-5">
        <form className="grid gap-3 md:grid-cols-[minmax(0,1fr)_12rem_auto]" onSubmit={applySearch}>
          <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={locale === 'ar' ? 'بحث بالاسم أو البريد أو الشركة...' : 'Search by name, email, or company...'} />
          <select className="h-11 rounded-xl border bg-background px-3 text-sm" value={status} onChange={(event) => setStatus(event.target.value)}>
            <option value="all">{locale === 'ar' ? 'كل الحالات' : 'All statuses'}</option>
            <option value="active">{locale === 'ar' ? 'نشط' : 'Active'}</option>
            <option value="locked">{locale === 'ar' ? 'معطل' : 'Disabled'}</option>
          </select>
          <Button type="submit"><Search className="h-4 w-4" /> {locale === 'ar' ? 'بحث' : 'Search'}</Button>
        </form>
      </Card>

      <Card className="overflow-hidden">
        {loading ? <div className="grid gap-3 p-5">{Array.from({ length: 5 }).map((_, index) => <Skeleton key={index} className="h-16" />)}</div> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[920px] text-sm">
              <thead className="bg-muted text-muted-foreground">
                <tr><th className="p-4 text-start">{locale === 'ar' ? 'المستخدم' : 'User'}</th><th className="p-4 text-start">{locale === 'ar' ? 'الدور' : 'Role'}</th><th className="p-4 text-start">{locale === 'ar' ? 'الحالة' : 'Status'}</th><th className="p-4 text-start">{locale === 'ar' ? 'المنصب' : 'Title'}</th><th className="p-4 text-start">{locale === 'ar' ? 'تاريخ الإنشاء' : 'Created'}</th><th className="p-4 text-start">{locale === 'ar' ? 'إجراءات' : 'Actions'}</th></tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="border-t">
                    <td className="p-4"><div className="font-bold">{user.name}</div><div className="text-xs text-muted-foreground">{user.email}</div></td>
                    <td className="p-4"><Badge variant={user.role === 'admin' ? 'warning' : 'muted'}>{user.role}</Badge></td>
                    <td className="p-4"><Badge variant={user.status === 'active' ? 'success' : 'warning'}>{user.status === 'active' ? (locale === 'ar' ? 'نشط' : 'Active') : (locale === 'ar' ? 'معطل' : 'Disabled')}</Badge></td>
                    <td className="p-4 text-muted-foreground">{user.title ?? '-'}</td>
                    <td className="p-4 text-muted-foreground">{new Date(user.createdAt).toLocaleDateString(locale === 'ar' ? 'ar' : 'en')}</td>
                    <td className="p-4"><div className="flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => openEdit(user)}><Edit3 className="h-4 w-4" /> {locale === 'ar' ? 'تعديل' : 'Edit'}</Button><Button size="sm" variant="ghost" onClick={() => toggleStatus(user)}>{user.status === 'active' ? <Lock className="h-4 w-4" /> : <UserCheck className="h-4 w-4" />} {user.status === 'active' ? (locale === 'ar' ? 'تعطيل' : 'Disable') : (locale === 'ar' ? 'تفعيل' : 'Enable')}</Button><Button size="sm" variant="danger" onClick={() => removeUser(user)}><Trash2 className="h-4 w-4" /></Button></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal open={Boolean(editingUser && form)} title={locale === 'ar' ? 'تعديل المستخدم' : 'Edit user'} onClose={() => { setEditingUser(null); setForm(null); }} className="max-w-2xl">
        {form ? (
          <form className="grid gap-4" onSubmit={handleSubmit}>
            <div className="grid gap-3 md:grid-cols-2"><Input label={locale === 'ar' ? 'الاسم' : 'Name'} value={form.name} onChange={(e) => updateForm('name', e.target.value)} /><Input label={locale === 'ar' ? 'البريد الإلكتروني' : 'Email'} value={form.email} onChange={(e) => updateForm('email', e.target.value)} /></div>
            <div className="grid gap-3 md:grid-cols-2">
              <label className="space-y-2 text-sm font-semibold">{locale === 'ar' ? 'الدور' : 'Role'}<select className="mt-2 h-11 w-full rounded-xl border bg-background px-3 text-sm" value={form.role} onChange={(e) => updateForm('role', e.target.value as UserRole)}><option value="user">user</option><option value="admin">admin</option></select></label>
              <label className="space-y-2 text-sm font-semibold">{locale === 'ar' ? 'الحالة' : 'Status'}<select className="mt-2 h-11 w-full rounded-xl border bg-background px-3 text-sm" value={form.status} onChange={(e) => updateForm('status', e.target.value as AccountStatus)}><option value="active">active</option><option value="locked">locked</option></select></label>
            </div>
            <div className="grid gap-3 md:grid-cols-2"><Input label={locale === 'ar' ? 'المنصب' : 'Title'} value={form.title} onChange={(e) => updateForm('title', e.target.value)} /><Input label={locale === 'ar' ? 'الشركة' : 'Company'} value={form.company} onChange={(e) => updateForm('company', e.target.value)} /></div>
            <label className="space-y-2 text-sm font-semibold">{locale === 'ar' ? 'نبذة' : 'Bio'}<textarea className="mt-2 min-h-24 w-full rounded-xl border bg-background p-3 text-sm" value={form.bio} onChange={(e) => updateForm('bio', e.target.value)} /></label>
            <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => { setEditingUser(null); setForm(null); }}>{locale === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button type="submit" disabled={saving}>{saving ? (locale === 'ar' ? 'جارٍ الحفظ...' : 'Saving...') : (locale === 'ar' ? 'حفظ' : 'Save')}</Button></div>
          </form>
        ) : null}
      </Modal>
    </div>
  );
}
