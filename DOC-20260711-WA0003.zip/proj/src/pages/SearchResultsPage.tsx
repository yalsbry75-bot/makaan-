import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import type { AITool, ToolCategory } from '@/types';
import type { ToolSortOption } from '@/types/database';
import { ToolCard } from '@/components/domain/ToolCard';
import { ToolFilters } from '@/components/domain/ToolFilters';
import { EmptyState } from '@/components/feedback/EmptyState';
import { ErrorState } from '@/components/feedback/ErrorState';
import { Breadcrumbs } from '@/components/ui/Breadcrumbs';
import { Card } from '@/components/ui/Card';
import { Dropdown } from '@/components/ui/Dropdown';
import { Pagination } from '@/components/ui/Pagination';
import { SearchBar } from '@/components/ui/SearchBar';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { getCategories, searchToolsAdvanced } from '@/services/toolService';
import { getSearchSuggestions } from '@/services/searchService';
import { getUserFavoriteIds, toggleFavorite } from '@/services/favoriteService';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

export function SearchResultsPage() {
  const { locale } = useLocale();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') ?? '';
  const [category, setCategory] = useState(searchParams.get('category') ?? 'all');
  const [pricing, setPricing] = useState(searchParams.get('pricing') ?? 'all');
  const [platform, setPlatform] = useState(searchParams.get('platform') ?? 'all');
  const [minRating, setMinRating] = useState<number | undefined>(searchParams.get('rating') ? Number(searchParams.get('rating')) : undefined);
  const [selectedTag, setSelectedTag] = useState(searchParams.get('tag') ?? 'all');
  const initialSort = searchParams.get('sort');
  const [sort, setSort] = useState<ToolSortOption>(['relevance', 'top-rated', 'newest', 'most-used', 'name', 'featured'].includes(initialSort ?? '') ? initialSort as ToolSortOption : 'relevance');
  const [page, setPage] = useState(1);
  const [results, setResults] = useState<AITool[]>([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [categories, setCategories] = useState<ToolCategory[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [correctedQuery, setCorrectedQuery] = useState<string | null>(null);
  useSeo(locale === 'ar' ? 'نتائج البحث' : 'Search results');

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);
    setHasError(false);
    Promise.all([
      searchToolsAdvanced({ search: query, category, pricing, platform, tag: selectedTag === 'all' ? '' : selectedTag, minRating, sort, status: 'active', page, pageSize: 9 }),
      getCategories(),
      user ? getUserFavoriteIds(user.id) : Promise.resolve(new Set<string>()),
      query ? getSearchSuggestions(query, 1) : Promise.resolve({ suggestions: [], correctedQuery: null }),
    ])
      .then(([loadedResults, loadedCategories, loadedFavorites, smartSnapshot]) => {
        if (!isMounted) return;
        setResults(loadedResults.items);
        setTotal(loadedResults.total);
        setTotalPages(loadedResults.totalPages);
        setCategories(loadedCategories);
        setFavoriteIds(loadedFavorites);
        setCorrectedQuery(smartSnapshot.correctedQuery);
      })
      .catch(() => {
        if (isMounted) setHasError(true);
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, [category, pricing, platform, selectedTag, minRating, query, sort, page, user]);


  const tagOptions = Array.from(new Set(results.flatMap((tool) => tool.tags))).slice(0, 12);

  async function handleToggleFavorite(tool: AITool) {
    if (!user) {
      showToast({ title: locale === 'ar' ? 'سجّل الدخول أولًا' : 'Login required', description: locale === 'ar' ? 'يجب تسجيل الدخول لحفظ الأدوات.' : 'You need to sign in to save tools.', tone: 'error' });
      return;
    }
    const result = await toggleFavorite(user.id, tool.id);
    setFavoriteIds((current) => {
      const next = new Set(current);
      if (result.favorite) next.add(tool.id);
      else next.delete(tool.id);
      return next;
    });
  }

  return (
    <section className="section-padding">
      <div className="container">
        <Breadcrumbs items={[{ label: locale === 'ar' ? 'البحث' : 'Search', href: '/search' }, { label: locale === 'ar' ? 'النتائج' : 'Results' }]} className="mb-8" />
        <div className="mb-8 grid gap-4 lg:grid-cols-[1fr_auto_18rem]">
          <SearchBar initialValue={query} showButton />
          <Dropdown
            label={locale === 'ar' ? 'الترتيب' : 'Sort'}
            items={[
              { label: locale === 'ar' ? 'الأكثر صلة' : 'Most relevant', onSelect: () => { setSort('relevance'); setPage(1); } },
              { label: locale === 'ar' ? 'الأعلى تقييمًا' : 'Top rated', onSelect: () => { setSort('top-rated'); setPage(1); } },
              { label: locale === 'ar' ? 'الأحدث' : 'Newest', onSelect: () => { setSort('newest'); setPage(1); } },
              { label: locale === 'ar' ? 'الأكثر استخدامًا' : 'Most used', onSelect: () => { setSort('most-used'); setPage(1); } },
            ]}
          />
          <Card className="flex items-center justify-between p-4 text-sm"><span className="text-muted-foreground">{locale === 'ar' ? 'عدد النتائج' : 'Results'}</span><strong>{total}</strong></Card>
        </div>
        <div className="grid gap-8 lg:grid-cols-[18rem_1fr]">
          <ToolFilters
            selectedCategory={category}
            selectedPricing={pricing}
            selectedPlatform={platform}
            minRating={minRating}
            selectedTag={selectedTag}
            tagOptions={tagOptions}
            categories={categories}
            onCategoryChange={(next) => { setCategory(next); setPage(1); }}
            onPricingChange={(next) => { setPricing(next); setPage(1); }}
            onPlatformChange={(next) => { setPlatform(next); setPage(1); }}
            onTagChange={(next) => { setSelectedTag(next); setPage(1); }}
            onMinRatingChange={(next) => { setMinRating(next); setPage(1); }}
          />
          <div>
            <h1 className="mb-3 text-3xl font-extrabold">{locale === 'ar' ? `نتائج البحث عن: ${query || 'كل الأدوات'}` : `Search results for: ${query || 'all tools'}`}</h1>
            {correctedQuery ? (
              <a className="mb-5 inline-flex rounded-full border px-4 py-2 text-sm font-semibold text-primary transition hover:bg-muted" href={`/search/results?q=${encodeURIComponent(correctedQuery)}`}>
                {locale === 'ar' ? `هل تقصد: ${correctedQuery}` : `Did you mean: ${correctedQuery}`}
              </a>
            ) : null}
            {hasError ? (
              <ErrorState title={locale === 'ar' ? 'تعذر البحث' : 'Search failed'} description={locale === 'ar' ? 'حدث خطأ أثناء تنفيذ الاستعلام.' : 'An error occurred while running the query.'} />
            ) : isLoading ? (
              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{Array.from({ length: 9 }).map((_, index) => <Skeleton key={index} className="h-72" />)}</div>
            ) : results.length ? (
              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{results.map((tool) => <ToolCard key={tool.id} tool={tool} isFavorite={favoriteIds.has(tool.id)} onToggleFavorite={handleToggleFavorite} />)}</div>
            ) : (
              <EmptyState title={locale === 'ar' ? 'لا توجد نتائج' : 'No results'} description={locale === 'ar' ? 'جرّب كلمة بحث مختلفة أو أزل بعض الفلاتر.' : 'Try a different query or remove filters.'} />
            )}
            {!hasError && !isLoading ? <Pagination className="mt-10" page={page} totalPages={totalPages} onPageChange={setPage} /> : null}
          </div>
        </div>
      </div>
    </section>
  );
}
