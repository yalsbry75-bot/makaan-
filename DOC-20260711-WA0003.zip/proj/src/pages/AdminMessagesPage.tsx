import { FormEvent, useEffect, useState } from 'react';
import { CheckCircle2, Mail, Search, ShieldAlert, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import type { ContactMessageRecord, ReportRecord } from '@/types/database';
import { deleteContactMessage, deleteReport, searchContactMessages, searchReports, updateContactMessageStatus, updateReportStatus } from '@/services/adminService';

export function AdminMessagesPage() {
  const { locale } = useLocale();
  const { showToast } = useToast();
  const [messages, setMessages] = useState<ContactMessageRecord[]>([]);
  const [reports, setReports] = useState<ReportRecord[]>([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  useSeo(locale === 'ar' ? 'الرسائل والبلاغات' : 'Messages and reports');

  async function refresh() {
    setLoading(true);
    const [messageRows, reportRows] = await Promise.all([searchContactMessages({ query }), searchReports({ query })]);
    setMessages(messageRows);
    setReports(reportRows);
    setLoading(false);
  }

  useEffect(() => { refresh().catch(() => setLoading(false)); }, []);
  async function applySearch(event: FormEvent) { event.preventDefault(); await refresh(); }

  async function setMessageStatus(message: ContactMessageRecord, status: ContactMessageRecord['status']) {
    await updateContactMessageStatus(message.id, status);
    await refresh();
    showToast({ title: locale === 'ar' ? 'تم تحديث الرسالة' : 'Message updated', tone: 'success' });
  }

  async function setReportStatus(report: ReportRecord, status: ReportRecord['status']) {
    await updateReportStatus(report.id, status);
    await refresh();
    showToast({ title: locale === 'ar' ? 'تم تحديث البلاغ' : 'Report updated', tone: 'success' });
  }

  return (
    <div className="grid gap-6">
      <SectionHeader title={locale === 'ar' ? 'إدارة الرسائل والبلاغات' : 'Messages and reports'} description={locale === 'ar' ? 'متابعة رسائل التواصل والشكاوى والاقتراحات والبلاغات ومعالجة حالتها.' : 'Track contact messages, complaints, suggestions, and reports with workflow status control.'} />

      <Card className="p-5">
        <form className="grid gap-3 md:grid-cols-[minmax(0,1fr)_auto]" onSubmit={applySearch}>
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={locale === 'ar' ? 'بحث في الرسائل والبلاغات...' : 'Search messages and reports...'} />
          <Button type="submit"><Search className="h-4 w-4" /> {locale === 'ar' ? 'بحث' : 'Search'}</Button>
        </form>
      </Card>

      {loading ? <div className="grid gap-4 md:grid-cols-2">{Array.from({ length: 4 }).map((_, index) => <Skeleton key={index} className="h-40" />)}</div> : (
        <div className="grid gap-6 xl:grid-cols-2">
          <Card className="p-5">
            <div className="mb-4 flex items-center gap-2"><Mail className="h-5 w-5 text-primary" /><h2 className="text-xl font-bold">{locale === 'ar' ? 'رسائل التواصل' : 'Contact messages'}</h2></div>
            <div className="grid gap-3">
              {messages.map((message) => (
                <div key={message.id} className="rounded-2xl border p-4">
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2"><div><p className="font-bold">{message.name}</p><p className="text-xs text-muted-foreground">{message.email}</p></div><Badge variant={message.status === 'new' ? 'warning' : message.status === 'closed' ? 'success' : 'muted'}>{message.status}</Badge></div>
                  <p className="text-sm leading-7 text-muted-foreground">{message.message}</p>
                  <div className="mt-3 flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => setMessageStatus(message, 'read')}>{locale === 'ar' ? 'مقروءة' : 'Read'}</Button><Button size="sm" variant="ghost" onClick={() => setMessageStatus(message, 'closed')}><CheckCircle2 className="h-4 w-4" /> {locale === 'ar' ? 'إغلاق' : 'Close'}</Button><Button size="sm" variant="danger" onClick={async () => { await deleteContactMessage(message.id); await refresh(); }}><Trash2 className="h-4 w-4" /></Button></div>
                </div>
              ))}
              {!messages.length ? <p className="py-8 text-center text-sm text-muted-foreground">{locale === 'ar' ? 'لا توجد رسائل مطابقة.' : 'No matching messages.'}</p> : null}
            </div>
          </Card>

          <Card className="p-5">
            <div className="mb-4 flex items-center gap-2"><ShieldAlert className="h-5 w-5 text-primary" /><h2 className="text-xl font-bold">{locale === 'ar' ? 'البلاغات والشكاوى' : 'Reports and complaints'}</h2></div>
            <div className="grid gap-3">
              {reports.map((report) => (
                <div key={report.id} className="rounded-2xl border p-4">
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2"><div><p className="font-bold">{report.targetType} · {report.targetId}</p><p className="text-xs text-muted-foreground">{locale === 'ar' ? 'المُبلّغ:' : 'Reporter:'} {report.reporterId}</p></div><Badge variant={report.status === 'open' ? 'warning' : report.status === 'resolved' ? 'success' : 'muted'}>{report.status}</Badge></div>
                  <p className="text-sm leading-7 text-muted-foreground">{report.reason}</p>
                  <div className="mt-3 flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => setReportStatus(report, 'investigating')}>{locale === 'ar' ? 'قيد المعالجة' : 'Investigating'}</Button><Button size="sm" variant="ghost" onClick={() => setReportStatus(report, 'resolved')}><CheckCircle2 className="h-4 w-4" /> {locale === 'ar' ? 'حل البلاغ' : 'Resolve'}</Button><Button size="sm" variant="danger" onClick={async () => { await deleteReport(report.id); await refresh(); }}><Trash2 className="h-4 w-4" /></Button></div>
                </div>
              ))}
              {!reports.length ? <p className="py-8 text-center text-sm text-muted-foreground">{locale === 'ar' ? 'لا توجد بلاغات مطابقة.' : 'No matching reports.'}</p> : null}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
