import { useEffect, useState } from 'react';
import { BarChart3 } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { ToolCategory } from '@/types';
import { CategoryCard } from '@/components/domain/CategoryCard';
import { ErrorState } from '@/components/feedback/ErrorState';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { SearchBar } from '@/components/ui/SearchBar';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { getCategories } from '@/services/toolService';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

export function CategoriesPage() {
  const { locale } = useLocale();
  const [categories, setCategories] = useState<ToolCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  useSeo(locale === 'ar' ? 'التصنيفات' : 'Categories');

  useEffect(() => {
    let isMounted = true;
    getCategories()
      .then((loadedCategories) => {
        if (isMounted) setCategories(loadedCategories);
      })
      .catch(() => {
        if (isMounted) setHasError(true);
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <section className="section-padding">
      <div className="container">
        <SectionHeader
          centered
          eyebrow={locale === 'ar' ? 'تصنيف واضح' : 'Clear taxonomy'}
          title={locale === 'ar' ? 'تصفح الأدوات حسب المجال' : 'Browse tools by domain'}
          description={locale === 'ar' ? 'التصنيفات تُقرأ الآن من Collection مخصصة داخل طبقة البيانات، مع قابلية التحديث لاحقًا من لوحة الإدارة.' : 'Categories are now read from a dedicated collection in the data layer and can later be managed from the admin dashboard.'}
        />
        <div className="mx-auto mb-10 max-w-3xl"><SearchBar showButton /></div>
        {hasError ? (
          <ErrorState title={locale === 'ar' ? 'تعذر تحميل التصنيفات' : 'Could not load categories'} description={locale === 'ar' ? 'تحقق من طبقة قاعدة البيانات المحلية.' : 'Check the local database layer.'} />
        ) : isLoading ? (
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 8 }).map((_, index) => <Skeleton key={index} className="h-56" />)}</div>
        ) : (
          <>
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
              {categories.map((category) => <CategoryCard key={category.id} category={category} />)}
            </div>
            <div className="mt-12 grid gap-5 lg:grid-cols-3">
              {categories.slice(0, 3).map((category) => (
                <Card key={category.id} className="p-5">
                  <div className="mb-4 flex items-center justify-between">
                    <Badge variant="success">{category.growth}</Badge>
                    <BarChart3 className="h-5 w-5 text-primary" />
                  </div>
                  <h2 className="text-lg font-bold">{locale === 'ar' ? category.nameAr : category.nameEn}</h2>
                  <p className="mt-2 text-sm text-muted-foreground">{locale === 'ar' ? 'نمو واضح في الطلب على هذا المجال داخل منتجات الذكاء الاصطناعي.' : 'Visible demand growth across AI products in this domain.'}</p>
                  <Link className="mt-5 inline-flex text-sm font-semibold text-primary" to={`/tools?category=${category.slug}`}>{locale === 'ar' ? 'عرض الأدوات' : 'View tools'}</Link>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
}
