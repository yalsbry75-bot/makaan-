import { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import { KeyRound } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { useToast } from '@/components/ui/Toast';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import type { FieldErrors, PasswordResetPayload } from '@/types/auth';

export function ForgotPasswordPage() {
  const { locale, t } = useLocale();
  const { resetPassword, isLoading } = useAuth();
  const { showToast } = useToast();
  const [form, setForm] = useState<PasswordResetPayload>({ email: '' });
  const [errors, setErrors] = useState<FieldErrors<keyof PasswordResetPayload>>({});
  useSeo(t('auth.forgotPassword'));

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    const result = await resetPassword(form);
    if (!result.success) {
      setErrors(result.fieldErrors as FieldErrors<keyof PasswordResetPayload>);
      showToast({ title: locale === 'ar' ? 'تعذر إرسال الطلب' : 'Request failed', description: result.message, tone: 'error' });
      return;
    }
    showToast({ title: locale === 'ar' ? 'تم تسجيل الطلب' : 'Reset requested', description: result.message, tone: 'success' });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">{t('auth.forgotPassword')}</CardTitle>
        <p className="text-sm text-muted-foreground">{locale === 'ar' ? 'أدخل بريدك لإرسال رابط إعادة تعيين كلمة المرور.' : 'Enter your email to receive a password reset link.'}</p>
      </CardHeader>
      <CardContent>
        <form className="grid gap-4" onSubmit={submit} noValidate>
          <Input
            label={locale === 'ar' ? 'البريد الإلكتروني' : 'Email'}
            name="email"
            type="email"
            autoComplete="email"
            placeholder="name@example.com"
            value={form.email}
            onChange={(event) => setForm({ email: event.target.value })}
            error={errors.email}
          />
          <Button type="submit" fullWidth isLoading={isLoading} loadingLabel={locale === 'ar' ? 'جاري الإرسال...' : 'Sending...'}>
            <KeyRound className="h-4 w-4" />
            {locale === 'ar' ? 'إرسال رابط الاستعادة' : 'Send reset link'}
          </Button>
        </form>
        <p className="mt-6 text-center text-sm"><Link className="font-semibold text-primary" to="/login">{locale === 'ar' ? 'العودة لتسجيل الدخول' : 'Back to login'}</Link></p>
      </CardContent>
    </Card>
  );
}
