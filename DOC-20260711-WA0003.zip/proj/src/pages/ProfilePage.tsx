import { FormEvent, useEffect, useState } from 'react';
import { Bell, Globe2, KeyRound, ShieldCheck, UserRound } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import type { AccountSettingsPayload, FieldErrors, PasswordChangePayload, ProfileUpdatePayload } from '@/types/auth';

const emptyPasswordForm: PasswordChangePayload = {
  currentPassword: '',
  newPassword: '',
  confirmPassword: '',
};

export function ProfilePage() {
  const { locale } = useLocale();
  const { user, isLoading, updateProfile, changePassword, updateAccountSettings } = useAuth();
  const { showToast } = useToast();
  const [profileForm, setProfileForm] = useState<ProfileUpdatePayload>({ name: '', email: '', title: '', company: '', bio: '' });
  const [profileErrors, setProfileErrors] = useState<FieldErrors<keyof ProfileUpdatePayload>>({});
  const [passwordForm, setPasswordForm] = useState<PasswordChangePayload>(emptyPasswordForm);
  const [passwordErrors, setPasswordErrors] = useState<FieldErrors<keyof PasswordChangePayload>>({});
  const [settingsForm, setSettingsForm] = useState<AccountSettingsPayload>({ newsletter: true, productUpdates: true });
  useSeo(locale === 'ar' ? 'الملف الشخصي' : 'Profile');

  useEffect(() => {
    if (!user) return;
    setProfileForm({
      name: user.name,
      email: user.email,
      title: user.title ?? '',
      company: user.company ?? '',
      bio: user.bio ?? '',
      avatarUrl: user.avatarUrl ?? '',
    });
    setSettingsForm({
      newsletter: user.preferences.newsletter,
      productUpdates: user.preferences.productUpdates,
    });
  }, [user]);

  if (!user) {
    return <Skeleton className="h-96 w-full" />;
  }

  const submitProfile = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setProfileErrors({});
    const result = await updateProfile(profileForm);
    if (!result.success) {
      setProfileErrors(result.fieldErrors as FieldErrors<keyof ProfileUpdatePayload>);
      showToast({ title: locale === 'ar' ? 'تعذر الحفظ' : 'Save failed', description: result.message, tone: 'error' });
      return;
    }
    showToast({ title: locale === 'ar' ? 'تم حفظ الملف الشخصي' : 'Profile saved', description: result.message, tone: 'success' });
  };

  const submitPassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setPasswordErrors({});
    const result = await changePassword(passwordForm);
    if (!result.success) {
      setPasswordErrors(result.fieldErrors as FieldErrors<keyof PasswordChangePayload>);
      showToast({ title: locale === 'ar' ? 'تعذر تغيير كلمة المرور' : 'Password change failed', description: result.message, tone: 'error' });
      return;
    }
    setPasswordForm(emptyPasswordForm);
    showToast({ title: locale === 'ar' ? 'تم تغيير كلمة المرور' : 'Password changed', description: result.message, tone: 'success' });
  };

  const submitSettings = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const result = await updateAccountSettings(settingsForm);
    showToast({
      title: result.success ? (locale === 'ar' ? 'تم حفظ الإعدادات' : 'Settings saved') : (locale === 'ar' ? 'تعذر حفظ الإعدادات' : 'Settings failed'),
      description: result.message,
      tone: result.success ? 'success' : 'error',
    });
  };

  return (
    <div className="grid gap-6">
      <SectionHeader title={locale === 'ar' ? 'الملف الشخصي' : 'Profile'} description={locale === 'ar' ? 'إدارة بيانات المستخدم، كلمة المرور، وتفضيلات الحساب.' : 'Manage user data, password, and account preferences.'} />
      <div className="grid gap-6 xl:grid-cols-[1fr_22rem]">
        <Card className="p-6">
          <div className="mb-6 flex flex-wrap items-center gap-4">
            <div className="grid h-16 w-16 place-items-center rounded-3xl bg-primary/10 text-primary"><UserRound className="h-8 w-8" /></div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-bold">{user.name}</h2>
                <Badge variant={user.role === 'admin' ? 'success' : 'muted'}>{user.role === 'admin' ? (locale === 'ar' ? 'مدير' : 'Admin') : (locale === 'ar' ? 'مستخدم' : 'User')}</Badge>
              </div>
              <p className="text-sm text-muted-foreground">{user.email}</p>
            </div>
          </div>

          <form className="grid gap-4 md:grid-cols-2" onSubmit={submitProfile} noValidate>
            <Input label={locale === 'ar' ? 'الاسم' : 'Name'} name="name" value={profileForm.name} onChange={(event) => setProfileForm((current) => ({ ...current, name: event.target.value }))} error={profileErrors.name} />
            <Input label={locale === 'ar' ? 'البريد الإلكتروني' : 'Email'} name="email" type="email" value={profileForm.email} onChange={(event) => setProfileForm((current) => ({ ...current, email: event.target.value }))} error={profileErrors.email} />
            <Input label={locale === 'ar' ? 'المجال المهني' : 'Role / Title'} name="title" value={profileForm.title} onChange={(event) => setProfileForm((current) => ({ ...current, title: event.target.value }))} />
            <Input label={locale === 'ar' ? 'الشركة' : 'Company'} name="company" placeholder={locale === 'ar' ? 'اختياري' : 'Optional'} value={profileForm.company} onChange={(event) => setProfileForm((current) => ({ ...current, company: event.target.value }))} />
            <label className="block space-y-2 md:col-span-2">
              <span className="text-sm font-semibold text-foreground">{locale === 'ar' ? 'نبذة مختصرة' : 'Short bio'}</span>
              <textarea
                className="focus-ring min-h-28 w-full rounded-xl border border-input bg-background px-3 py-3 text-sm outline-none transition placeholder:text-muted-foreground/70"
                value={profileForm.bio}
                onChange={(event) => setProfileForm((current) => ({ ...current, bio: event.target.value }))}
                placeholder={locale === 'ar' ? 'اكتب نبذة قصيرة تظهر داخل الحساب.' : 'Write a short account bio.'}
              />
            </label>
            <div className="md:col-span-2">
              <Button type="submit" disabled={isLoading}>{isLoading ? (locale === 'ar' ? 'جاري الحفظ...' : 'Saving...') : locale === 'ar' ? 'حفظ التغييرات' : 'Save changes'}</Button>
            </div>
          </form>
        </Card>

        <div className="grid gap-4">
          {[{ icon: <ShieldCheck className="h-5 w-5" />, ar: 'حماية الحساب', en: 'Account security' }, { icon: <Bell className="h-5 w-5" />, ar: 'التنبيهات', en: 'Notifications' }, { icon: <Globe2 className="h-5 w-5" />, ar: 'اللغة والاتجاه', en: 'Language and direction' }].map((item) => <Card key={item.en} className="flex items-center gap-3 p-5"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">{item.icon}</span><span className="font-semibold">{locale === 'ar' ? item.ar : item.en}</span></Card>)}
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card className="p-6">
          <div className="mb-5 flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary"><KeyRound className="h-5 w-5" /></span>
            <h2 className="text-xl font-bold">{locale === 'ar' ? 'تغيير كلمة المرور' : 'Change password'}</h2>
          </div>
          <form className="grid gap-4" onSubmit={submitPassword} noValidate>
            <Input label={locale === 'ar' ? 'كلمة المرور الحالية' : 'Current password'} name="currentPassword" type="password" value={passwordForm.currentPassword} onChange={(event) => setPasswordForm((current) => ({ ...current, currentPassword: event.target.value }))} error={passwordErrors.currentPassword} />
            <Input label={locale === 'ar' ? 'كلمة المرور الجديدة' : 'New password'} name="newPassword" type="password" value={passwordForm.newPassword} onChange={(event) => setPasswordForm((current) => ({ ...current, newPassword: event.target.value }))} error={passwordErrors.newPassword} />
            <Input label={locale === 'ar' ? 'تأكيد كلمة المرور الجديدة' : 'Confirm new password'} name="confirmPassword" type="password" value={passwordForm.confirmPassword} onChange={(event) => setPasswordForm((current) => ({ ...current, confirmPassword: event.target.value }))} error={passwordErrors.confirmPassword} />
            <Button type="submit" disabled={isLoading}>{locale === 'ar' ? 'تحديث كلمة المرور' : 'Update password'}</Button>
          </form>
        </Card>

        <Card className="p-6">
          <h2 className="mb-5 text-xl font-bold">{locale === 'ar' ? 'إعدادات الحساب' : 'Account settings'}</h2>
          <form className="grid gap-4" onSubmit={submitSettings}>
            <label className="flex items-start gap-3 rounded-2xl border p-4">
              <input className="mt-1 h-4 w-4" type="checkbox" checked={settingsForm.newsletter} onChange={(event) => setSettingsForm((current) => ({ ...current, newsletter: event.target.checked }))} />
              <span><strong>{locale === 'ar' ? 'النشرة الأسبوعية' : 'Weekly newsletter'}</strong><span className="mt-1 block text-sm text-muted-foreground">{locale === 'ar' ? 'استلام ملخص أسبوعي لأحدث أدوات الذكاء الاصطناعي.' : 'Receive a weekly digest of new AI tools.'}</span></span>
            </label>
            <label className="flex items-start gap-3 rounded-2xl border p-4">
              <input className="mt-1 h-4 w-4" type="checkbox" checked={settingsForm.productUpdates} onChange={(event) => setSettingsForm((current) => ({ ...current, productUpdates: event.target.checked }))} />
              <span><strong>{locale === 'ar' ? 'تحديثات المنتج' : 'Product updates'}</strong><span className="mt-1 block text-sm text-muted-foreground">{locale === 'ar' ? 'تلقي إشعارات حول التحسينات والميزات الجديدة.' : 'Receive notifications about improvements and new features.'}</span></span>
            </label>
            <Button type="submit" variant="outline" disabled={isLoading}>{locale === 'ar' ? 'حفظ الإعدادات' : 'Save settings'}</Button>
          </form>
        </Card>
      </div>
    </div>
  );
}
