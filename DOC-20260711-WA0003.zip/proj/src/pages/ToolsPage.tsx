import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Activity, Database, SlidersHorizontal, Sparkles, TrendingUp } from 'lucide-react';
import type { AITool, ToolCategory } from '@/types';
import type { ToolSortOption } from '@/types/database';
import { ToolCard } from '@/components/domain/ToolCard';
import { ToolFilters } from '@/components/domain/ToolFilters';
import { ToolShelf } from '@/components/domain/ToolShelf';
import { EmptyState } from '@/components/feedback/EmptyState';
import { ErrorState } from '@/components/feedback/ErrorState';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { Dropdown } from '@/components/ui/Dropdown';
import { Pagination } from '@/components/ui/Pagination';
import { SearchBar } from '@/components/ui/SearchBar';
import { Skeleton } from '@/components/ui/Skeleton';
import { StatCard } from '@/components/ui/StatCard';
import { useToast } from '@/components/ui/Toast';
import { getCategories, getFeaturedTools, getLatestTools, getMostUsedTools, getTools } from '@/services/toolService';
import { getUserFavoriteIds, toggleFavorite } from '@/services/favoriteService';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

export function ToolsPage() {
  const { locale } = useLocale();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();
  const [pricing, setPricing] = useState('all');
  const [platform, setPlatform] = useState('all');
  const [minRating, setMinRating] = useState<number | undefined>();
  const [selectedTag, setSelectedTag] = useState('all');
  const [sort, setSort] = useState<ToolSortOption>('top-rated');
  const [page, setPage] = useState(1);
  const [tools, setTools] = useState<AITool[]>([]);
  const [featuredTools, setFeaturedTools] = useState<AITool[]>([]);
  const [latestTools, setLatestTools] = useState<AITool[]>([]);
  const [popularTools, setPopularTools] = useState<AITool[]>([]);
  const [categories, setCategories] = useState<ToolCategory[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const selectedCategory = searchParams.get('category') ?? 'all';
  useSeo(locale === 'ar' ? 'الأدوات' : 'Tools');

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);
    setHasError(false);
    Promise.all([
      getTools({ category: selectedCategory, pricing, platform, tag: selectedTag === 'all' ? '' : selectedTag, minRating, sort, status: 'active' }),
      getFeaturedTools(4),
      getLatestTools(4),
      getMostUsedTools(4),
      getCategories(),
      user ? getUserFavoriteIds(user.id) : Promise.resolve(new Set<string>()),
    ])
      .then(([loadedTools, loadedFeatured, loadedLatest, loadedPopular, loadedCategories, loadedFavorites]) => {
        if (!isMounted) return;
        setTools(loadedTools);
        setFeaturedTools(loadedFeatured);
        setLatestTools(loadedLatest);
        setPopularTools(loadedPopular);
        setCategories(loadedCategories);
        setFavoriteIds(loadedFavorites);
      })
      .catch(() => {
        if (isMounted) setHasError(true);
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, [pricing, selectedCategory, platform, selectedTag, minRating, sort, user]);

  function updateCategory(category: string) {
    setPage(1);
    setSearchParams(category === 'all' ? {} : { category });
  }

  function updatePricing(nextPricing: string) {
    setPricing(nextPricing);
    setPage(1);
  }

  function updatePlatform(nextPlatform: string) {
    setPlatform(nextPlatform);
    setPage(1);
  }

  async function handleToggleFavorite(tool: AITool) {
    if (!user) {
      showToast({ title: locale === 'ar' ? 'سجّل الدخول أولًا' : 'Login required', description: locale === 'ar' ? 'يجب تسجيل الدخول لحفظ الأدوات.' : 'You need to sign in to save tools.', tone: 'error' });
      return;
    }
    const result = await toggleFavorite(user.id, tool.id);
    setFavoriteIds((current) => {
      const next = new Set(current);
      if (result.favorite) next.add(tool.id);
      else next.delete(tool.id);
      return next;
    });
    showToast({ title: result.favorite ? (locale === 'ar' ? 'تمت الإضافة للمفضلة' : 'Added to favorites') : (locale === 'ar' ? 'تمت الإزالة من المفضلة' : 'Removed from favorites'), tone: 'success' });
  }

  const pageSize = 9;
  const totalPages = Math.max(1, Math.ceil(tools.length / pageSize));
  const paginatedTools = useMemo(() => tools.slice((page - 1) * pageSize, page * pageSize), [page, tools]);
  const tagCloud = useMemo(() => {
    const tagMap = new Map<string, number>();
    [...featuredTools, ...latestTools, ...popularTools, ...tools].forEach((tool) => {
      tool.tags.forEach((tag) => tagMap.set(tag, (tagMap.get(tag) ?? 0) + 1));
    });
    return [...tagMap.entries()]
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .slice(0, 18)
      .map(([tag]) => tag);
  }, [featuredTools, latestTools, popularTools, tools]);

  return (
    <section className="section-padding">
      <div className="container">
        <div className="mb-8 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <Badge className="mb-3">{locale === 'ar' ? 'منصة الأدوات' : 'AI tools platform'}</Badge>
            <h1 className="text-4xl font-extrabold tracking-tight">{locale === 'ar' ? 'استكشف وأدر أدوات الذكاء الاصطناعي' : 'Explore and manage AI tools'}</h1>
            <p className="mt-3 max-w-2xl text-muted-foreground">{locale === 'ar' ? 'بحث متقدم، فلاتر متعددة، أدوات مميزة، أحدث الأدوات، والأكثر استخدامًا ضمن طبقة بيانات قابلة للتوسع.' : 'Advanced search, multi-filters, featured tools, latest tools, and most-used tools connected to a scalable data layer.'}</p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Dropdown
              label={locale === 'ar' ? 'الترتيب' : 'Sort'}
              items={[
                { label: locale === 'ar' ? 'الأعلى تقييمًا' : 'Top rated', onSelect: () => setSort('top-rated') },
                { label: locale === 'ar' ? 'الأحدث' : 'Newest', onSelect: () => setSort('newest') },
                { label: locale === 'ar' ? 'الأكثر استخدامًا' : 'Most used', onSelect: () => setSort('most-used') },
                { label: locale === 'ar' ? 'المميزة أولًا' : 'Featured first', onSelect: () => setSort('featured') },
              ]}
            />
            <span className="inline-flex h-11 items-center gap-2 rounded-xl border px-4 text-sm font-semibold"><SlidersHorizontal className="h-4 w-4" /> {locale === 'ar' ? 'فلاتر متقدمة' : 'Advanced filters'}</span>
          </div>
        </div>

        <div className="mb-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <StatCard label={locale === 'ar' ? 'كل الأدوات' : 'All tools'} value={String(tools.length)} change="Live" icon={<Database className="h-5 w-5" />} />
          <StatCard label={locale === 'ar' ? 'مميزة' : 'Featured'} value={String(featuredTools.length)} change="Curated" icon={<Sparkles className="h-5 w-5" />} />
          <StatCard label={locale === 'ar' ? 'الأحدث' : 'Latest'} value={String(latestTools.length)} change="Fresh" icon={<Activity className="h-5 w-5" />} />
          <StatCard label={locale === 'ar' ? 'الأكثر استخدامًا' : 'Most used'} value={String(popularTools.length)} change="Usage" icon={<TrendingUp className="h-5 w-5" />} />
        </div>

        {!isLoading && !hasError ? (
          <>
            <ToolShelf
              title={locale === 'ar' ? 'الأدوات المميزة' : 'Featured AI tools'}
              description={locale === 'ar' ? 'اختيارات بارزة تصلح كنقطة بداية للمستخدمين الجدد.' : 'Curated tools that work well as a starting stack for new users.'}
              tools={featuredTools}
              action={<Link className="focus-ring inline-flex h-11 items-center justify-center rounded-xl px-4 text-sm font-semibold transition hover:bg-muted" to="/search/results?sort=featured">{locale === 'ar' ? 'عرض المزيد' : 'View more'}</Link>}
            />
            <div className="mb-10 grid gap-5 xl:grid-cols-2">
              <ToolShelf
                title={locale === 'ar' ? 'أحدث الأدوات' : 'Newest tools'}
                description={locale === 'ar' ? 'أدوات أضيفت حديثًا إلى قاعدة البيانات المحلية.' : 'Recently added tools in the local catalog database.'}
                tools={latestTools}
              />
              <ToolShelf
                title={locale === 'ar' ? 'الأكثر استخدامًا' : 'Most used tools'}
                description={locale === 'ar' ? 'أدوات ذات انتشار واسع حسب مؤشرات الاستخدام داخل المكتبة.' : 'Widely adopted tools based on catalog usage indicators.'}
                tools={popularTools}
              />
            </div>
          </>
        ) : null}

        <div className="mb-8 grid gap-4 lg:grid-cols-[1fr_18rem]">
          <SearchBar showButton />
          <Card className="flex items-center justify-between p-4 text-sm">
            <span className="text-muted-foreground">{locale === 'ar' ? 'النتائج الحالية' : 'Current results'}</span>
            <strong>{tools.length}</strong>
          </Card>
        </div>

        {tagCloud.length ? (
          <Card className="mb-8 p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <strong>{locale === 'ar' ? 'وسوم شائعة' : 'Popular tags'}</strong>
              <span className="text-xs text-muted-foreground">{locale === 'ar' ? 'تدعم البحث بالكلمات المفتاحية' : 'Keyword search enabled'}</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {tagCloud.map((tag) => (
                <Link key={tag} className="rounded-full border px-3 py-1.5 text-xs font-semibold transition hover:border-primary hover:text-primary" to={`/search/results?q=${encodeURIComponent(tag)}`}>
                  {tag}
                </Link>
              ))}
            </div>
          </Card>
        ) : null}

        <div className="grid gap-8 lg:grid-cols-[18rem_1fr]">
          <ToolFilters
            selectedCategory={selectedCategory}
            selectedPricing={pricing}
            selectedPlatform={platform}
            minRating={minRating}
            selectedTag={selectedTag}
            tagOptions={tagCloud}
            categories={categories}
            onCategoryChange={updateCategory}
            onPricingChange={updatePricing}
            onPlatformChange={updatePlatform}
            onTagChange={(tag) => { setSelectedTag(tag); setPage(1); }}
            onMinRatingChange={(rating) => { setMinRating(rating); setPage(1); }}
            className="hidden lg:block"
          />
          <div>
            <div className="mb-4 flex flex-wrap gap-2 lg:hidden">
              <button className="rounded-xl bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground" onClick={() => updateCategory('all')} type="button">{locale === 'ar' ? 'الكل' : 'All'}</button>
              {categories.slice(0, 4).map((category) => <button key={category.slug} className="rounded-xl border px-3 py-2 text-sm" onClick={() => updateCategory(category.slug)} type="button">{locale === 'ar' ? category.nameAr : category.nameEn}</button>)}
            </div>
            {hasError ? (
              <ErrorState title={locale === 'ar' ? 'تعذر تحميل الأدوات' : 'Could not load tools'} description={locale === 'ar' ? 'حدث خطأ أثناء قراءة قاعدة البيانات المحلية.' : 'An error occurred while reading the local database.'} />
            ) : isLoading ? (
              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                {Array.from({ length: 9 }).map((_, index) => <Skeleton key={index} className="h-72" />)}
              </div>
            ) : paginatedTools.length ? (
              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                {paginatedTools.map((tool) => <ToolCard key={tool.id} tool={tool} isFavorite={favoriteIds.has(tool.id)} onToggleFavorite={handleToggleFavorite} />)}
              </div>
            ) : (
              <EmptyState title={locale === 'ar' ? 'لا توجد أدوات مطابقة' : 'No matching tools'} description={locale === 'ar' ? 'غيّر الفلاتر الحالية أو جرّب تصنيفًا مختلفًا.' : 'Change the current filters or try a different category.'} />
            )}
            {!hasError && !isLoading ? <Pagination className="mt-10" page={page} totalPages={totalPages} onPageChange={setPage} /> : null}
          </div>
        </div>
      </div>
    </section>
  );
}
