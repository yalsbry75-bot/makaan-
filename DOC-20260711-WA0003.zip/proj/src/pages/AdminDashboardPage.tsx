import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, BarChart3, Boxes, Clock3, Database, MessageSquareWarning, Star, Tags, UsersRound } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { StatCard } from '@/components/ui/StatCard';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import { getAdminOverviewStats, type AdminOverviewStats } from '@/services/adminService';

export function AdminDashboardPage() {
  const { locale } = useLocale();
  const [stats, setStats] = useState<AdminOverviewStats | null>(null);
  useSeo(locale === 'ar' ? 'لوحة الإدارة الرئيسية' : 'Admin overview');

  useEffect(() => {
    let mounted = true;
    getAdminOverviewStats().then((data) => {
      if (mounted) setStats(data);
    });
    return () => { mounted = false; };
  }, []);

  if (!stats) {
    return <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 8 }).map((_, index) => <Skeleton key={index} className="h-32" />)}</div>;
  }

  const cards = [
    { label: locale === 'ar' ? 'عدد المستخدمين' : 'Users', value: stats.usersCount, change: `${stats.activeUsersCount} active`, icon: <UsersRound className="h-5 w-5" /> },
    { label: locale === 'ar' ? 'عدد الأدوات' : 'Tools', value: stats.toolsCount, change: `${stats.activeToolsCount} active`, icon: <Boxes className="h-5 w-5" /> },
    { label: locale === 'ar' ? 'عدد التصنيفات' : 'Categories', value: stats.categoriesCount, change: 'taxonomy', icon: <Tags className="h-5 w-5" /> },
    { label: locale === 'ar' ? 'عدد التقييمات' : 'Reviews', value: stats.reviewsCount, change: `${stats.pendingReviewsCount} pending`, icon: <Star className="h-5 w-5" /> },
    { label: locale === 'ar' ? 'عدد الزيارات' : 'Visits', value: stats.visitsCount.toLocaleString(), change: 'simulated analytics', icon: <BarChart3 className="h-5 w-5" /> },
    { label: locale === 'ar' ? 'رسائل التواصل' : 'Messages', value: stats.contactMessagesCount, change: 'support inbox', icon: <MessageSquareWarning className="h-5 w-5" /> },
  ];

  return (
    <div className="grid gap-6">
      <SectionHeader
        title={locale === 'ar' ? 'لوحة الإدارة الرئيسية' : 'Admin overview'}
        description={locale === 'ar' ? 'نظرة شاملة على حالة المنصة، المستخدمين، الأدوات، المراجعات، البلاغات، ومؤشرات الأداء.' : 'A unified view of platform health, users, tools, reviews, reports, and performance indicators.'}
        action={<div className="flex flex-wrap gap-2"><Link className="focus-ring inline-flex h-11 items-center justify-center rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-card transition hover:bg-primary/90" to="/admin/tools">{locale === 'ar' ? 'إدارة الأدوات' : 'Manage tools'}</Link><Link className="focus-ring inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-background px-4 text-sm font-semibold transition hover:bg-muted" to="/admin/system"><Activity className="h-4 w-4" />{locale === 'ar' ? 'صحة النظام' : 'System health'}</Link></div>}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {cards.map((card) => <StatCard key={card.label} label={card.label} value={String(card.value)} change={card.change} icon={card.icon} />)}
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="p-5 xl:col-span-2">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h2 className="text-xl font-bold">{locale === 'ar' ? 'أكثر الأدوات استخدامًا' : 'Most used tools'}</h2>
            <Link className="text-sm font-semibold text-primary" to="/admin/tools">{locale === 'ar' ? 'عرض الكل' : 'View all'}</Link>
          </div>
          <div className="grid gap-3">
            {stats.topTools.map((tool, index) => (
              <div key={tool.id} className="flex items-center justify-between gap-4 rounded-2xl border bg-muted/30 p-4">
                <div className="flex items-center gap-3">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-sm font-black text-primary">{index + 1}</span>
                  <div><p className="font-bold">{tool.name}</p><p className="text-xs text-muted-foreground">{tool.users} · ★ {tool.rating}</p></div>
                </div>
                <Badge variant="success">{locale === 'ar' ? 'نشطة' : 'Active'}</Badge>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="mb-4 text-xl font-bold">{locale === 'ar' ? 'أحدث الأدوات' : 'Latest tools'}</h2>
          <div className="grid gap-3">
            {stats.latestTools.map((tool) => (
              <div key={tool.id} className="rounded-2xl border p-3">
                <div className="flex items-center gap-2 text-sm font-bold"><Clock3 className="h-4 w-4 text-primary" /> {tool.name}</div>
                <p className="mt-1 text-xs text-muted-foreground">{tool.addedAt ?? tool.lastUpdatedAt ?? 'Recently updated'}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="p-5">
        <div className="mb-4 flex items-center gap-2"><Database className="h-5 w-5 text-primary" /><h2 className="text-xl font-bold">{locale === 'ar' ? 'أكثر التصنيفات نشاطًا' : 'Most active categories'}</h2></div>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
          {stats.activeCategories.map((category) => (
            <div key={category.slug} className="rounded-2xl border bg-muted/20 p-4">
              <p className="font-bold">{locale === 'ar' ? category.nameAr : category.nameEn}</p>
              <p className="mt-2 text-2xl font-black text-primary">{category.toolsCount}</p>
              <p className="text-xs text-muted-foreground">{locale === 'ar' ? 'أداة مرتبطة' : 'linked tools'}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
