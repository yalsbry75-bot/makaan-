import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquareText, Star, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { EmptyState } from '@/components/feedback/EmptyState';
import { deleteUserReview } from '@/services/reviewService';
import { getUserReviewsWithTools } from '@/services/userWorkspaceService';
import type { UserReviewWithTool } from '@/services/userWorkspaceService';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

export function UserReviewsPage() {
  const { locale } = useLocale();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [reviews, setReviews] = useState<UserReviewWithTool[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  useSeo(locale === 'ar' ? 'مراجعاتي' : 'My reviews');

  useEffect(() => {
    if (!user) return;
    let mounted = true;
    setIsLoading(true);
    getUserReviewsWithTools(user.id)
      .then((items) => {
        if (mounted) setReviews(items);
      })
      .finally(() => {
        if (mounted) setIsLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, [user]);

  async function removeReview(reviewId: string) {
    if (!user) return;
    await deleteUserReview(reviewId, user.id);
    setReviews((current) => current.filter((review) => review.id !== reviewId));
    showToast({ title: locale === 'ar' ? 'تم حذف المراجعة' : 'Review deleted', tone: 'success' });
  }

  return (
    <div className="grid gap-6">
      <SectionHeader
        title={locale === 'ar' ? 'مراجعاتي' : 'My reviews'}
        description={locale === 'ar' ? 'إدارة مراجعاتك للأدوات ومتابعة حالة اعتمادها من لوحة واحدة.' : 'Manage your tool reviews and track moderation status from one place.'}
      />

      {isLoading ? (
        <div className="grid gap-4">{Array.from({ length: 3 }).map((_, index) => <Skeleton key={index} className="h-36" />)}</div>
      ) : reviews.length ? (
        <div className="grid gap-4">
          {reviews.map((review) => (
            <Card key={review.id} className="p-5">
              <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-start">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="text-lg font-bold">{review.title}</h2>
                    <Badge variant={review.status === 'approved' ? 'success' : review.status === 'pending' ? 'warning' : 'muted'}>{review.status}</Badge>
                  </div>
                  <Link className="mt-1 inline-flex text-sm font-semibold text-primary hover:underline" to={review.tool ? `/tools/${review.tool.slug}` : '/tools'}>{review.tool?.name ?? (locale === 'ar' ? 'أداة غير متاحة' : 'Unavailable tool')}</Link>
                  <div className="mt-3 flex items-center gap-1 text-sm font-bold text-accent">
                    {Array.from({ length: 5 }).map((_, index) => <Star key={index} className={index < review.rating ? 'h-4 w-4 fill-current' : 'h-4 w-4 text-muted-foreground'} />)}
                    <span className="ms-2 text-foreground">{review.rating}/5</span>
                  </div>
                  <p className="mt-3 text-sm leading-6 text-muted-foreground">{review.comment}</p>
                  <p className="mt-2 text-xs text-muted-foreground">{locale === 'ar' ? 'آخر تحديث:' : 'Updated:'} {new Date(review.updatedAt).toLocaleDateString(locale === 'ar' ? 'ar' : 'en')}</p>
                </div>
                <Button variant="outline" onClick={() => removeReview(review.id)}><Trash2 className="h-4 w-4" /> {locale === 'ar' ? 'حذف' : 'Delete'}</Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState title={locale === 'ar' ? 'لا توجد مراجعات' : 'No reviews yet'} description={locale === 'ar' ? 'اكتب مراجعتك من صفحة تفاصيل أي أداة بعد تسجيل الدخول.' : 'Write your first review from any tool details page after signing in.'} action={<MessageSquareText className="h-5 w-5 text-primary" />} />
      )}
    </div>
  );
}
