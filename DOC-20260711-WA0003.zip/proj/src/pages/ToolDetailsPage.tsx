import { FormEvent, useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, Copy, ExternalLink, Flag, Globe2, Heart, MonitorSmartphone, Share2, Star, Trash2, UsersRound } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import type { AITool } from '@/types';
import type { ReviewRecord } from '@/types/database';
import { ToolCard } from '@/components/domain/ToolCard';
import { EmptyState } from '@/components/feedback/EmptyState';
import { ErrorState } from '@/components/feedback/ErrorState';
import { Badge } from '@/components/ui/Badge';
import { Breadcrumbs } from '@/components/ui/Breadcrumbs';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { StatCard } from '@/components/ui/StatCard';
import { useToast } from '@/components/ui/Toast';
import { getTool, getRelatedTools, getMostUsedTools } from '@/services/toolService';
import { createReview, deleteUserReview, getReviewsForTool, getUserReviewForTool, reportReview, updateUserReview } from '@/services/reviewService';
import { isToolFavorite, toggleFavorite } from '@/services/favoriteService';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import { categoryName, formatRating, pricingLabel } from '@/utils/format';
import { platformLabel } from '@/utils/toolNormalization';

function statusLabel(status: ReviewRecord['status'], locale: 'ar' | 'en') {
  const labels: Record<ReviewRecord['status'], { ar: string; en: string }> = {
    approved: { ar: 'معتمدة', en: 'Approved' },
    pending: { ar: 'بانتظار المراجعة', en: 'Pending' },
    rejected: { ar: 'مرفوضة', en: 'Rejected' },
  };
  return labels[status][locale];
}

export function ToolDetailsPage() {
  const { slug } = useParams();
  const { user } = useAuth();
  const { locale, direction } = useLocale();
  const { showToast } = useToast();
  const [tool, setTool] = useState<AITool | null>(null);
  const [relatedTools, setRelatedTools] = useState<AITool[]>([]);
  const [recommendedTools, setRecommendedTools] = useState<AITool[]>([]);
  const [reviews, setReviews] = useState<ReviewRecord[]>([]);
  const [userReview, setUserReview] = useState<ReviewRecord | null>(null);
  const [favorite, setFavorite] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const ArrowIcon = direction === 'rtl' ? ArrowLeft : ArrowRight;
  const pageUrl = typeof window !== 'undefined' ? window.location.href : '';
  useSeo(tool ? tool.name : locale === 'ar' ? 'تفاصيل الأداة' : 'Tool details');

  async function loadToolDetails(isMountedRef?: { current: boolean }) {
    const loadedTool = await getTool(slug);
    if (isMountedRef && !isMountedRef.current) return;
    setTool(loadedTool);
    if (!loadedTool) return;
    const [loadedRelated, loadedRecommended, loadedReviews, loadedUserReview, loadedFavorite] = await Promise.all([
      getRelatedTools(loadedTool, 3),
      getMostUsedTools(4),
      getReviewsForTool(loadedTool.id, user?.id),
      user ? getUserReviewForTool(user.id, loadedTool.id) : Promise.resolve(null),
      user ? isToolFavorite(user.id, loadedTool.id) : Promise.resolve(false),
    ]);
    if (isMountedRef && !isMountedRef.current) return;
    setRelatedTools(loadedRelated);
    setRecommendedTools(loadedRecommended.filter((item) => item.id !== loadedTool.id).slice(0, 3));
    setReviews(loadedReviews);
    setUserReview(loadedUserReview);
    setFavorite(loadedFavorite);
    if (loadedUserReview) {
      setReviewRating(loadedUserReview.rating);
      setReviewTitle(loadedUserReview.title);
      setReviewComment(loadedUserReview.comment);
    } else {
      setReviewRating(5);
      setReviewTitle('');
      setReviewComment('');
    }
  }

  useEffect(() => {
    const isMountedRef = { current: true };
    setIsLoading(true);
    setHasError(false);
    loadToolDetails(isMountedRef)
      .catch(() => {
        if (isMountedRef.current) setHasError(true);
      })
      .finally(() => {
        if (isMountedRef.current) setIsLoading(false);
      });
    return () => {
      isMountedRef.current = false;
    };
  }, [slug, user]);

  async function handleFavorite() {
    if (!tool) return;
    if (!user) {
      showToast({ title: locale === 'ar' ? 'سجّل الدخول أولًا' : 'Login required', description: locale === 'ar' ? 'يجب تسجيل الدخول لحفظ الأدوات.' : 'You need to sign in to save tools.', tone: 'error' });
      return;
    }
    const result = await toggleFavorite(user.id, tool.id);
    setFavorite(result.favorite);
    showToast({ title: result.favorite ? (locale === 'ar' ? 'تمت الإضافة للمفضلة' : 'Added to favorites') : (locale === 'ar' ? 'تمت الإزالة من المفضلة' : 'Removed from favorites'), tone: 'success' });
  }

  async function handleShare() {
    if (!tool) return;
    const shareData = { title: tool.name, text: locale === 'ar' ? tool.taglineAr : tool.taglineEn, url: pageUrl };
    if (navigator.share) {
      await navigator.share(shareData).catch(() => undefined);
      return;
    }
    await navigator.clipboard?.writeText(pageUrl);
    showToast({ title: locale === 'ar' ? 'تم نسخ الرابط' : 'Link copied', tone: 'success' });
  }

  async function handleCopyLink() {
    await navigator.clipboard?.writeText(pageUrl);
    showToast({ title: locale === 'ar' ? 'تم نسخ رابط الأداة' : 'Tool link copied', tone: 'success' });
  }

  async function handleReviewSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!tool) return;
    if (!user) {
      showToast({ title: locale === 'ar' ? 'سجّل الدخول أولًا' : 'Login required', description: locale === 'ar' ? 'يجب تسجيل الدخول لكتابة مراجعة.' : 'You need to sign in to write a review.', tone: 'error' });
      return;
    }
    if (!reviewTitle.trim() || reviewComment.trim().length < 10) {
      showToast({ title: locale === 'ar' ? 'بيانات المراجعة غير مكتملة' : 'Review is incomplete', description: locale === 'ar' ? 'اكتب عنوانًا وتعليقًا لا يقل عن 10 أحرف.' : 'Add a title and a comment of at least 10 characters.', tone: 'error' });
      return;
    }
    setIsSubmittingReview(true);
    try {
      if (userReview) {
        await updateUserReview(userReview.id, user.id, { rating: reviewRating, title: reviewTitle.trim(), comment: reviewComment.trim() });
        showToast({ title: locale === 'ar' ? 'تم تحديث المراجعة' : 'Review updated', description: locale === 'ar' ? 'أُعيدت المراجعة إلى قائمة الاعتماد.' : 'The review was sent back to moderation.', tone: 'success' });
      } else {
        await createReview({ userId: user.id, toolId: tool.id, rating: reviewRating, title: reviewTitle.trim(), comment: reviewComment.trim() });
        showToast({ title: locale === 'ar' ? 'تم إرسال المراجعة' : 'Review submitted', description: locale === 'ar' ? 'ستظهر بعد اعتمادها من الإدارة.' : 'It will appear after admin approval.', tone: 'success' });
      }
      await loadToolDetails();
    } catch (error) {
      showToast({ title: locale === 'ar' ? 'تعذر حفظ المراجعة' : 'Could not save review', description: error instanceof Error ? error.message : undefined, tone: 'error' });
    } finally {
      setIsSubmittingReview(false);
    }
  }

  async function handleDeleteReview() {
    if (!user || !userReview) return;
    await deleteUserReview(userReview.id, user.id);
    setUserReview(null);
    setReviewTitle('');
    setReviewComment('');
    setReviewRating(5);
    await loadToolDetails();
    showToast({ title: locale === 'ar' ? 'تم حذف مراجعتك' : 'Your review was deleted', tone: 'success' });
  }

  async function handleReportReview(review: ReviewRecord) {
    if (!user) {
      showToast({ title: locale === 'ar' ? 'سجّل الدخول أولًا' : 'Login required', description: locale === 'ar' ? 'يجب تسجيل الدخول للإبلاغ عن مراجعة.' : 'You need to sign in to report a review.', tone: 'error' });
      return;
    }
    await reportReview(user.id, review.id, 'User reported this review from the tool details page.');
    showToast({ title: locale === 'ar' ? 'تم إرسال البلاغ' : 'Report submitted', description: locale === 'ar' ? 'سيظهر البلاغ في لوحة الإدارة.' : 'The report is now visible in the admin dashboard.', tone: 'success' });
  }

  const approvedReviews = useMemo(() => reviews.filter((review) => review.status === 'approved'), [reviews]);

  if (isLoading) {
    return (
      <section className="section-padding">
        <div className="container grid gap-6 lg:grid-cols-[1fr_22rem]">
          <Skeleton className="h-[32rem]" />
          <Skeleton className="h-[32rem]" />
        </div>
      </section>
    );
  }

  if (hasError) {
    return <section className="section-padding"><div className="container"><ErrorState title={locale === 'ar' ? 'تعذر تحميل الأداة' : 'Could not load tool'} description={locale === 'ar' ? 'حدث خطأ أثناء قراءة بيانات الأداة.' : 'An error occurred while reading the tool data.'} /></div></section>;
  }

  if (!tool) {
    return <section className="section-padding"><div className="container"><EmptyState title={locale === 'ar' ? 'الأداة غير موجودة' : 'Tool not found'} description={locale === 'ar' ? 'قد تكون الأداة مخفية أو تم حذفها.' : 'The tool may be hidden or deleted.'} /></div></section>;
  }

  const platforms = tool.platform ?? ['web'];
  const updatedDate = tool.lastUpdatedAt ? new Date(tool.lastUpdatedAt).toLocaleDateString(locale === 'ar' ? 'ar-SA' : 'en-US') : tool.launchYear;
  const addedDate = tool.addedAt ? new Date(tool.addedAt).toLocaleDateString(locale === 'ar' ? 'ar-SA' : 'en-US') : tool.launchYear;
  const averageRating = approvedReviews.length ? approvedReviews.reduce((sum, review) => sum + review.rating, 0) / approvedReviews.length : tool.rating;

  return (
    <section className="section-padding">
      <div className="container">
        <Breadcrumbs items={[{ label: locale === 'ar' ? 'الأدوات' : 'Tools', href: '/tools' }, { label: tool.name }]} className="mb-8" />

        <div className="grid gap-8 lg:grid-cols-[1fr_22rem]">
          <main className="grid gap-6">
            <Card className="overflow-hidden">
              <div className={`bg-gradient-to-br ${tool.logoGradient} p-8 text-white`}>
                <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
                  <div>
                    <div className="mb-5 grid h-16 w-16 place-items-center rounded-3xl bg-white/15 text-xl font-extrabold shadow-card backdrop-blur">
                      {tool.logoUrl ? <img alt="" className="h-12 w-12 rounded-2xl object-cover" loading="lazy" src={tool.logoUrl} /> : tool.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {tool.featured ? <Badge variant="warning">{locale === 'ar' ? 'أداة مميزة' : 'Featured'}</Badge> : null}
                      {tool.verified ? <Badge variant="success">{locale === 'ar' ? 'موثقة' : 'Verified'}</Badge> : null}
                      <Badge variant="muted">{pricingLabel(tool.pricing, locale)}</Badge>
                    </div>
                    <h1 className="mt-4 text-4xl font-extrabold md:text-5xl">{tool.name}</h1>
                    <p className="mt-4 max-w-3xl text-white/85">{locale === 'ar' ? tool.taglineAr : tool.taglineEn}</p>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <Button variant="secondary" onClick={handleFavorite}><Heart className={favorite ? 'h-4 w-4 fill-current' : 'h-4 w-4'} /> {favorite ? (locale === 'ar' ? 'محفوظة' : 'Saved') : (locale === 'ar' ? 'حفظ' : 'Save')}</Button>
                    <Button variant="secondary" onClick={handleShare}><Share2 className="h-4 w-4" /> {locale === 'ar' ? 'مشاركة' : 'Share'}</Button>
                    <Button onClick={() => window.open(tool.website.startsWith('http') ? tool.website : `https://${tool.website}`, '_blank', 'noopener,noreferrer')}><ExternalLink className="h-4 w-4" /> {locale === 'ar' ? 'زيارة الموقع' : 'Visit site'}</Button>
                  </div>
                </div>
              </div>
              <div className="grid gap-4 p-6 md:grid-cols-3">
                <StatCard label={locale === 'ar' ? 'متوسط التقييم' : 'Average rating'} value={formatRating(averageRating, locale)} change={`${approvedReviews.length || tool.reviewsCount || 0} reviews`} icon={<Star className="h-5 w-5" />} />
                <StatCard label={locale === 'ar' ? 'المستخدمون' : 'Users'} value={tool.users} change={locale === 'ar' ? 'تقديري' : 'Estimated'} icon={<UsersRound className="h-5 w-5" />} />
                <StatCard label={locale === 'ar' ? 'آخر تحديث' : 'Updated'} value={updatedDate} change={locale === 'ar' ? 'قاعدة البيانات' : 'Database'} icon={<CheckCircle2 className="h-5 w-5" />} />
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="mb-3 text-2xl font-bold">{locale === 'ar' ? 'الوصف الكامل' : 'Full description'}</h2>
              <p className="leading-8 text-muted-foreground">{locale === 'ar' ? tool.fullDescriptionAr ?? tool.descriptionAr : tool.fullDescriptionEn ?? tool.descriptionEn}</p>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
              <Card className="p-6">
                <h2 className="mb-4 text-xl font-bold">{locale === 'ar' ? 'المميزات' : 'Features'}</h2>
                <div className="grid gap-3">{(locale === 'ar' ? tool.featuresAr : tool.featuresEn).map((feature) => <p key={feature} className="flex items-start gap-2 text-sm text-muted-foreground"><CheckCircle2 className="mt-0.5 h-4 w-4 text-primary" /> {feature}</p>)}</div>
              </Card>
              <Card className="p-6">
                <h2 className="mb-4 text-xl font-bold">{locale === 'ar' ? 'حالات الاستخدام' : 'Use cases'}</h2>
                <div className="grid gap-3">{(locale === 'ar' ? tool.useCasesAr : tool.useCasesEn).map((useCase) => <p key={useCase} className="flex items-start gap-2 text-sm text-muted-foreground"><ArrowIcon className="mt-0.5 h-4 w-4 text-primary" /> {useCase}</p>)}</div>
              </Card>
            </div>

            <Card className="p-6">
              <div className="mb-5 flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                <div>
                  <h2 className="text-xl font-bold">{locale === 'ar' ? 'التقييمات والمراجعات' : 'Ratings and reviews'}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{locale === 'ar' ? 'اكتب مراجعة، عدّلها، احذفها، أو أبلغ عن مراجعة مخالفة.' : 'Write, edit, delete, or report reviews.'}</p>
                </div>
                <Badge variant="muted">{formatRating(averageRating, locale)} · {approvedReviews.length} {locale === 'ar' ? 'معتمدة' : 'approved'}</Badge>
              </div>

              <form className="mb-6 grid gap-4 rounded-2xl border bg-muted/30 p-4" onSubmit={handleReviewSubmit}>
                <div className="grid gap-4 md:grid-cols-[10rem_1fr]">
                  <label className="grid gap-2 text-sm font-semibold">
                    {locale === 'ar' ? 'التقييم' : 'Rating'}
                    <select className="focus-ring h-11 rounded-xl border bg-background px-3 text-sm outline-none" value={reviewRating} onChange={(event) => setReviewRating(Number(event.target.value))}>
                      {[5, 4, 3, 2, 1].map((rating) => <option key={rating} value={rating}>{rating} / 5</option>)}
                    </select>
                  </label>
                  <Input label={locale === 'ar' ? 'عنوان المراجعة' : 'Review title'} value={reviewTitle} onChange={(event) => setReviewTitle(event.target.value)} placeholder={locale === 'ar' ? 'مثال: تجربة عملية ومفيدة' : 'Example: Practical and useful'} />
                </div>
                <label className="grid gap-2 text-sm font-semibold">
                  {locale === 'ar' ? 'التعليق' : 'Comment'}
                  <textarea className="focus-ring min-h-28 rounded-xl border bg-background p-3 text-sm outline-none" value={reviewComment} onChange={(event) => setReviewComment(event.target.value)} placeholder={locale === 'ar' ? 'اكتب تجربتك مع الأداة بوضوح...' : 'Write your experience with this tool clearly...'} />
                </label>
                {userReview ? <Badge variant={userReview.status === 'approved' ? 'success' : userReview.status === 'pending' ? 'warning' : 'muted'}>{statusLabel(userReview.status, locale)}</Badge> : null}
                <div className="flex flex-wrap gap-3">
                  <Button disabled={isSubmittingReview} type="submit">{userReview ? (locale === 'ar' ? 'تحديث المراجعة' : 'Update review') : (locale === 'ar' ? 'إرسال المراجعة' : 'Submit review')}</Button>
                  {userReview ? <Button disabled={isSubmittingReview} type="button" variant="outline" onClick={handleDeleteReview}><Trash2 className="h-4 w-4" /> {locale === 'ar' ? 'حذف مراجعتي' : 'Delete my review'}</Button> : null}
                </div>
              </form>

              {reviews.length ? (
                <div className="grid gap-3">
                  {reviews.map((review) => (
                    <div key={review.id} className="rounded-2xl border p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <div className="flex flex-wrap items-center gap-2"><strong>{review.title}</strong><Badge variant={review.status === 'approved' ? 'success' : review.status === 'pending' ? 'warning' : 'muted'}>{statusLabel(review.status, locale)}</Badge></div>
                          <p className="mt-2 text-sm text-muted-foreground">{review.comment}</p>
                        </div>
                        <div className="flex shrink-0 items-center gap-2">
                          <span className="flex items-center gap-1 text-sm"><Star className="h-4 w-4 fill-accent text-accent" /> {review.rating}</span>
                          {review.userId !== user?.id ? <button className="rounded-full p-2 text-muted-foreground transition hover:bg-muted hover:text-destructive" type="button" onClick={() => handleReportReview(review)} aria-label="Report review"><Flag className="h-4 w-4" /></button> : null}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : <p className="text-sm text-muted-foreground">{locale === 'ar' ? 'لا توجد تقييمات بعد.' : 'No reviews yet.'}</p>}
            </Card>
          </main>

          <aside className="grid content-start gap-6">
            <Card className="p-6">
              <h2 className="mb-4 text-xl font-bold">{locale === 'ar' ? 'معلومات الأداة' : 'Tool info'}</h2>
              <dl className="grid gap-3 text-sm">
                <div className="flex justify-between gap-4"><dt className="text-muted-foreground">{locale === 'ar' ? 'التصنيف' : 'Category'}</dt><dd className="font-semibold">{categoryName(tool.categorySlug, locale)}</dd></div>
                <div className="flex justify-between gap-4"><dt className="text-muted-foreground">{locale === 'ar' ? 'السعر' : 'Pricing'}</dt><dd className="font-semibold">{pricingLabel(tool.pricing, locale)}</dd></div>
                <div className="flex justify-between gap-4"><dt className="text-muted-foreground">{locale === 'ar' ? 'تاريخ الإضافة' : 'Added'}</dt><dd className="font-semibold">{addedDate}</dd></div>
                <div className="flex justify-between gap-4"><dt className="text-muted-foreground">{locale === 'ar' ? 'الحالة' : 'Status'}</dt><dd className="font-semibold">{tool.visibilityStatus === 'hidden' ? (locale === 'ar' ? 'مخفية' : 'Hidden') : (locale === 'ar' ? 'نشطة' : 'Active')}</dd></div>
              </dl>
            </Card>
            <Card className="p-6">
              <h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><Share2 className="h-5 w-5 text-primary" /> {locale === 'ar' ? 'المشاركة' : 'Share'}</h2>
              <div className="grid gap-3">
                <Button fullWidth variant="outline" onClick={handleCopyLink}><Copy className="h-4 w-4" /> {locale === 'ar' ? 'نسخ الرابط' : 'Copy link'}</Button>
                <Button fullWidth variant="outline" onClick={handleShare}><Share2 className="h-4 w-4" /> {locale === 'ar' ? 'مشاركة الأداة' : 'Share tool'}</Button>
              </div>
            </Card>
            <Card className="p-6"><h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><MonitorSmartphone className="h-5 w-5 text-primary" /> {locale === 'ar' ? 'المنصات' : 'Platforms'}</h2><div className="flex flex-wrap gap-2">{platforms.map((platform) => <Badge key={platform} variant="muted">{platformLabel(platform, locale)}</Badge>)}</div></Card>
            <Card className="p-6"><h2 className="mb-4 text-xl font-bold">{locale === 'ar' ? 'الوسوم' : 'Tags'}</h2><div className="flex flex-wrap gap-2">{tool.tags.map((tag) => <Badge key={tag} variant="muted">{tag}</Badge>)}</div></Card>
            <Card className="p-6"><h2 className="mb-4 text-xl font-bold">{locale === 'ar' ? 'التكاملات' : 'Integrations'}</h2><div className="flex flex-wrap gap-2">{tool.integrations.map((integration) => <Badge key={integration} variant="muted">{integration}</Badge>)}</div></Card>
            <Card className="p-6"><h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><Globe2 className="h-5 w-5 text-primary" /> {locale === 'ar' ? 'اللغات' : 'Languages'}</h2><div className="flex flex-wrap gap-2">{tool.supportedLanguages.map((language) => <Badge key={language} variant="muted">{language}</Badge>)}</div></Card>
          </aside>
        </div>

        {relatedTools.length ? <div className="mt-14"><SectionHeader title={locale === 'ar' ? 'أدوات مشابهة' : 'Similar tools'} description={locale === 'ar' ? 'اقتراحات من نفس التصنيف والوسوم اعتمادًا على قاعدة البيانات.' : 'Suggestions based on category and tag similarity.'} /><div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{relatedTools.map((relatedTool) => <ToolCard key={relatedTool.id} tool={relatedTool} />)}</div></div> : null}
        {recommendedTools.length ? <div className="mt-14"><SectionHeader title={locale === 'ar' ? 'أدوات مقترحة' : 'Suggested tools'} description={locale === 'ar' ? 'أدوات واسعة الاستخدام من تصنيفات مختلفة لاستكمال تجربة المقارنة.' : 'Widely used tools from different categories to complete the comparison experience.'} /><div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{recommendedTools.map((recommendedTool) => <ToolCard key={recommendedTool.id} tool={recommendedTool} />)}</div></div> : null}

        <div className="mt-10"><Link className="inline-flex items-center gap-2 text-sm font-semibold text-primary" to="/tools"><ArrowIcon className="h-4 w-4" /> {locale === 'ar' ? 'العودة إلى الأدوات' : 'Back to tools'}</Link></div>
      </div>
    </section>
  );
}
