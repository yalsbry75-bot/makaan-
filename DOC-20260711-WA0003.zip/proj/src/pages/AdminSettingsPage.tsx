import { FormEvent, useEffect, useState } from 'react';
import { Globe2, Save, SearchCode, Settings2 } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import type { PlatformSettingsRecord } from '@/types/database';
import { getAdminSettings, updatePlatformSetting } from '@/services/adminService';

function valueToString(value: PlatformSettingsRecord['value']) {
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

function parseValue(value: string): PlatformSettingsRecord['value'] {
  if (value === 'true') return true;
  if (value === 'false') return false;
  const numeric = Number(value);
  if (!Number.isNaN(numeric) && value.trim() !== '') return numeric;
  try {
    const parsed = JSON.parse(value);
    if (typeof parsed === 'object') return parsed as PlatformSettingsRecord['value'];
  } catch {
    // Keep as string for plain settings values.
  }
  return value;
}

export function AdminSettingsPage() {
  const { locale } = useLocale();
  const { showToast } = useToast();
  const [settings, setSettings] = useState<PlatformSettingsRecord[]>([]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  useSeo(locale === 'ar' ? 'إعدادات الموقع' : 'Site settings');

  async function refresh() {
    setLoading(true);
    const items = await getAdminSettings();
    setSettings(items);
    setValues(Object.fromEntries(items.map((item) => [item.id, valueToString(item.value)])));
    setLoading(false);
  }

  useEffect(() => { refresh().catch(() => setLoading(false)); }, []);

  async function saveSettings(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    try {
      await Promise.all(settings.map((setting) => updatePlatformSetting(setting.id, parseValue(values[setting.id] ?? ''))));
      await refresh();
      showToast({ title: locale === 'ar' ? 'تم حفظ إعدادات الموقع' : 'Site settings saved', tone: 'success' });
    } catch (error) {
      showToast({ title: locale === 'ar' ? 'تعذر حفظ الإعدادات' : 'Could not save settings', description: error instanceof Error ? error.message : undefined, tone: 'error' });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid gap-6">
      <SectionHeader title={locale === 'ar' ? 'إعدادات الموقع' : 'Site settings'} description={locale === 'ar' ? 'إدارة اسم الموقع، الوصف، اللغات، إعدادات SEO، وإعدادات النظام العامة.' : 'Manage platform name, description, languages, SEO, and general system settings.'} />

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-5"><Settings2 className="mb-3 h-5 w-5 text-primary" /><p className="font-bold">{locale === 'ar' ? 'إعدادات عامة' : 'General settings'}</p><p className="text-sm text-muted-foreground">{locale === 'ar' ? 'اسم المنصة والوضع الافتراضي.' : 'Platform name and defaults.'}</p></Card>
        <Card className="p-5"><Globe2 className="mb-3 h-5 w-5 text-primary" /><p className="font-bold">{locale === 'ar' ? 'اللغات' : 'Languages'}</p><p className="text-sm text-muted-foreground">Arabic / English</p></Card>
        <Card className="p-5"><SearchCode className="mb-3 h-5 w-5 text-primary" /><p className="font-bold">SEO</p><p className="text-sm text-muted-foreground">{locale === 'ar' ? 'وصف وفهرسة أساسية.' : 'Metadata and discoverability.'}</p></Card>
      </div>

      <Card className="p-5">
        {loading ? <div className="grid gap-3">{Array.from({ length: 5 }).map((_, index) => <Skeleton key={index} className="h-16" />)}</div> : (
          <form className="grid gap-4" onSubmit={saveSettings}>
            {settings.map((setting) => (
              <div key={setting.id} className="grid gap-3 rounded-2xl border p-4 md:grid-cols-[16rem_1fr_auto] md:items-center">
                <div><p className="font-bold">{setting.key}</p><p className="text-xs text-muted-foreground">{new Date(setting.updatedAt).toLocaleDateString(locale === 'ar' ? 'ar' : 'en')}</p></div>
                <Input value={values[setting.id] ?? ''} onChange={(e) => setValues((current) => ({ ...current, [setting.id]: e.target.value }))} />
                <Badge variant="muted">{typeof setting.value}</Badge>
              </div>
            ))}
            <div className="flex justify-end"><Button type="submit" disabled={saving}><Save className="h-4 w-4" /> {saving ? (locale === 'ar' ? 'جارٍ الحفظ...' : 'Saving...') : (locale === 'ar' ? 'حفظ الإعدادات' : 'Save settings')}</Button></div>
          </form>
        )}
      </Card>
    </div>
  );
}
