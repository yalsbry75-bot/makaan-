/**
 * Privacy Policy Page — AI Hub Arabia
 * سياسة الخصوصية — منصة AI Hub Arabia
 *
 * محتوى قانوني شامل باللغتين العربية والإنجليزية.
 * راجع هذه السياسة مع مستشار قانوني قبل الإطلاق الرسمي.
 */

import type { ReactNode } from 'react';
import { Shield } from 'lucide-react';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

const LAST_UPDATED_AR = '9 يوليو 2026';
const LAST_UPDATED_EN = 'July 9, 2026';

export function PrivacyPage() {
  const { locale } = useLocale();
  const isArabic = locale === 'ar';

  useSeo({
    title: isArabic ? 'سياسة الخصوصية' : 'Privacy Policy',
    description: isArabic
      ? 'تعرَّف على كيفية جمع بياناتك وحمايتها واستخدامها على منصة AI Hub Arabia.'
      : 'Learn how AI Hub Arabia collects, protects, and uses your data.',
    canonicalPath: '/privacy',
  });

  return (
    <div className="section-padding">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-10 text-center">
          <div className="mb-4 flex justify-center">
            <div className="rounded-2xl bg-teal-50 p-4 dark:bg-teal-900/20">
              <Shield className="h-8 w-8 text-teal-600 dark:text-teal-400" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {isArabic ? 'سياسة الخصوصية' : 'Privacy Policy'}
          </h1>
          <p className="mt-3 text-sm text-gray-500 dark:text-gray-400">
            {isArabic
              ? `آخر تحديث: ${LAST_UPDATED_AR}`
              : `Last updated: ${LAST_UPDATED_EN}`}
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-gray max-w-none space-y-8 dark:prose-invert">
          {isArabic ? <ArabicContent /> : <EnglishContent />}
        </div>
      </div>
    </div>
  );
}

// ── المحتوى العربي ──────────────────────────────────────────────────────────

function ArabicContent() {
  return (
    <div className="space-y-8 text-right" dir="rtl">
      <Section title="مقدمة">
        <p>
          مرحبًا بك في منصة <strong>AI Hub Arabia</strong>. نحن نُقدِّر خصوصيتك ونلتزم بحماية بياناتك الشخصية. توضِّح هذه السياسة
          كيفية جمع المعلومات عنك وتخزينها واستخدامها ومشاركتها، وكذلك حقوقك فيما يتعلق ببياناتك.
        </p>
        <p>
          باستخدامك لهذه المنصة، فإنك توافق على شروط هذه السياسة. إذا كنت لا توافق على أيٍّ من بنودها، يُرجى عدم استخدام المنصة.
        </p>
      </Section>

      <Section title="المعلومات التي نجمعها">
        <SubSection title="1. المعلومات التي تُقدِّمها مباشرةً">
          <ul>
            <li><strong>بيانات الحساب:</strong> الاسم، البريد الإلكتروني، كلمة المرور عند التسجيل.</li>
            <li><strong>بيانات الملف الشخصي:</strong> المسمى الوظيفي، الشركة، نبذة شخصية قصيرة، صورة الملف الشخصي (اختيارية).</li>
            <li><strong>رسائل التواصل:</strong> المحتوى الذي ترسله عبر نموذج التواصل.</li>
            <li><strong>التقييمات والمراجعات:</strong> تقييماتك وتعليقاتك على أدوات الذكاء الاصطناعي.</li>
          </ul>
        </SubSection>

        <SubSection title="2. المعلومات التي نجمعها تلقائيًا">
          <ul>
            <li><strong>بيانات الاستخدام:</strong> الصفحات التي تزورها، الأدوات التي تستعرضها، وقت الجلسة.</li>
            <li><strong>بيانات الجهاز:</strong> نوع المتصفح، نظام التشغيل، دقة الشاشة.</li>
            <li><strong>بيانات الشبكة:</strong> عنوان IP المُجزَّأ (نحتفظ بـ 3 مجموعات فقط لأغراض الأمان).</li>
            <li><strong>ملفات الجلسة (Session Storage):</strong> معلومات جلسة تسجيل الدخول — لا نستخدم Cookies تتبُّع.</li>
          </ul>
        </SubSection>
      </Section>

      <Section title="كيف نستخدم معلوماتك">
        <ul>
          <li>تشغيل الحساب وتوفير الوصول لجميع ميزات المنصة.</li>
          <li>تخصيص تجربتك (المفضلة، المقارنات، التوصيات).</li>
          <li>الرد على رسائل التواصل والاستفسارات.</li>
          <li>إرسال تحديثات المنصة والأدوات الجديدة (بموافقتك فقط).</li>
          <li>تحسين أداء المنصة وإضافة ميزات جديدة.</li>
          <li>الكشف عن الاحتيال وضمان أمان المنصة.</li>
          <li>الامتثال للمتطلبات القانونية والتنظيمية.</li>
        </ul>
      </Section>

      <Section title="مشاركة المعلومات">
        <p><strong>لا نبيع بياناتك الشخصية إطلاقًا.</strong> قد نشارك معلومات محدودة في الحالات التالية فقط:</p>
        <ul>
          <li><strong>مزودو الخدمة:</strong> Firebase (Google) لتخزين البيانات والمصادقة — ملتزمون بسياسات خصوصية صارمة.</li>
          <li><strong>الالتزام القانوني:</strong> عند الضرورة القانونية المُثبَتة بقرار قضائي.</li>
          <li><strong>حماية الحقوق:</strong> لمنع الضرر أو حماية حقوق المنصة أو مستخدميها.</li>
          <li><strong>نقل الأعمال:</strong> في حالة الاندماج أو الاستحواذ، مع الإشعار المسبق لك.</li>
        </ul>
      </Section>

      <Section title="حقوقك على بياناتك">
        <ul>
          <li><strong>الوصول:</strong> يمكنك الاطلاع على بياناتك من لوحة الحساب في أي وقت.</li>
          <li><strong>التصحيح:</strong> يمكنك تعديل معلوماتك من إعدادات الملف الشخصي.</li>
          <li><strong>الحذف:</strong> يمكنك طلب حذف حسابك وجميع بياناتك عبر صفحة التواصل.</li>
          <li><strong>تقييد المعالجة:</strong> يمكنك إيقاف تلقِّي الرسائل التسويقية من إعدادات الحساب.</li>
          <li><strong>قابلية النقل:</strong> يمكنك طلب تصدير بياناتك بتنسيق قابل للقراءة.</li>
        </ul>
      </Section>

      <Section title="أمان البيانات">
        <p>نطبِّق إجراءات أمان متعددة لحماية بياناتك:</p>
        <ul>
          <li>تشفير HTTPS لجميع الاتصالات.</li>
          <li>استخدام Firebase Authentication لإدارة كلمات المرور بأمان.</li>
          <li>قواعد أمان Firestore المُعرَّفة تمنع الوصول غير المصرَّح به.</li>
          <li>سجل تدقيق (Audit Log) لتتبُّع الأحداث الأمنية الحساسة.</li>
          <li>جلسات مشفَّرة وحد أقصى للمحاولات الخاطئة.</li>
        </ul>
      </Section>

      <Section title="الاحتفاظ بالبيانات">
        <p>
          نحتفظ ببياناتك طالما حسابك نشط. عند طلب الحذف، تُحذف البيانات الشخصية خلال 30 يومًا،
          مع الإبقاء على بيانات مُجهَّلة لأغراض إحصائية.
        </p>
      </Section>

      <Section title="الخدمات الخارجية (Third-Party Services)">
        <ul>
          <li><strong>Firebase (Google):</strong> التخزين، المصادقة، الاستضافة. راجع <a href="https://firebase.google.com/support/privacy" target="_blank" rel="noopener noreferrer" className="text-teal-600 underline">سياسة خصوصية Firebase</a>.</li>
          <li><strong>Google Fonts:</strong> تحميل خط Tajawal. لا تتعقَّب بياناتك الشخصية.</li>
        </ul>
        <p>لا نستخدم Google Analytics أو أي أداة تتبُّع إضافية.</p>
      </Section>

      <Section title="الأطفال دون سن 13">
        <p>
          منصتنا غير مُوجَّهة للأطفال دون سن 13 عامًا. إذا علمنا بجمع بيانات طفل دون موافقة ولي الأمر،
          سنحذف هذه البيانات فورًا.
        </p>
      </Section>

      <Section title="التحديثات على هذه السياسة">
        <p>
          قد نُحدِّث هذه السياسة من وقت لآخر. سنُخطرك بالتغييرات الجوهرية عبر البريد الإلكتروني أو
          إشعار داخل المنصة قبل نفاذ التغيير بـ 14 يومًا.
        </p>
      </Section>

      <Section title="التواصل معنا">
        <p>
          لأي استفسار حول هذه السياسة أو بياناتك الشخصية، تواصل معنا عبر{' '}
          <a href="/contact" className="text-teal-600 underline">صفحة التواصل</a>.
        </p>
      </Section>
    </div>
  );
}

// ── English Content ──────────────────────────────────────────────────────────

function EnglishContent() {
  return (
    <div className="space-y-8" dir="ltr">
      <Section title="Introduction">
        <p>
          Welcome to <strong>AI Hub Arabia</strong>. We respect your privacy and are committed to protecting your personal data.
          This policy explains how we collect, store, use, and share information about you, and your rights regarding your data.
        </p>
        <p>
          By using this platform, you agree to this policy. If you do not agree, please discontinue use of the platform.
        </p>
      </Section>

      <Section title="Information We Collect">
        <SubSection title="1. Information You Provide Directly">
          <ul>
            <li><strong>Account data:</strong> Name, email address, password when registering.</li>
            <li><strong>Profile data:</strong> Job title, company, short bio, profile photo (optional).</li>
            <li><strong>Contact messages:</strong> Content you submit via the contact form.</li>
            <li><strong>Reviews & ratings:</strong> Your ratings and comments on AI tools.</li>
          </ul>
        </SubSection>

        <SubSection title="2. Information We Collect Automatically">
          <ul>
            <li><strong>Usage data:</strong> Pages visited, tools viewed, session duration.</li>
            <li><strong>Device data:</strong> Browser type, operating system, screen resolution.</li>
            <li><strong>Network data:</strong> Truncated IP address (3 octets only, for security purposes).</li>
            <li><strong>Session storage:</strong> Login session token — we do not use tracking cookies.</li>
          </ul>
        </SubSection>
      </Section>

      <Section title="How We Use Your Information">
        <ul>
          <li>Operating your account and providing access to platform features.</li>
          <li>Personalizing your experience (favorites, comparisons, recommendations).</li>
          <li>Responding to contact messages and inquiries.</li>
          <li>Sending platform updates and new tool announcements (with your consent only).</li>
          <li>Improving platform performance and adding new features.</li>
          <li>Detecting fraud and maintaining platform security.</li>
          <li>Complying with legal and regulatory requirements.</li>
        </ul>
      </Section>

      <Section title="Sharing Your Information">
        <p><strong>We never sell your personal data.</strong> We may share limited information only in these cases:</p>
        <ul>
          <li><strong>Service providers:</strong> Firebase (Google) for data storage and authentication — bound by strict privacy policies.</li>
          <li><strong>Legal obligation:</strong> When legally required by a court order.</li>
          <li><strong>Rights protection:</strong> To prevent harm or protect the rights of the platform or its users.</li>
          <li><strong>Business transfer:</strong> In case of merger or acquisition, with prior notice to you.</li>
        </ul>
      </Section>

      <Section title="Your Data Rights">
        <ul>
          <li><strong>Access:</strong> View your data from the account dashboard at any time.</li>
          <li><strong>Correction:</strong> Edit your information from profile settings.</li>
          <li><strong>Deletion:</strong> Request account and data deletion via the contact page.</li>
          <li><strong>Processing restriction:</strong> Disable marketing communications from account settings.</li>
          <li><strong>Portability:</strong> Request an export of your data in a readable format.</li>
        </ul>
      </Section>

      <Section title="Data Security">
        <p>We apply multiple security measures to protect your data:</p>
        <ul>
          <li>HTTPS encryption for all communications.</li>
          <li>Firebase Authentication for secure password management.</li>
          <li>Firestore security rules preventing unauthorized access.</li>
          <li>Audit log tracking sensitive security events.</li>
          <li>Encrypted sessions and login attempt rate limiting.</li>
        </ul>
      </Section>

      <Section title="Data Retention">
        <p>
          We retain your data as long as your account is active. Upon deletion requests, personal data is removed within 30 days,
          while anonymized statistical data may be retained.
        </p>
      </Section>

      <Section title="Third-Party Services">
        <ul>
          <li><strong>Firebase (Google):</strong> Storage, authentication, hosting. See <a href="https://firebase.google.com/support/privacy" target="_blank" rel="noopener noreferrer" className="text-teal-600 underline">Firebase Privacy Policy</a>.</li>
          <li><strong>Google Fonts:</strong> Loading the Tajawal font. Does not track your personal data.</li>
        </ul>
        <p>We do not use Google Analytics or any additional tracking tools.</p>
      </Section>

      <Section title="Children Under 13">
        <p>
          Our platform is not directed at children under 13. If we become aware that we have collected data from a child
          without parental consent, we will delete it immediately.
        </p>
      </Section>

      <Section title="Policy Updates">
        <p>
          We may update this policy from time to time. We will notify you of material changes via email or
          an in-platform notice at least 14 days before the change takes effect.
        </p>
      </Section>

      <Section title="Contact Us">
        <p>
          For any questions about this policy or your personal data, contact us via the{' '}
          <a href="/contact" className="text-teal-600 underline">Contact Page</a>.
        </p>
      </Section>
    </div>
  );
}

// ── Helper Components ────────────────────────────────────────────────────────

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
      <h2 className="mb-4 text-xl font-bold text-gray-900 dark:text-white">{title}</h2>
      <div className="space-y-3 text-gray-700 dark:text-gray-300 leading-relaxed">{children}</div>
    </section>
  );
}

function SubSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mt-4">
      <h3 className="mb-2 font-semibold text-gray-800 dark:text-gray-200">{title}</h3>
      {children}
    </div>
  );
}
