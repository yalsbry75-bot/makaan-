import { Link } from 'react-router-dom';
import { Home, SearchX } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

export function NotFoundPage() {
  const { locale } = useLocale();
  useSeo(locale === 'ar' ? 'الصفحة غير موجودة' : 'Page not found');

  return (
    <section className="section-padding">
      <div className="container">
        <Card className="mx-auto flex max-w-2xl flex-col items-center p-8 text-center md:p-12">
          <div className="mb-6 grid h-16 w-16 place-items-center rounded-3xl bg-muted text-muted-foreground"><SearchX className="h-8 w-8" /></div>
          <p className="text-sm font-bold text-primary">404</p>
          <h1 className="mt-2 text-3xl font-extrabold">{locale === 'ar' ? 'الصفحة غير موجودة' : 'Page not found'}</h1>
          <p className="mt-3 text-muted-foreground">{locale === 'ar' ? 'الرابط الذي تحاول فتحه غير متاح أو تم تغييره.' : 'The link you are trying to open is unavailable or has changed.'}</p>
          <Link to="/" className="mt-6"><Button><Home className="h-4 w-4" /> {locale === 'ar' ? 'العودة للرئيسية' : 'Back home'}</Button></Link>
        </Card>
      </div>
    </section>
  );
}
