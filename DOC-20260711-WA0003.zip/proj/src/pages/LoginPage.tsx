import { FormEvent, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LockKeyhole, Mail } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { useToast } from '@/components/ui/Toast';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import type { FieldErrors, SignInPayload } from '@/types/auth';

export function LoginPage() {
  const { locale, t } = useLocale();
  const { login, isLoading } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState<SignInPayload>({ email: '', password: '', remember: true });
  const [errors, setErrors] = useState<FieldErrors<keyof SignInPayload>>({});
  const redirectTo = (location.state as { from?: { pathname?: string } } | null)?.from?.pathname ?? '/dashboard';
  useSeo(t('auth.login'));

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    const result = await login(form);
    if (!result.success) {
      setErrors(result.fieldErrors as FieldErrors<keyof SignInPayload>);
      showToast({ title: locale === 'ar' ? 'تعذر تسجيل الدخول' : 'Login failed', description: result.message, tone: 'error' });
      return;
    }
    showToast({ title: locale === 'ar' ? 'تم تسجيل الدخول' : 'Login successful', description: result.message, tone: 'success' });
    navigate(redirectTo, { replace: true });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">{t('auth.login')}</CardTitle>
        <p className="text-sm text-muted-foreground">{locale === 'ar' ? 'ادخل إلى حسابك لمتابعة الأدوات المحفوظة والمقارنات.' : 'Access your saved tools and comparisons.'}</p>
      </CardHeader>
      <CardContent>
        <form className="grid gap-4" onSubmit={submit} noValidate>
          <Input
            label={locale === 'ar' ? 'البريد الإلكتروني' : 'Email'}
            name="email"
            type="email"
            autoComplete="email"
            placeholder="name@example.com"
            value={form.email}
            onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))}
            error={errors.email}
          />
          <Input
            label={locale === 'ar' ? 'كلمة المرور' : 'Password'}
            name="password"
            type="password"
            autoComplete="current-password"
            placeholder="••••••••"
            value={form.password}
            onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))}
            error={errors.password}
          />
          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center gap-2 text-muted-foreground">
              <input
                className="h-4 w-4 rounded border"
                type="checkbox"
                checked={Boolean(form.remember)}
                onChange={(event) => setForm((current) => ({ ...current, remember: event.target.checked }))}
              />
              {locale === 'ar' ? 'تذكرني' : 'Remember me'}
            </label>
            <Link className="font-semibold text-primary" to="/forgot-password">{t('auth.forgotPassword')}</Link>
          </div>
          <Button type="submit" fullWidth isLoading={isLoading} loadingLabel={locale === 'ar' ? 'جاري الدخول...' : 'Signing in...'}>
            <LockKeyhole className="h-4 w-4" />
            {t('auth.login')}
          </Button>
          <Button
            variant="outline"
            fullWidth
            onClick={() => showToast({ title: locale === 'ar' ? 'الدخول المؤسسي' : 'Work email', description: locale === 'ar' ? 'تم تجهيز مكان التكامل وسيُربط لاحقًا بمزود هوية خارجي.' : 'The integration point is ready for a future identity provider.' })}
          >
            <Mail className="h-4 w-4" />
            {locale === 'ar' ? 'الدخول بالبريد المؤسسي' : 'Continue with work email'}
          </Button>
        </form>
        <div className="mt-5 rounded-2xl bg-muted p-4 text-xs leading-6 text-muted-foreground">
          <p className="font-semibold text-foreground">{locale === 'ar' ? 'حسابات اختبار جاهزة:' : 'Ready demo accounts:'}</p>
          <p>admin@aihubarabia.com / Admin@12345</p>
          <p>user@aihubarabia.com / User@12345</p>
        </div>
        <p className="mt-6 text-center text-sm text-muted-foreground">
          {locale === 'ar' ? 'ليس لديك حساب؟ ' : "Don't have an account? "}
          <Link className="font-semibold text-primary" to="/register">{t('auth.register')}</Link>
        </p>
      </CardContent>
    </Card>
  );
}
