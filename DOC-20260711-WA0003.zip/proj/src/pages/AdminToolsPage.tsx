import { FormEvent, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Database, Edit3, EyeOff, MessageSquare, Plus, ShieldCheck, Trash2, UsersRound } from 'lucide-react';
import type { AITool, Pricing, ToolCategory, ToolPlatform } from '@/types';
import type { AdminDashboardData } from '@/types/database';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { StatCard } from '@/components/ui/StatCard';
import { useToast } from '@/components/ui/Toast';
import { getAdminDashboardData } from '@/services/dashboardService';
import { createCategory, createTool, deleteCategory, deleteTool, updateCategory, updateTool } from '@/services/toolService';
import { databaseMetadata } from '@/services/databaseService';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';
import { slugifyToolName } from '@/utils/toolNormalization';

const pricingOptions: Pricing[] = ['free', 'freemium', 'paid', 'enterprise'];
const platformOptions: ToolPlatform[] = ['web', 'android', 'ios', 'api', 'desktop'];

const defaultMetrics = [
  { labelAr: 'زمن التجربة', labelEn: 'Trial setup', value: '10m' },
  { labelAr: 'سهولة الاستخدام', labelEn: 'Ease of use', value: '90%' },
  { labelAr: 'ملاءمة الفرق', labelEn: 'Team fit', value: 'High' },
];

type ToolFormState = {
  name: string;
  taglineAr: string;
  taglineEn: string;
  descriptionAr: string;
  descriptionEn: string;
  categorySlug: string;
  pricing: Pricing;
  platform: ToolPlatform[];
  tags: string;
  featuresAr: string;
  featuresEn: string;
  useCasesAr: string;
  useCasesEn: string;
  integrations: string;
  website: string;
  rating: string;
  users: string;
  launchYear: string;
  featured: boolean;
  verified: boolean;
  visibilityStatus: 'active' | 'hidden';
};

type CategoryFormState = {
  nameAr: string;
  nameEn: string;
  slug: string;
  descriptionAr: string;
  descriptionEn: string;
  icon: string;
  growth: string;
  status: 'active' | 'hidden';
};

function csvToArray(value: string) {
  return value.split(',').map((item) => item.trim()).filter(Boolean);
}

function arrayToCsv(value: string[] | undefined) {
  return value?.join(', ') ?? '';
}

function createEmptyToolForm(categorySlug = 'writing'): ToolFormState {
  return {
    name: '',
    taglineAr: '',
    taglineEn: '',
    descriptionAr: '',
    descriptionEn: '',
    categorySlug,
    pricing: 'freemium',
    platform: ['web'],
    tags: '',
    featuresAr: '',
    featuresEn: '',
    useCasesAr: '',
    useCasesEn: '',
    integrations: '',
    website: 'app.aihubarabia.local/new-tool',
    rating: '4.5',
    users: '1K',
    launchYear: String(new Date().getFullYear()),
    featured: false,
    verified: false,
    visibilityStatus: 'active',
  };
}

function toolToForm(tool: AITool): ToolFormState {
  return {
    name: tool.name,
    taglineAr: tool.taglineAr,
    taglineEn: tool.taglineEn,
    descriptionAr: tool.descriptionAr,
    descriptionEn: tool.descriptionEn,
    categorySlug: tool.categorySlug,
    pricing: tool.pricing,
    platform: tool.platform ?? ['web'],
    tags: arrayToCsv(tool.tags),
    featuresAr: arrayToCsv(tool.featuresAr),
    featuresEn: arrayToCsv(tool.featuresEn),
    useCasesAr: arrayToCsv(tool.useCasesAr),
    useCasesEn: arrayToCsv(tool.useCasesEn),
    integrations: arrayToCsv(tool.integrations),
    website: tool.website,
    rating: String(tool.rating),
    users: tool.users,
    launchYear: tool.launchYear,
    featured: Boolean(tool.featured),
    verified: Boolean(tool.verified),
    visibilityStatus: tool.visibilityStatus ?? 'active',
  };
}

function categoryToForm(category: ToolCategory): CategoryFormState {
  return {
    nameAr: category.nameAr,
    nameEn: category.nameEn,
    slug: category.slug,
    descriptionAr: category.descriptionAr,
    descriptionEn: category.descriptionEn,
    icon: category.icon,
    growth: category.growth,
    status: category.status ?? 'active',
  };
}

export function AdminToolsPage() {
  const { locale } = useLocale();
  const { showToast } = useToast();
  const [data, setData] = useState<AdminDashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [toolModalOpen, setToolModalOpen] = useState(false);
  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [editingTool, setEditingTool] = useState<AITool | null>(null);
  const [editingCategory, setEditingCategory] = useState<ToolCategory | null>(null);
  const [toolForm, setToolForm] = useState<ToolFormState>(() => createEmptyToolForm());
  const [categoryForm, setCategoryForm] = useState<CategoryFormState>({ nameAr: '', nameEn: '', slug: '', descriptionAr: '', descriptionEn: '', icon: 'Sparkles', growth: '+0%', status: 'active' });
  const metadata = useMemo(() => databaseMetadata(), []);
  useSeo(locale === 'ar' ? 'إدارة الأدوات' : 'Admin tools management');

  async function refresh() {
    const dashboardData = await getAdminDashboardData();
    setData(dashboardData);
  }

  useEffect(() => {
    let isMounted = true;
    getAdminDashboardData()
      .then((dashboardData) => {
        if (isMounted) {
          setData(dashboardData);
          setToolForm(createEmptyToolForm(dashboardData.categories[0]?.slug ?? 'writing'));
        }
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, []);

  function openCreateTool() {
    setEditingTool(null);
    setToolForm(createEmptyToolForm(data?.categories[0]?.slug ?? 'writing'));
    setToolModalOpen(true);
  }

  function openEditTool(tool: AITool) {
    setEditingTool(tool);
    setToolForm(toolToForm(tool));
    setToolModalOpen(true);
  }

  function openCreateCategory() {
    setEditingCategory(null);
    setCategoryForm({ nameAr: '', nameEn: '', slug: '', descriptionAr: '', descriptionEn: '', icon: 'Sparkles', growth: '+0%', status: 'active' });
    setCategoryModalOpen(true);
  }

  function openEditCategory(category: ToolCategory) {
    setEditingCategory(category);
    setCategoryForm(categoryToForm(category));
    setCategoryModalOpen(true);
  }

  function updateToolForm<K extends keyof ToolFormState>(key: K, value: ToolFormState[K]) {
    setToolForm((current) => ({ ...current, [key]: value }));
  }

  function updateCategoryForm<K extends keyof CategoryFormState>(key: K, value: CategoryFormState[K]) {
    setCategoryForm((current) => ({ ...current, [key]: value }));
  }

  async function handleToolSubmit(event: FormEvent) {
    event.preventDefault();
    if (!toolForm.name.trim() || !toolForm.taglineAr.trim() || !toolForm.taglineEn.trim()) {
      showToast({ title: locale === 'ar' ? 'بيانات ناقصة' : 'Missing fields', description: locale === 'ar' ? 'اسم الأداة والعنوان المختصر مطلوبان.' : 'Tool name and taglines are required.', tone: 'error' });
      return;
    }
    setIsSaving(true);
    try {
      const payload = {
        name: toolForm.name.trim(),
        slug: editingTool?.slug ?? slugifyToolName(toolForm.name),
        taglineAr: toolForm.taglineAr.trim(),
        taglineEn: toolForm.taglineEn.trim(),
        descriptionAr: toolForm.descriptionAr.trim() || toolForm.taglineAr.trim(),
        descriptionEn: toolForm.descriptionEn.trim() || toolForm.taglineEn.trim(),
        fullDescriptionAr: toolForm.descriptionAr.trim() || toolForm.taglineAr.trim(),
        fullDescriptionEn: toolForm.descriptionEn.trim() || toolForm.taglineEn.trim(),
        categorySlug: toolForm.categorySlug,
        pricing: toolForm.pricing,
        platform: toolForm.platform,
        rating: Number.parseFloat(toolForm.rating) || 4,
        users: toolForm.users.trim() || '1K',
        tags: csvToArray(toolForm.tags),
        featured: toolForm.featured,
        verified: toolForm.verified,
        status: toolForm.verified ? 'verified' as const : 'new' as const,
        visibilityStatus: toolForm.visibilityStatus,
        logoGradient: editingTool?.logoGradient ?? 'from-teal-500 to-cyan-500',
        website: toolForm.website.trim() || `app.aihubarabia.local/${slugifyToolName(toolForm.name)}`,
        launchYear: toolForm.launchYear.trim() || String(new Date().getFullYear()),
        supportedLanguages: ['Arabic', 'English'],
        useCasesAr: csvToArray(toolForm.useCasesAr),
        useCasesEn: csvToArray(toolForm.useCasesEn),
        featuresAr: csvToArray(toolForm.featuresAr),
        featuresEn: csvToArray(toolForm.featuresEn),
        integrations: csvToArray(toolForm.integrations),
        metrics: defaultMetrics,
      };
      if (editingTool) await updateTool(editingTool.id, payload);
      else await createTool(payload);
      await refresh();
      setToolModalOpen(false);
      showToast({ title: editingTool ? (locale === 'ar' ? 'تم تعديل الأداة' : 'Tool updated') : (locale === 'ar' ? 'تمت إضافة الأداة' : 'Tool added'), tone: 'success' });
    } catch (error) {
      showToast({ title: locale === 'ar' ? 'تعذر حفظ الأداة' : 'Could not save tool', description: error instanceof Error ? error.message : undefined, tone: 'error' });
    } finally {
      setIsSaving(false);
    }
  }

  async function handleCategorySubmit(event: FormEvent) {
    event.preventDefault();
    if (!categoryForm.nameAr.trim() || !categoryForm.nameEn.trim()) {
      showToast({ title: locale === 'ar' ? 'بيانات ناقصة' : 'Missing fields', description: locale === 'ar' ? 'اسم التصنيف مطلوب.' : 'Category name is required.', tone: 'error' });
      return;
    }
    setIsSaving(true);
    try {
      const payload = {
        nameAr: categoryForm.nameAr.trim(),
        nameEn: categoryForm.nameEn.trim(),
        slug: categoryForm.slug.trim() || slugifyToolName(categoryForm.nameEn),
        descriptionAr: categoryForm.descriptionAr.trim(),
        descriptionEn: categoryForm.descriptionEn.trim(),
        icon: categoryForm.icon.trim() || 'Sparkles',
        growth: categoryForm.growth.trim() || '+0%',
        status: categoryForm.status,
      };
      if (editingCategory) await updateCategory(editingCategory.id, payload);
      else await createCategory(payload);
      await refresh();
      setCategoryModalOpen(false);
      showToast({ title: editingCategory ? (locale === 'ar' ? 'تم تعديل التصنيف' : 'Category updated') : (locale === 'ar' ? 'تمت إضافة التصنيف' : 'Category added'), tone: 'success' });
    } catch (error) {
      showToast({ title: locale === 'ar' ? 'تعذر حفظ التصنيف' : 'Could not save category', description: error instanceof Error ? error.message : undefined, tone: 'error' });
    } finally {
      setIsSaving(false);
    }
  }

  async function handleDeleteTool(tool: AITool) {
    setIsSaving(true);
    try {
      await deleteTool(tool.id);
      await refresh();
      showToast({ title: locale === 'ar' ? 'تم حذف الأداة' : 'Tool deleted', tone: 'success' });
    } catch (error) {
      showToast({ title: locale === 'ar' ? 'تعذر حذف الأداة' : 'Could not delete tool', description: error instanceof Error ? error.message : undefined, tone: 'error' });
    } finally {
      setIsSaving(false);
    }
  }

  async function handleToggleToolVisibility(tool: AITool) {
    const nextStatus = tool.visibilityStatus === 'hidden' ? 'active' : 'hidden';
    await updateTool(tool.id, { visibilityStatus: nextStatus });
    await refresh();
    showToast({ title: nextStatus === 'active' ? (locale === 'ar' ? 'الأداة نشطة' : 'Tool is active') : (locale === 'ar' ? 'الأداة مخفية' : 'Tool hidden'), tone: 'success' });
  }

  async function handleDeleteCategory(category: ToolCategory) {
    setIsSaving(true);
    try {
      await deleteCategory(category.id);
      await refresh();
      showToast({ title: locale === 'ar' ? 'تم حذف التصنيف' : 'Category deleted', tone: 'success' });
    } catch (error) {
      showToast({ title: locale === 'ar' ? 'تعذر حذف التصنيف' : 'Could not delete category', description: error instanceof Error ? error.message : undefined, tone: 'error' });
    } finally {
      setIsSaving(false);
    }
  }

  const pendingReviews = data?.reviews.filter((review) => review.status === 'pending') ?? [];
  const newMessages = data?.contactMessages.filter((message) => message.status === 'new') ?? [];
  const openReports = data?.reports.filter((report) => report.status === 'open') ?? [];
  const activeTools = data?.tools.filter((tool) => (tool.visibilityStatus ?? 'active') === 'active') ?? [];

  return (
    <div className="grid gap-8">
      <SectionHeader
        title={locale === 'ar' ? 'إدارة أدوات الذكاء الاصطناعي' : 'AI tools management'}
        description={locale === 'ar' ? 'إضافة وتعديل وحذف وإخفاء الأدوات، مع إدارة التصنيفات والوسوم وحالة النشر.' : 'Create, edit, delete, hide, and publish tools while managing categories, tags, and listing status.'}
        action={<div className="flex flex-wrap gap-2"><Button onClick={openCreateTool}><Plus className="h-4 w-4" /> {locale === 'ar' ? 'إضافة أداة' : 'Add tool'}</Button><Button variant="outline" onClick={openCreateCategory}><Plus className="h-4 w-4" /> {locale === 'ar' ? 'إضافة تصنيف' : 'Add category'}</Button></div>}
      />

      {isLoading || !data ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 4 }).map((_, index) => <Skeleton key={index} className="h-32" />)}</div>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <StatCard label={locale === 'ar' ? 'الأدوات النشطة' : 'Active tools'} value={String(activeTools.length)} change="CRUD" icon={<Database className="h-5 w-5" />} />
            <StatCard label={locale === 'ar' ? 'التصنيفات' : 'Categories'} value={String(data.categories.length)} change="Managed" icon={<ShieldCheck className="h-5 w-5" />} />
            <StatCard label={locale === 'ar' ? 'المستخدمون' : 'Users'} value={String(data.users.length)} change="Auth" icon={<UsersRound className="h-5 w-5" />} />
            <StatCard label={locale === 'ar' ? 'مراجعات معلقة' : 'Pending reviews'} value={String(pendingReviews.length)} change="Moderation" icon={<AlertTriangle className="h-5 w-5" />} />
          </div>

          <div className="grid gap-6 xl:grid-cols-[1fr_24rem]">
            <Card className="overflow-hidden">
              <div className="flex flex-col gap-3 border-b p-5 md:flex-row md:items-center md:justify-between"><h2 className="text-xl font-bold">{locale === 'ar' ? 'إدارة الأدوات' : 'Tool management'}</h2><Button size="sm" onClick={openCreateTool}><Plus className="h-4 w-4" /> {locale === 'ar' ? 'إضافة' : 'Add'}</Button></div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[900px] text-sm">
                  <thead className="bg-muted text-muted-foreground">
                    <tr><th className="p-4 text-start">{locale === 'ar' ? 'الأداة' : 'Tool'}</th><th className="p-4 text-start">{locale === 'ar' ? 'الحالة' : 'Status'}</th><th className="p-4 text-start">{locale === 'ar' ? 'الخطة' : 'Plan'}</th><th className="p-4 text-start">{locale === 'ar' ? 'المنصة' : 'Platform'}</th><th className="p-4 text-start">{locale === 'ar' ? 'التقييم' : 'Rating'}</th><th className="p-4 text-start">{locale === 'ar' ? 'إجراءات' : 'Actions'}</th></tr>
                  </thead>
                  <tbody>
                    {data.tools.map((tool) => (
                      <tr key={tool.id} className="border-t">
                        <td className="p-4"><div className="font-semibold">{tool.name}</div><div className="text-xs text-muted-foreground">{tool.slug}</div></td>
                        <td className="p-4"><Badge variant={(tool.visibilityStatus ?? 'active') === 'active' ? 'success' : 'muted'}>{(tool.visibilityStatus ?? 'active') === 'active' ? (locale === 'ar' ? 'نشطة' : 'Active') : (locale === 'ar' ? 'مخفية' : 'Hidden')}</Badge></td>
                        <td className="p-4 text-muted-foreground">{tool.pricing}</td>
                        <td className="p-4 text-muted-foreground">{tool.platform?.join(', ') ?? 'web'}</td>
                        <td className="p-4 text-muted-foreground">{tool.rating}</td>
                        <td className="p-4"><div className="flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => openEditTool(tool)}><Edit3 className="h-4 w-4" /> {locale === 'ar' ? 'تعديل' : 'Edit'}</Button><Button size="sm" variant="ghost" onClick={() => handleToggleToolVisibility(tool)}><EyeOff className="h-4 w-4" /> {locale === 'ar' ? 'إخفاء' : 'Hide'}</Button><Button size="sm" variant="danger" disabled={isSaving} onClick={() => handleDeleteTool(tool)}><Trash2 className="h-4 w-4" /></Button></div></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
            <div className="grid gap-6">
              <Card className="p-5">
                <div className="mb-4 flex items-center justify-between"><h2 className="text-xl font-bold">{locale === 'ar' ? 'التصنيفات' : 'Categories'}</h2><Button size="sm" variant="outline" onClick={openCreateCategory}><Plus className="h-4 w-4" /></Button></div>
                <div className="grid gap-3">
                  {data.categories.map((category) => (
                    <div key={category.id} className="rounded-2xl border p-3">
                      <div className="flex items-start justify-between gap-3"><div><strong>{locale === 'ar' ? category.nameAr : category.nameEn}</strong><p className="text-xs text-muted-foreground">{category.slug} · {category.toolsCount}</p></div><Badge variant={(category.status ?? 'active') === 'active' ? 'success' : 'muted'}>{category.status ?? 'active'}</Badge></div>
                      <div className="mt-3 flex gap-2"><Button size="sm" variant="outline" onClick={() => openEditCategory(category)}><Edit3 className="h-4 w-4" /></Button><Button size="sm" variant="danger" disabled={isSaving} onClick={() => handleDeleteCategory(category)}><Trash2 className="h-4 w-4" /></Button></div>
                    </div>
                  ))}
                </div>
              </Card>
              <Card className="p-5">
                <h2 className="mb-4 text-xl font-bold">{locale === 'ar' ? 'حالة النظام' : 'System status'}</h2>
                {[`Database ${metadata.version}`, 'Tool Repository CRUD', 'Advanced Filters', 'Related Tools'].map((item) => <p key={item} className="mb-3 flex items-center gap-2 text-sm text-muted-foreground"><CheckCircle2 className="h-4 w-4 text-primary" /> {item}</p>)}
              </Card>
              <Card className="p-5">
                <h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><MessageSquare className="h-5 w-5 text-primary" /> {locale === 'ar' ? 'الرسائل والبلاغات' : 'Messages & reports'}</h2>
                <div className="grid gap-3 text-sm text-muted-foreground">
                  <p>{locale === 'ar' ? `رسائل جديدة: ${newMessages.length}` : `New messages: ${newMessages.length}`}</p>
                  <p>{locale === 'ar' ? `بلاغات مفتوحة: ${openReports.length}` : `Open reports: ${openReports.length}`}</p>
                  <p>{locale === 'ar' ? `Collections: ${metadata.collections.length}` : `Collections: ${metadata.collections.length}`}</p>
                </div>
              </Card>
            </div>
          </div>
        </>
      )}

      <Modal open={toolModalOpen} title={editingTool ? (locale === 'ar' ? 'تعديل أداة' : 'Edit tool') : (locale === 'ar' ? 'إضافة أداة' : 'Add tool')} onClose={() => setToolModalOpen(false)} className="max-h-[90vh] max-w-4xl overflow-y-auto">
        <form className="grid gap-4" onSubmit={handleToolSubmit}>
          <div className="grid gap-4 md:grid-cols-2"><Input label={locale === 'ar' ? 'اسم الأداة' : 'Tool name'} value={toolForm.name} onChange={(event) => updateToolForm('name', event.target.value)} /><Input label="Website" value={toolForm.website} onChange={(event) => updateToolForm('website', event.target.value)} /></div>
          <div className="grid gap-4 md:grid-cols-2"><Input label={locale === 'ar' ? 'وصف مختصر عربي' : 'Arabic tagline'} value={toolForm.taglineAr} onChange={(event) => updateToolForm('taglineAr', event.target.value)} /><Input label={locale === 'ar' ? 'وصف مختصر إنجليزي' : 'English tagline'} value={toolForm.taglineEn} onChange={(event) => updateToolForm('taglineEn', event.target.value)} /></div>
          <div className="grid gap-4 md:grid-cols-2"><TextArea label={locale === 'ar' ? 'الوصف العربي' : 'Arabic description'} value={toolForm.descriptionAr} onChange={(value) => updateToolForm('descriptionAr', value)} /><TextArea label={locale === 'ar' ? 'الوصف الإنجليزي' : 'English description'} value={toolForm.descriptionEn} onChange={(value) => updateToolForm('descriptionEn', value)} /></div>
          <div className="grid gap-4 md:grid-cols-4"><Select label={locale === 'ar' ? 'التصنيف' : 'Category'} value={toolForm.categorySlug} onChange={(value) => updateToolForm('categorySlug', value)} options={(data?.categories ?? []).map((category) => ({ label: locale === 'ar' ? category.nameAr : category.nameEn, value: category.slug }))} /><Select label={locale === 'ar' ? 'السعر' : 'Pricing'} value={toolForm.pricing} onChange={(value) => updateToolForm('pricing', value as Pricing)} options={pricingOptions.map((item) => ({ label: item, value: item }))} /><Input label={locale === 'ar' ? 'التقييم' : 'Rating'} value={toolForm.rating} onChange={(event) => updateToolForm('rating', event.target.value)} /><Input label={locale === 'ar' ? 'المستخدمون' : 'Users'} value={toolForm.users} onChange={(event) => updateToolForm('users', event.target.value)} /></div>
          <div className="grid gap-4 md:grid-cols-2"><Input label="Tags CSV" value={toolForm.tags} onChange={(event) => updateToolForm('tags', event.target.value)} /><Input label="Integrations CSV" value={toolForm.integrations} onChange={(event) => updateToolForm('integrations', event.target.value)} /></div>
          <div className="grid gap-4 md:grid-cols-2"><Input label="Features AR CSV" value={toolForm.featuresAr} onChange={(event) => updateToolForm('featuresAr', event.target.value)} /><Input label="Features EN CSV" value={toolForm.featuresEn} onChange={(event) => updateToolForm('featuresEn', event.target.value)} /></div>
          <div className="grid gap-4 md:grid-cols-2"><Input label="Use cases AR CSV" value={toolForm.useCasesAr} onChange={(event) => updateToolForm('useCasesAr', event.target.value)} /><Input label="Use cases EN CSV" value={toolForm.useCasesEn} onChange={(event) => updateToolForm('useCasesEn', event.target.value)} /></div>
          <div className="grid gap-4 md:grid-cols-3"><MultiPlatform value={toolForm.platform} onChange={(value) => updateToolForm('platform', value)} /><Select label={locale === 'ar' ? 'الحالة' : 'Visibility'} value={toolForm.visibilityStatus} onChange={(value) => updateToolForm('visibilityStatus', value as 'active' | 'hidden')} options={[{ label: 'active', value: 'active' }, { label: 'hidden', value: 'hidden' }]} /><Input label={locale === 'ar' ? 'سنة الإطلاق' : 'Launch year'} value={toolForm.launchYear} onChange={(event) => updateToolForm('launchYear', event.target.value)} /></div>
          <div className="flex flex-wrap gap-4 text-sm"><label className="flex items-center gap-2"><input type="checkbox" checked={toolForm.featured} onChange={(event) => updateToolForm('featured', event.target.checked)} /> {locale === 'ar' ? 'مميزة' : 'Featured'}</label><label className="flex items-center gap-2"><input type="checkbox" checked={toolForm.verified} onChange={(event) => updateToolForm('verified', event.target.checked)} /> {locale === 'ar' ? 'موثقة' : 'Verified'}</label></div>
          <div className="flex justify-end gap-3"><Button variant="outline" onClick={() => setToolModalOpen(false)}>{locale === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button type="submit" disabled={isSaving}>{isSaving ? (locale === 'ar' ? 'جار الحفظ...' : 'Saving...') : (locale === 'ar' ? 'حفظ' : 'Save')}</Button></div>
        </form>
      </Modal>

      <Modal open={categoryModalOpen} title={editingCategory ? (locale === 'ar' ? 'تعديل تصنيف' : 'Edit category') : (locale === 'ar' ? 'إضافة تصنيف' : 'Add category')} onClose={() => setCategoryModalOpen(false)}>
        <form className="grid gap-4" onSubmit={handleCategorySubmit}>
          <div className="grid gap-4 md:grid-cols-2"><Input label={locale === 'ar' ? 'الاسم العربي' : 'Arabic name'} value={categoryForm.nameAr} onChange={(event) => updateCategoryForm('nameAr', event.target.value)} /><Input label={locale === 'ar' ? 'الاسم الإنجليزي' : 'English name'} value={categoryForm.nameEn} onChange={(event) => updateCategoryForm('nameEn', event.target.value)} /></div>
          <Input label="Slug" value={categoryForm.slug} onChange={(event) => updateCategoryForm('slug', event.target.value)} />
          <div className="grid gap-4 md:grid-cols-2"><Input label={locale === 'ar' ? 'الوصف العربي' : 'Arabic description'} value={categoryForm.descriptionAr} onChange={(event) => updateCategoryForm('descriptionAr', event.target.value)} /><Input label={locale === 'ar' ? 'الوصف الإنجليزي' : 'English description'} value={categoryForm.descriptionEn} onChange={(event) => updateCategoryForm('descriptionEn', event.target.value)} /></div>
          <div className="grid gap-4 md:grid-cols-3"><Input label="Icon" value={categoryForm.icon} onChange={(event) => updateCategoryForm('icon', event.target.value)} /><Input label="Growth" value={categoryForm.growth} onChange={(event) => updateCategoryForm('growth', event.target.value)} /><Select label={locale === 'ar' ? 'الحالة' : 'Status'} value={categoryForm.status} onChange={(value) => updateCategoryForm('status', value as 'active' | 'hidden')} options={[{ label: 'active', value: 'active' }, { label: 'hidden', value: 'hidden' }]} /></div>
          <div className="flex justify-end gap-3"><Button variant="outline" onClick={() => setCategoryModalOpen(false)}>{locale === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button type="submit" disabled={isSaving}>{locale === 'ar' ? 'حفظ' : 'Save'}</Button></div>
        </form>
      </Modal>
    </div>
  );
}

function Select({ label, value, options, onChange }: { label: string; value: string; options: Array<{ label: string; value: string }>; onChange: (value: string) => void }) {
  return (
    <label className="block space-y-2">
      <span className="text-sm font-semibold text-foreground">{label}</span>
      <select className="focus-ring h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none transition" value={value} onChange={(event) => onChange(event.target.value)}>
        {options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
      </select>
    </label>
  );
}

function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="block space-y-2">
      <span className="text-sm font-semibold text-foreground">{label}</span>
      <textarea className="focus-ring min-h-28 w-full rounded-xl border border-input bg-background px-3 py-3 text-sm outline-none transition" value={value} onChange={(event) => onChange(event.target.value)} />
    </label>
  );
}

function MultiPlatform({ value, onChange }: { value: ToolPlatform[]; onChange: (value: ToolPlatform[]) => void }) {
  return (
    <div className="space-y-2">
      <span className="text-sm font-semibold text-foreground">Platforms</span>
      <div className="grid gap-2 rounded-xl border p-3 text-sm">
        {platformOptions.map((platform) => (
          <label key={platform} className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={value.includes(platform)}
              onChange={(event) => {
                if (event.target.checked) onChange([...value, platform]);
                else onChange(value.filter((item) => item !== platform));
              }}
            />
            {platform}
          </label>
        ))}
      </div>
    </div>
  );
}
