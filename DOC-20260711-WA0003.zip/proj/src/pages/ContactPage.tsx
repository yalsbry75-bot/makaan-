import { FormEvent, useState } from 'react';
import { Mail, MapPin, MessageSquare, Send } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { useToast } from '@/components/ui/Toast';
import { siteConfig } from '@/config/site';
import { submitContactMessage, ContactServiceError } from '@/services/contactService';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

export function ContactPage() {
  const { locale } = useLocale();
  const { showToast } = useToast();
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState<Partial<Record<keyof typeof form, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  useSeo(locale === 'ar' ? 'تواصل معنا' : 'Contact');

  async function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErrors({});
    setIsSubmitting(true);
    try {
      await submitContactMessage(form);
      setForm({ name: '', email: '', message: '' });
      showToast({ title: locale === 'ar' ? 'تم إرسال الرسالة' : 'Message sent', description: locale === 'ar' ? 'تم حفظ الرسالة داخل Contact Messages.' : 'The message was saved in Contact Messages.', tone: 'success' });
    } catch (error) {
      if (error instanceof ContactServiceError) setErrors(error.fieldErrors);
      showToast({ title: locale === 'ar' ? 'تعذر إرسال الرسالة' : 'Message failed', description: error instanceof Error ? error.message : undefined, tone: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <section className="section-padding">
      <div className="container">
        <SectionHeader centered eyebrow={locale === 'ar' ? 'الدعم والتواصل' : 'Support'} title={locale === 'ar' ? 'تواصل معنا' : 'Contact us'} description={locale === 'ar' ? 'نموذج التواصل مربوط الآن بقاعدة البيانات ويحفظ الرسائل للوحة الإدارة.' : 'The contact form is now connected to the database and stores messages for the admin dashboard.'} />
        <div className="grid gap-6 lg:grid-cols-[1fr_24rem]">
          <Card className="p-6">
            <form className="grid gap-4" onSubmit={submitForm} noValidate>
              <Input label={locale === 'ar' ? 'الاسم' : 'Name'} placeholder={locale === 'ar' ? 'اكتب اسمك' : 'Your name'} value={form.name} onChange={(event) => setForm((current) => ({ ...current, name: event.target.value }))} error={errors.name} />
              <Input label={locale === 'ar' ? 'البريد الإلكتروني' : 'Email'} type="email" placeholder="name@example.com" value={form.email} onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))} error={errors.email} />
              <label className="block space-y-2"><span className="text-sm font-semibold">{locale === 'ar' ? 'الرسالة' : 'Message'}</span><textarea className="focus-ring min-h-36 w-full rounded-2xl border bg-background p-3 text-sm outline-none" placeholder={locale === 'ar' ? 'اكتب رسالتك هنا' : 'Write your message here'} value={form.message} onChange={(event) => setForm((current) => ({ ...current, message: event.target.value }))} /></label>
              {errors.message ? <p className="text-sm text-destructive">{errors.message}</p> : null}
              <Button type="submit" disabled={isSubmitting}><Send className="h-4 w-4" /> {isSubmitting ? (locale === 'ar' ? 'جاري الإرسال...' : 'Sending...') : locale === 'ar' ? 'إرسال' : 'Send'}</Button>
            </form>
          </Card>
          <div className="grid gap-4">
            {[{ icon: <Mail className="h-5 w-5" />, title: siteConfig.supportEmail, labelAr: 'البريد', labelEn: 'Email' }, { icon: <MessageSquare className="h-5 w-5" />, title: 'Contact Messages', labelAr: 'Collection', labelEn: 'Collection' }, { icon: <MapPin className="h-5 w-5" />, title: 'Arabia Region', labelAr: 'النطاق', labelEn: 'Region' }].map((item) => <Card key={item.title} className="flex items-center gap-4 p-5"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-primary/10 text-primary">{item.icon}</span><div><p className="text-sm text-muted-foreground">{locale === 'ar' ? item.labelAr : item.labelEn}</p><h2 className="font-bold">{item.title}</h2></div></Card>)}
          </div>
        </div>
      </div>
    </section>
  );
}
