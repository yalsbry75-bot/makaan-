import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

const colors = [
  { name: 'Primary Teal', value: '#0F766E' },
  { name: 'Cyan Highlight', value: '#67E8F9' },
  { name: 'Gold Accent', value: '#F59E0B' },
  { name: 'Slate Surface', value: '#0F172A' },
  { name: 'Soft Background', value: '#F8FAFC' },
];

export function BrandGuidePage() {
  const { locale } = useLocale();
  useSeo(locale === 'ar' ? 'دليل الهوية' : 'Brand guide');

  return (
    <section className="section-padding">
      <div className="container">
        <div className="mb-10 max-w-3xl">
          <Badge>{locale === 'ar' ? 'Design System' : 'Design System'}</Badge>
          <h1 className="mt-4 text-4xl font-extrabold tracking-tight">{locale === 'ar' ? 'دليل الهوية البصرية المؤقت' : 'Temporary brand identity guide'}</h1>
          <p className="mt-3 text-muted-foreground">
            {locale === 'ar' ? 'مرجع داخلي لاستخدام الألوان والخطوط والمكونات في المراحل القادمة.' : 'Internal reference for color, typography, and component usage in future phases.'}
          </p>
        </div>
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-5">
          {colors.map((color) => (
            <Card key={color.name} className="overflow-hidden">
              <div className="h-28" style={{ backgroundColor: color.value }} />
              <div className="p-4">
                <h3 className="font-bold">{color.name}</h3>
                <p className="mt-1 font-mono text-sm text-muted-foreground">{color.value}</p>
              </div>
            </Card>
          ))}
        </div>
        <div className="mt-8 grid gap-5 lg:grid-cols-2">
          <Card className="p-6">
            <h2 className="text-2xl font-extrabold">{locale === 'ar' ? 'الخطوط' : 'Typography'}</h2>
            <p className="mt-3 text-muted-foreground">Tajawal للعربية، Inter للنصوص الإنجليزية، وPlus Jakarta Sans للعناوين الإنجليزية.</p>
          </Card>
          <Card className="p-6">
            <h2 className="text-2xl font-extrabold">{locale === 'ar' ? 'نمط المكونات' : 'Component style'}</h2>
            <p className="mt-3 text-muted-foreground">حواف دائرية كبيرة، ظلال ناعمة، تباين واضح، وتركيز على القراءة السريعة في واجهات SaaS.</p>
          </Card>
        </div>
      </div>
    </section>
  );
}
