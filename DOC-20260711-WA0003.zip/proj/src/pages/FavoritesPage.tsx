import { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';
import type { AITool } from '@/types';
import { ToolCard } from '@/components/domain/ToolCard';
import { EmptyState } from '@/components/feedback/EmptyState';
import { ErrorState } from '@/components/feedback/ErrorState';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Skeleton } from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';
import { getUserFavorites, toggleFavorite } from '@/services/favoriteService';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

export function FavoritesPage() {
  const { locale } = useLocale();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [favorites, setFavorites] = useState<AITool[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  useSeo(locale === 'ar' ? 'المفضلة' : 'Favorites');

  useEffect(() => {
    if (!user) return;
    let isMounted = true;
    setIsLoading(true);
    getUserFavorites(user.id)
      .then((loadedFavorites) => {
        if (isMounted) setFavorites(loadedFavorites);
      })
      .catch(() => {
        if (isMounted) setHasError(true);
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, [user]);

  async function handleRemoveFavorite(tool: AITool) {
    if (!user) return;
    await toggleFavorite(user.id, tool.id);
    setFavorites((current) => current.filter((item) => item.id !== tool.id));
    showToast({ title: locale === 'ar' ? 'تم حذف الأداة من المفضلة' : 'Removed from favorites', tone: 'success' });
  }

  return (
    <div>
      <SectionHeader title={locale === 'ar' ? 'الأدوات المفضلة' : 'Favorite tools'} description={locale === 'ar' ? 'الأدوات المحفوظة مرتبطة الآن بجدول Favorites وتظهر حسب المستخدم الحالي.' : 'Saved tools are now connected to the Favorites collection and shown per current user.'} />
      {hasError ? (
        <ErrorState title={locale === 'ar' ? 'تعذر تحميل المفضلة' : 'Could not load favorites'} description={locale === 'ar' ? 'حدث خطأ أثناء قراءة قاعدة البيانات.' : 'An error occurred while reading the database.'} />
      ) : isLoading ? (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{Array.from({ length: 3 }).map((_, index) => <Skeleton key={index} className="h-72" />)}</div>
      ) : favorites.length ? (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{favorites.map((tool) => <ToolCard key={tool.id} tool={tool} isFavorite onToggleFavorite={handleRemoveFavorite} />)}</div>
      ) : (
        <EmptyState title={locale === 'ar' ? 'لا توجد مفضلة' : 'No favorites yet'} description={locale === 'ar' ? 'اضغط على رمز القلب داخل بطاقة الأداة لإضافتها هنا.' : 'Press the heart icon inside a tool card to add it here.'} action={<Heart className="h-5 w-5 text-primary" />} />
      )}
    </div>
  );
}
