/**
 * Terms of Service Page — AI Hub Arabia
 * شروط الاستخدام — منصة AI Hub Arabia
 *
 * محتوى قانوني شامل باللغتين العربية والإنجليزية.
 * راجع هذه الشروط مع مستشار قانوني قبل الإطلاق الرسمي.
 */

import type { ReactNode } from 'react';
import { FileText } from 'lucide-react';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

const LAST_UPDATED_AR = '9 يوليو 2026';
const LAST_UPDATED_EN = 'July 9, 2026';
const EFFECTIVE_DATE_AR = '9 يوليو 2026';
const EFFECTIVE_DATE_EN = 'July 9, 2026';

export function TermsPage() {
  const { locale } = useLocale();
  const isArabic = locale === 'ar';

  useSeo({
    title: isArabic ? 'شروط الاستخدام' : 'Terms of Service',
    description: isArabic
      ? 'اقرأ شروط استخدام منصة AI Hub Arabia قبل التسجيل أو استخدام أي من خدماتها.'
      : 'Read the Terms of Service for AI Hub Arabia before registering or using any of its services.',
    canonicalPath: '/terms',
  });

  return (
    <div className="section-padding">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-10 text-center">
          <div className="mb-4 flex justify-center">
            <div className="rounded-2xl bg-teal-50 p-4 dark:bg-teal-900/20">
              <FileText className="h-8 w-8 text-teal-600 dark:text-teal-400" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {isArabic ? 'شروط الاستخدام' : 'Terms of Service'}
          </h1>
          <p className="mt-3 text-sm text-gray-500 dark:text-gray-400">
            {isArabic
              ? `تاريخ السريان: ${EFFECTIVE_DATE_AR} — آخر تحديث: ${LAST_UPDATED_AR}`
              : `Effective: ${EFFECTIVE_DATE_EN} — Last updated: ${LAST_UPDATED_EN}`}
          </p>
        </div>

        {/* Content */}
        <div className="space-y-8">
          {isArabic ? <ArabicContent /> : <EnglishContent />}
        </div>
      </div>
    </div>
  );
}

// ── المحتوى العربي ──────────────────────────────────────────────────────────

function ArabicContent() {
  return (
    <div className="space-y-6 text-right" dir="rtl">
      <Section title="القبول والموافقة">
        <p>
          باستخدامك لمنصة <strong>AI Hub Arabia</strong>، سواء بالتسجيل أو التصفح، فإنك تُقرُّ بقراءتك لهذه الشروط وفهمها
          والموافقة الكاملة عليها. إذا كنت لا توافق على أي بند، يُرجى التوقف عن استخدام المنصة فورًا.
        </p>
        <p>
          هذه الشروط ملزمة قانونيًا بينك وبين منصة AI Hub Arabia. نحتفظ بالحق في تعديلها في أي وقت مع إشعارك وفق ما هو موضَّح
          في البند المتعلق بالتحديثات.
        </p>
      </Section>

      <Section title="وصف الخدمة">
        <p>
          AI Hub Arabia هي منصة رقمية ثنائية اللغة (عربي / إنجليزي) تُتيح:
        </p>
        <ul>
          <li>اكتشاف أدوات الذكاء الاصطناعي وتصفُّح فئاتها.</li>
          <li>مقارنة الأدوات جنبًا إلى جنب لاتخاذ قرارات مستنيرة.</li>
          <li>حفظ أدوات مفضَّلة وإدارة قوائم مخصَّصة.</li>
          <li>كتابة تقييمات ومراجعات للأدوات وقراءة تقييمات الآخرين.</li>
          <li>البحث المتقدَّم والفلترة عبر معايير متعددة.</li>
        </ul>
        <p>
          المعلومات المتعلقة بالأدوات الخارجية (الأسعار، الميزات، التوافر) مُقدَّمة لأغراض إعلامية فقط وقابلة للتغيير.
          الروابط الخارجية تُقوِّدك إلى مواقع أطراف ثالثة لا نتحمل مسؤوليتها.
        </p>
      </Section>

      <Section title="إنشاء الحساب وأمانه">
        <ul>
          <li>يجب أن تكون في سن 13 عامًا أو أكبر لإنشاء حساب.</li>
          <li>المعلومات التي تُقدِّمها عند التسجيل يجب أن تكون صحيحة ودقيقة.</li>
          <li>أنت مسؤول كليًّا عن الحفاظ على سرية بيانات تسجيل دخولك.</li>
          <li>أي نشاط يحدث تحت حسابك يُعَدُّ مسؤوليتك الكاملة.</li>
          <li>في حال الاشتباه في اختراق حسابك، يجب إخطارنا فورًا عبر صفحة التواصل.</li>
          <li>يُحظر إنشاء أكثر من حساب واحد أو انتحال هوية شخص آخر.</li>
        </ul>
      </Section>

      <Section title="السلوك المقبول">
        <p>توافق على استخدام المنصة بشكل مسؤول والامتثال للمعايير التالية:</p>
        <ul>
          <li>عدم نشر محتوى مسيء أو مُضلِّل أو غير قانوني.</li>
          <li>عدم محاولة اختراق المنصة أو التحايل على إجراءات الأمان.</li>
          <li>عدم استخدام أدوات آلية (Bots) لجمع البيانات أو إرسال طلبات مكثَّفة.</li>
          <li>عدم نشر محتوى ترويجي أو إعلانات غير مُصرَّح بها.</li>
          <li>تقديم تقييمات صادقة وحقيقية تعكس تجربتك الفعلية.</li>
          <li>احترام حقوق الملكية الفكرية للمنصة وأطراف ثالثة.</li>
        </ul>
      </Section>

      <Section title="المحتوى الذي تُنشئه (User-Generated Content)">
        <p>
          بنشرك تقييمات أو تعليقات على المنصة، فإنك تمنحنا ترخيصًا غير حصري وعالمي لعرض هذا المحتوى وتوزيعه داخل المنصة.
        </p>
        <ul>
          <li>تحتفظ بحقوق ملكية المحتوى الذي تُنشئه.</li>
          <li>أنت مسؤول عن دقة المراجعات وعدم انتهاك حقوق الآخرين فيها.</li>
          <li>نحتفظ بالحق في إزالة أي محتوى يُخالف هذه الشروط أو سياسة الخصوصية.</li>
        </ul>
      </Section>

      <Section title="حقوق الملكية الفكرية">
        <p>
          جميع محتويات المنصة (التصميم، الكود، الشعار، النصوص الأصلية) محمية بموجب قوانين حقوق النشر والملكية الفكرية.
          لا يُسمح بنسخ أو إعادة استخدام أي محتوى إلا بإذن كتابي مسبق.
        </p>
        <p>أسماء وعلامات الأدوات الخارجية المُدرَجة على المنصة ملك لأصحابها المعنيين.</p>
      </Section>

      <Section title="إخلاء المسؤولية">
        <p>
          تُقدَّم المنصة <strong>"كما هي"</strong> دون ضمانات صريحة أو ضمنية. لا نضمن:
        </p>
        <ul>
          <li>دقة أو اكتمال معلومات الأدوات الخارجية بشكل مستمر.</li>
          <li>توافر المنصة بصورة مستمرة وخالية من الأعطال.</li>
          <li>ملاءمة أي أداة معيَّنة لاحتياجاتك الخاصة.</li>
        </ul>
        <p>
          لا نتحمل مسؤولية أي خسائر أو أضرار مباشرة أو غير مباشرة تنجم عن استخدام المنصة أو الاعتماد على معلوماتها.
        </p>
      </Section>

      <Section title="إنهاء الحساب">
        <p>يمكنك إنهاء استخدام المنصة في أي وقت بحذف حسابك من إعدادات الملف الشخصي.</p>
        <p>
          نحتفظ بالحق في تعليق أو إلغاء أي حساب يُخالف هذه الشروط، مع إشعار مسبق كلما أمكن ذلك.
          في حالات الانتهاك الجسيم، قد يكون الإلغاء فوريًا.
        </p>
      </Section>

      <Section title="القانون المنطبق">
        <p>
          تخضع هذه الشروط للقوانين المعمول بها في مملكة المملكة العربية السعودية.
          تُحسم أي نزاعات عبر التفاوض الودِّي أولًا، ثم التحكيم إذا لزم الأمر.
        </p>
      </Section>

      <Section title="تحديثات الشروط">
        <p>
          قد نُعدِّل هذه الشروط من وقت لآخر. سيُشار إلى تاريخ التحديث في أعلى هذه الصفحة.
          استمرارك في استخدام المنصة بعد التحديث يُعَدُّ قبولًا للشروط المُعدَّلة.
          للتغييرات الجوهرية، سنُرسل إشعارًا عبر البريد الإلكتروني قبل 14 يومًا.
        </p>
      </Section>

      <Section title="تواصل معنا">
        <p>
          لأي استفسار حول هذه الشروط، تواصل معنا عبر{' '}
          <a href="/contact" className="text-teal-600 underline">صفحة التواصل</a>.
        </p>
      </Section>
    </div>
  );
}

// ── English Content ──────────────────────────────────────────────────────────

function EnglishContent() {
  return (
    <div className="space-y-6" dir="ltr">
      <Section title="Acceptance of Terms">
        <p>
          By accessing or using <strong>AI Hub Arabia</strong> — whether by registering or browsing — you acknowledge that
          you have read, understood, and agreed to these Terms of Service. If you do not agree, please stop using the platform immediately.
        </p>
        <p>
          These Terms form a legally binding agreement between you and AI Hub Arabia. We reserve the right to modify them
          at any time, with notice as described in the Updates section below.
        </p>
      </Section>

      <Section title="Service Description">
        <p>AI Hub Arabia is a bilingual (Arabic/English) digital platform that provides:</p>
        <ul>
          <li>Discovery and browsing of AI tools by category.</li>
          <li>Side-by-side tool comparisons for informed decisions.</li>
          <li>Saving favorites and managing personalized lists.</li>
          <li>Writing and reading ratings and reviews for AI tools.</li>
          <li>Advanced search and multi-criteria filtering.</li>
        </ul>
        <p>
          Information about third-party tools (pricing, features, availability) is provided for informational purposes only
          and is subject to change. External links direct you to third-party websites for which we bear no responsibility.
        </p>
      </Section>

      <Section title="Account Creation and Security">
        <ul>
          <li>You must be at least 13 years old to create an account.</li>
          <li>The information you provide during registration must be accurate and truthful.</li>
          <li>You are solely responsible for maintaining the confidentiality of your login credentials.</li>
          <li>Any activity under your account is your full responsibility.</li>
          <li>If you suspect your account has been compromised, notify us immediately via the Contact page.</li>
          <li>Creating multiple accounts or impersonating another person is prohibited.</li>
        </ul>
      </Section>

      <Section title="Acceptable Use">
        <p>You agree to use the platform responsibly and comply with the following standards:</p>
        <ul>
          <li>Do not post offensive, misleading, or unlawful content.</li>
          <li>Do not attempt to breach the platform or circumvent security measures.</li>
          <li>Do not use automated tools (bots) to scrape data or send mass requests.</li>
          <li>Do not post unauthorized promotional content or advertisements.</li>
          <li>Submit honest reviews that reflect your actual experience.</li>
          <li>Respect the intellectual property rights of the platform and third parties.</li>
        </ul>
      </Section>

      <Section title="User-Generated Content">
        <p>
          By posting reviews or comments on the platform, you grant us a non-exclusive, worldwide license to display
          and distribute that content within the platform.
        </p>
        <ul>
          <li>You retain ownership of the content you create.</li>
          <li>You are responsible for the accuracy of your reviews and for not infringing on others' rights.</li>
          <li>We reserve the right to remove any content that violates these Terms or our Privacy Policy.</li>
        </ul>
      </Section>

      <Section title="Intellectual Property">
        <p>
          All platform content (design, code, logo, original text) is protected by copyright and intellectual property laws.
          No content may be copied or reused without prior written permission.
        </p>
        <p>Names and trademarks of external tools listed on the platform belong to their respective owners.</p>
      </Section>

      <Section title="Disclaimers">
        <p>
          The platform is provided <strong>"as is"</strong> without express or implied warranties. We do not guarantee:
        </p>
        <ul>
          <li>Continuous accuracy or completeness of third-party tool information.</li>
          <li>Uninterrupted or error-free platform availability.</li>
          <li>The suitability of any specific tool for your particular needs.</li>
        </ul>
        <p>
          We are not liable for any direct or indirect losses or damages arising from platform use or reliance on its information.
        </p>
      </Section>

      <Section title="Account Termination">
        <p>You may stop using the platform at any time by deleting your account from profile settings.</p>
        <p>
          We reserve the right to suspend or terminate any account that violates these Terms, with advance notice whenever possible.
          In cases of serious violations, termination may be immediate.
        </p>
      </Section>

      <Section title="Governing Law">
        <p>
          These Terms are governed by the applicable laws of the Kingdom of Saudi Arabia.
          Any disputes shall be resolved first through good-faith negotiation, then arbitration if necessary.
        </p>
      </Section>

      <Section title="Updates to Terms">
        <p>
          We may update these Terms from time to time. The update date will be shown at the top of this page.
          Your continued use of the platform after an update constitutes acceptance of the revised Terms.
          For material changes, we will send notice via email at least 14 days in advance.
        </p>
      </Section>

      <Section title="Contact Us">
        <p>
          For any questions about these Terms, contact us via the{' '}
          <a href="/contact" className="text-teal-600 underline">Contact Page</a>.
        </p>
      </Section>
    </div>
  );
}

// ── Helper Components ────────────────────────────────────────────────────────

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
      <h2 className="mb-4 text-xl font-bold text-gray-900 dark:text-white">{title}</h2>
      <div className="space-y-3 text-gray-700 dark:text-gray-300 leading-relaxed">{children}</div>
    </section>
  );
}
