import { Compass, Layers3, ShieldCheck, Sparkles } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { useLocale } from '@/hooks/useLocale';
import { useSeo } from '@/hooks/useSeo';

export function AboutPage() {
  const { locale } = useLocale();
  useSeo(locale === 'ar' ? 'من نحن' : 'About');
  const values = [
    { icon: <Compass className="h-6 w-6" />, ar: 'وضوح الاختيار', en: 'Clear decisions' },
    { icon: <Layers3 className="h-6 w-6" />, ar: 'تصنيف قابل للتوسع', en: 'Scalable taxonomy' },
    { icon: <ShieldCheck className="h-6 w-6" />, ar: 'ثقة وشفافية', en: 'Trust and transparency' },
    { icon: <Sparkles className="h-6 w-6" />, ar: 'تجربة حديثة', en: 'Modern experience' },
  ];

  return (
    <section className="section-padding">
      <div className="container">
        <SectionHeader centered eyebrow={locale === 'ar' ? 'من نحن' : 'About us'} title={locale === 'ar' ? 'AI Hub Arabia منصة عربية حديثة لاكتشاف أدوات الذكاء الاصطناعي' : 'AI Hub Arabia is a modern Arabic-first AI tools discovery platform'} description={locale === 'ar' ? 'الهدف هو مساعدة الأفراد والفرق على اختيار الأدوات المناسبة بسرعة من خلال واجهة واضحة، مقارنة عادلة، وتصنيفات منظمة.' : 'The goal is to help individuals and teams select suitable tools quickly through clear UI, fair comparison, and organized categories.'} />
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {values.map((value) => <Card key={value.en} className="p-6 text-center"><div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-primary/10 text-primary">{value.icon}</div><h2 className="font-bold">{locale === 'ar' ? value.ar : value.en}</h2></Card>)}
        </div>
        <Card className="mt-10 p-6 md:p-8">
          <h2 className="text-2xl font-extrabold">{locale === 'ar' ? 'خارطة التطوير' : 'Development roadmap'}</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {[
              { ar: 'المرحلة 1: الأساس والهوية', en: 'Phase 1: foundation and identity' },
              { ar: 'المرحلة 2: واجهات الموقع', en: 'Phase 2: complete UI' },
              { ar: 'المراحل القادمة: البيانات والمصادقة والربط', en: 'Next phases: data, authentication, integrations' },
            ].map((item, index) => <div key={item.en} className="rounded-2xl bg-muted p-4"><strong className="text-primary">0{index + 1}</strong><p className="mt-2 text-sm text-muted-foreground">{locale === 'ar' ? item.ar : item.en}</p></div>)}
          </div>
        </Card>
      </div>
    </section>
  );
}
