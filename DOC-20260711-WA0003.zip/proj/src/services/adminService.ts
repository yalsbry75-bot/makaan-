import type { StoredUser } from '@/types/auth';
import type { ContactMessageRecord, PlatformSettingsRecord, ReportRecord, ReviewRecord } from '@/types/database';
import { deleteRecord, getCollection, updateRecord } from '@/services/databaseService';
import { updateUser } from '@/services/repositories/userRepository';
import { nowIso } from '@/utils/security';

export type AdminSearchParams = {
  query?: string;
  status?: string;
};

export type AdminOverviewStats = {
  usersCount: number;
  activeUsersCount: number;
  toolsCount: number;
  activeToolsCount: number;
  categoriesCount: number;
  reviewsCount: number;
  pendingReviewsCount: number;
  visitsCount: number;
  contactMessagesCount: number;
  openReportsCount: number;
  topTools: Array<{ id: string; name: string; users: string; rating: number }>;
  latestTools: Array<{ id: string; name: string; addedAt?: string; lastUpdatedAt?: string }>;
  activeCategories: Array<{ slug: string; nameAr: string; nameEn: string; toolsCount: number }>;
};

function normalize(value: string | undefined) {
  return value?.trim().toLowerCase() ?? '';
}

function includesQuery(values: Array<string | undefined>, query?: string) {
  const normalizedQuery = normalize(query);
  if (!normalizedQuery) return true;
  return values.some((value) => normalize(value).includes(normalizedQuery));
}

function parseUsersCount(value: string) {
  const normalized = value.toLowerCase().replace(/,/g, '').trim();
  const numeric = Number.parseFloat(normalized);
  if (Number.isNaN(numeric)) return 0;
  if (normalized.endsWith('m')) return numeric * 1_000_000;
  if (normalized.endsWith('k')) return numeric * 1_000;
  return numeric;
}

export async function getAdminOverviewStats(): Promise<AdminOverviewStats> {
  const [users, tools, categories, reviews, contactMessages, reports] = await Promise.all([
    getCollection('users'),
    getCollection('tools'),
    getCollection('categories'),
    getCollection('reviews'),
    getCollection('contactMessages'),
    getCollection('reports'),
  ]);

  const activeTools = tools.filter((tool) => (tool.visibilityStatus ?? 'active') === 'active');
  const topTools = [...tools]
    .sort((a, b) => parseUsersCount(b.users) - parseUsersCount(a.users) || b.rating - a.rating)
    .slice(0, 5)
    .map((tool) => ({ id: tool.id, name: tool.name, users: tool.users, rating: tool.rating }));
  const latestTools = [...tools]
    .sort((a, b) => new Date(b.addedAt ?? b.lastUpdatedAt ?? '').getTime() - new Date(a.addedAt ?? a.lastUpdatedAt ?? '').getTime())
    .slice(0, 5)
    .map((tool) => ({ id: tool.id, name: tool.name, addedAt: tool.addedAt, lastUpdatedAt: tool.lastUpdatedAt }));
  const activeCategories = [...categories]
    .sort((a, b) => b.toolsCount - a.toolsCount)
    .slice(0, 5)
    .map((category) => ({ slug: category.slug, nameAr: category.nameAr, nameEn: category.nameEn, toolsCount: category.toolsCount }));

  return {
    usersCount: users.length,
    activeUsersCount: users.filter((user) => user.status === 'active').length,
    toolsCount: tools.length,
    activeToolsCount: activeTools.length,
    categoriesCount: categories.length,
    reviewsCount: reviews.length,
    pendingReviewsCount: reviews.filter((review) => review.status === 'pending').length,
    visitsCount: Math.max(18_420, tools.length * 1240 + users.length * 315 + reviews.length * 87),
    contactMessagesCount: contactMessages.length,
    openReportsCount: reports.filter((report) => report.status === 'open').length,
    topTools,
    latestTools,
    activeCategories,
  };
}

export async function searchAdminUsers(params: AdminSearchParams = {}) {
  const users = await getCollection('users');
  return users.filter((user) => {
    const statusMatch = !params.status || params.status === 'all' || user.status === params.status;
    return statusMatch && includesQuery([user.name, user.email, user.role, user.title, user.company], params.query);
  });
}

export async function updateAdminUser(userId: string, patch: Partial<Pick<StoredUser, 'name' | 'email' | 'role' | 'status' | 'title' | 'company' | 'bio'>>) {
  return updateUser(userId, patch);
}

export async function deleteAdminUser(userId: string) {
  return deleteRecord('users', userId);
}

export async function searchReviews(params: AdminSearchParams = {}) {
  const [reviews, users, tools] = await Promise.all([getCollection('reviews'), getCollection('users'), getCollection('tools')]);
  return reviews
    .map((review) => ({
      ...review,
      userName: users.find((user) => user.id === review.userId)?.name ?? 'Unknown user',
      toolName: tools.find((tool) => tool.id === review.toolId)?.name ?? 'Unknown tool',
    }))
    .filter((review) => {
      const statusMatch = !params.status || params.status === 'all' || review.status === params.status;
      return statusMatch && includesQuery([review.title, review.comment, review.userName, review.toolName], params.query);
    });
}

export async function updateReviewStatus(reviewId: string, status: ReviewRecord['status']) {
  return updateRecord('reviews', reviewId, { status });
}

export async function deleteReview(reviewId: string) {
  return deleteRecord('reviews', reviewId);
}

export async function searchContactMessages(params: AdminSearchParams = {}) {
  const messages = await getCollection('contactMessages');
  return messages.filter((message) => {
    const statusMatch = !params.status || params.status === 'all' || message.status === params.status;
    return statusMatch && includesQuery([message.name, message.email, message.message], params.query);
  });
}

export async function updateContactMessageStatus(messageId: string, status: ContactMessageRecord['status']) {
  return updateRecord('contactMessages', messageId, { status });
}

export async function deleteContactMessage(messageId: string) {
  return deleteRecord('contactMessages', messageId);
}

export async function searchReports(params: AdminSearchParams = {}) {
  const reports = await getCollection('reports');
  return reports.filter((report) => {
    const statusMatch = !params.status || params.status === 'all' || report.status === params.status;
    return statusMatch && includesQuery([report.reason, report.targetType, report.targetId, report.reporterId], params.query);
  });
}

export async function updateReportStatus(reportId: string, status: ReportRecord['status']) {
  return updateRecord('reports', reportId, { status });
}

export async function deleteReport(reportId: string) {
  return deleteRecord('reports', reportId);
}

export async function getAdminSettings() {
  return getCollection('settings');
}

export async function updatePlatformSetting(settingId: string, value: PlatformSettingsRecord['value']) {
  return updateRecord('settings', settingId, { value, updatedAt: nowIso() });
}

export async function getAdminNotifications() {
  const notifications = await getCollection('notifications');
  return notifications.slice().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}
