import type { ReviewRecord } from '@/types/database';
import { createRecord, deleteRecord, getCollection, updateRecord } from '@/services/databaseService';
import { createReport } from '@/services/reportService';
import { createId, nowIso, sanitizeText } from '@/utils/security';

export async function getReviewsByTool(toolId: string) {
  const reviews = await getCollection('reviews');
  return reviews.filter((review) => review.toolId === toolId && review.status === 'approved');
}

export async function getReviewsForTool(toolId: string, userId?: string) {
  const reviews = await getCollection('reviews');
  return reviews.filter((review) => review.toolId === toolId && (review.status === 'approved' || review.userId === userId));
}

export async function getUserReviewForTool(userId: string, toolId: string) {
  const reviews = await getCollection('reviews');
  return reviews.find((review) => review.userId === userId && review.toolId === toolId) ?? null;
}

export async function getPendingReviews() {
  const reviews = await getCollection('reviews');
  return reviews.filter((review) => review.status === 'pending');
}

export async function createReview(payload: Omit<ReviewRecord, 'id' | 'createdAt' | 'updatedAt' | 'status'>) {
  const existing = await getUserReviewForTool(payload.userId, payload.toolId);
  if (existing) throw new Error('You already reviewed this tool. Edit your existing review instead.');
  const createdAt = nowIso();
  return createRecord('reviews', {
    ...payload,
    title: sanitizeText(payload.title, 120),
    comment: sanitizeText(payload.comment, 1500),
    rating: Math.max(1, Math.min(5, payload.rating)),
    id: createId('review'),
    status: 'pending',
    createdAt,
    updatedAt: createdAt,
  });
}

export async function updateUserReview(reviewId: string, userId: string, patch: Pick<ReviewRecord, 'rating' | 'title' | 'comment'>) {
  const reviews = await getCollection('reviews');
  const review = reviews.find((item) => item.id === reviewId);
  if (!review || review.userId !== userId) throw new Error('Review not found or permission denied.');
  return updateRecord('reviews', reviewId, { rating: Math.max(1, Math.min(5, patch.rating)), title: sanitizeText(patch.title, 120), comment: sanitizeText(patch.comment, 1500), status: 'pending' });
}

export async function deleteUserReview(reviewId: string, userId: string) {
  const reviews = await getCollection('reviews');
  const review = reviews.find((item) => item.id === reviewId);
  if (!review || review.userId !== userId) throw new Error('Review not found or permission denied.');
  return deleteRecord('reviews', reviewId);
}

export async function reportReview(reporterId: string, reviewId: string, reason: string) {
  return createReport({ reporterId, targetType: 'review', targetId: reviewId, reason });
}

export async function updateReviewStatus(reviewId: string, status: ReviewRecord['status']) {
  return updateRecord('reviews', reviewId, { status });
}
