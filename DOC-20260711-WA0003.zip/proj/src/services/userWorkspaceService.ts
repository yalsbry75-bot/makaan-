import type { AITool } from '@/types';
import type { ComparisonRecord, ReviewRecord } from '@/types/database';
import { deleteRecord, getCollection, updateRecord } from '@/services/databaseService';
import { sanitizeText } from '@/utils/security';

export type UserReviewWithTool = ReviewRecord & {
  tool?: Pick<AITool, 'id' | 'slug' | 'name' | 'logoGradient' | 'categorySlug' | 'pricing' | 'rating'>;
};

export type UserComparisonWithTools = ComparisonRecord & {
  tools: AITool[];
};

export async function getUserReviewsWithTools(userId: string): Promise<UserReviewWithTool[]> {
  const [reviews, tools] = await Promise.all([getCollection('reviews'), getCollection('tools')]);
  return reviews
    .filter((review) => review.userId === userId)
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .map((review) => ({ ...review, tool: tools.find((tool) => tool.id === review.toolId) }));
}

export async function getUserComparisonsWithTools(userId: string): Promise<UserComparisonWithTools[]> {
  const [comparisons, tools] = await Promise.all([getCollection('comparisons'), getCollection('tools')]);
  return comparisons
    .filter((comparison) => comparison.userId === userId)
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .map((comparison) => ({
      ...comparison,
      tools: comparison.toolIds.map((toolId) => tools.find((tool) => tool.id === toolId)).filter(Boolean) as AITool[],
    }));
}

export async function renameUserComparison(userId: string, comparisonId: string, name: string) {
  const comparisons = await getCollection('comparisons');
  const comparison = comparisons.find((item) => item.id === comparisonId);
  if (!comparison || comparison.userId !== userId) throw new Error('Comparison not found or permission denied.');
  return updateRecord('comparisons', comparisonId, { name: sanitizeText(name, 120) || comparison.name });
}

export async function deleteUserComparison(userId: string, comparisonId: string) {
  const comparisons = await getCollection('comparisons');
  const comparison = comparisons.find((item) => item.id === comparisonId);
  if (!comparison || comparison.userId !== userId) throw new Error('Comparison not found or permission denied.');
  return deleteRecord('comparisons', comparisonId);
}
