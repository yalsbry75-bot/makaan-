/**
 * Database Service — AI Hub Arabia
 * Phase 14: Real Services Integration
 *
 * وضع التشغيل:
 * - VITE_USE_FIREBASE=true  → يستخدم Firestore (الإنتاج)
 * - VITE_USE_FIREBASE=false → يستخدم localStorage (التطوير/التجربة)
 *
 * جميع الدوال المُصدَّرة متوافقة تمامًا — لا يحتاج أي service آخر للتعديل.
 */

import { isFirebaseConfigured } from '@/firebase/config';
import {
  firestoreGetCollection,
  firestoreSetCollection,
  firestoreFindRecord,
  firestoreCreateRecord,
  firestoreUpdateRecord,
  firestoreDeleteRecord,
} from '@/firebase/db';
import { createInitialDatabase, ensureCoreSeeds } from '@/data/seedDatabase';
import type { CollectionName, DatabaseCollectionMap, DatabaseSchema } from '@/types/database';
import { nowIso, safeJsonParse, sanitizeRecord } from '@/utils/security';

// ── إعداد localStorage ──────────────────────────────────────────────────────

const DATABASE_KEY = 'ai-hub-arabia-database-v13';
const LEGACY_DATABASE_KEYS = [
  'ai-hub-arabia-database-v12',
  'ai-hub-arabia-database-v11',
  'ai-hub-arabia-database-v9',
  'ai-hub-arabia-database-v8',
  'ai-hub-arabia-database-v7',
  'ai-hub-arabia-database-v6',
];
const DATABASE_VERSION_KEY = 'ai-hub-arabia-database-version';
const DATABASE_VERSION = '14.0.0';

export class DatabaseError extends Error {
  code: string;

  constructor(message: string, code = 'DATABASE_ERROR') {
    super(message);
    this.name = 'DatabaseError';
    this.code = code;
  }
}

function hasWindowStorage() {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

export function delay(ms = 180) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function readDatabaseSync(): DatabaseSchema {
  if (!hasWindowStorage()) return createInitialDatabase();
  const current = window.localStorage.getItem(DATABASE_KEY);
  const legacy = LEGACY_DATABASE_KEYS.map((key) => window.localStorage.getItem(key)).find(Boolean) ?? null;
  const stored = safeJsonParse<DatabaseSchema | null>(current ?? legacy, null);
  const database = ensureCoreSeeds(stored ?? createInitialDatabase());
  if (!stored || window.localStorage.getItem(DATABASE_VERSION_KEY) !== DATABASE_VERSION) {
    writeDatabaseSync(database);
  }
  return database;
}

function writeDatabaseSync(database: DatabaseSchema) {
  if (!hasWindowStorage()) return;
  window.localStorage.setItem(DATABASE_KEY, JSON.stringify(database));
  window.localStorage.setItem(DATABASE_VERSION_KEY, DATABASE_VERSION);
}

// ── الدوال الأساسية (موزَّعة بين localStorage وFirestore) ───────────────────

export async function initializeDatabase() {
  if (isFirebaseConfigured()) {
    // Firestore: لا حاجة لتهيئة — Firebase يُدير الاتصال
    return {} as DatabaseSchema;
  }
  await delay(80);
  const database = readDatabaseSync();
  writeDatabaseSync(database);
  return database;
}

export async function resetDatabase() {
  if (isFirebaseConfigured()) {
    throw new DatabaseError('إعادة تعيين قاعدة البيانات غير مدعومة في وضع Firestore.', 'NOT_SUPPORTED');
  }
  await delay(120);
  const database = createInitialDatabase();
  writeDatabaseSync(database);
  return database;
}

export async function getDatabase(): Promise<DatabaseSchema> {
  if (isFirebaseConfigured()) {
    throw new DatabaseError('getDatabase() غير مدعوم في وضع Firestore. استخدم getCollection().', 'NOT_SUPPORTED');
  }
  await delay(80);
  return readDatabaseSync();
}

export async function getCollection<TCollection extends CollectionName>(
  collection: TCollection,
): Promise<Array<DatabaseCollectionMap[TCollection]>> {
  if (isFirebaseConfigured()) {
    return firestoreGetCollection(collection);
  }
  const database = await getDatabase();
  return [...database[collection]] as Array<DatabaseCollectionMap[TCollection]>;
}

export async function setCollection<TCollection extends CollectionName>(
  collection: TCollection,
  records: Array<DatabaseCollectionMap[TCollection]>,
): Promise<Array<DatabaseCollectionMap[TCollection]>> {
  if (isFirebaseConfigured()) {
    return firestoreSetCollection(collection, records);
  }
  await delay(80);
  const database = readDatabaseSync();
  const nextDatabase = { ...database, [collection]: sanitizeRecord(records) } as DatabaseSchema;
  writeDatabaseSync(nextDatabase);
  return records;
}

export async function findRecord<TCollection extends CollectionName>(
  collection: TCollection,
  predicate: (record: DatabaseCollectionMap[TCollection]) => boolean,
): Promise<DatabaseCollectionMap[TCollection] | null> {
  if (isFirebaseConfigured()) {
    return firestoreFindRecord(collection, predicate);
  }
  const records = await getCollection(collection);
  return records.find(predicate) ?? null;
}

export async function createRecord<TCollection extends CollectionName>(
  collection: TCollection,
  record: DatabaseCollectionMap[TCollection],
): Promise<DatabaseCollectionMap[TCollection]> {
  if (isFirebaseConfigured()) {
    return firestoreCreateRecord(collection, record);
  }
  const records = await getCollection(collection);
  const sanitized = sanitizeRecord(record);
  await setCollection(collection, [...records, sanitized]);
  return sanitized;
}

export async function updateRecord<TCollection extends CollectionName>(
  collection: TCollection,
  id: string,
  patch: Partial<DatabaseCollectionMap[TCollection]>,
): Promise<DatabaseCollectionMap[TCollection]> {
  if (isFirebaseConfigured()) {
    return firestoreUpdateRecord(collection, id, patch);
  }
  const records = await getCollection(collection);
  let updated: DatabaseCollectionMap[TCollection] | null = null;
  const nextRecords = records.map((record) => {
    if ('id' in record && record.id === id) {
      updated = sanitizeRecord({ ...record, ...patch, updatedAt: nowIso() }) as DatabaseCollectionMap[TCollection];
      return updated;
    }
    return record;
  });
  if (!updated) throw new DatabaseError('Record not found.', 'NOT_FOUND');
  await setCollection(collection, nextRecords);
  return updated;
}

export async function deleteRecord<TCollection extends CollectionName>(
  collection: TCollection,
  id: string,
): Promise<{ deleted: boolean }> {
  if (isFirebaseConfigured()) {
    return firestoreDeleteRecord(collection, id);
  }
  const records = await getCollection(collection);
  const nextRecords = records.filter((record) => !('id' in record) || record.id !== id);
  await setCollection(collection, nextRecords);
  return { deleted: records.length !== nextRecords.length };
}

export function databaseMetadata() {
  const mode = isFirebaseConfigured() ? 'firestore' : 'localStorage';
  return {
    key: mode === 'firestore' ? `firestore:${import.meta.env.VITE_FIREBASE_PROJECT_ID}` : DATABASE_KEY,
    version: DATABASE_VERSION,
    mode,
    collections: [
      'users',
      'tools',
      'categories',
      'favorites',
      'reviews',
      'comparisons',
      'settings',
      'contactMessages',
      'reports',
      'notifications',
      'auditLogs',
    ] as CollectionName[],
    storage: mode === 'firestore' ? 'Cloud Firestore' : 'localStorage adapter with repository abstraction',
  };
}
