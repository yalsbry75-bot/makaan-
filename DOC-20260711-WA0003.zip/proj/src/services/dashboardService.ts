import type { AdminDashboardData, DashboardData } from '@/types/database';
import { getCollection } from '@/services/databaseService';
import { getUserFavorites } from '@/services/favoriteService';
import { getUserNotifications } from '@/services/notificationService';
import { listTools } from '@/services/repositories/catalogRepository';

export async function getUserDashboardData(userId: string): Promise<DashboardData> {
  const [favorites, comparisons, notifications, tools] = await Promise.all([
    getUserFavorites(userId),
    getCollection('comparisons'),
    getUserNotifications(userId),
    listTools({ sort: 'top-rated', limit: 6 }),
  ]);
  const userComparisons = comparisons.filter((comparison) => comparison.userId === userId);
  const unread = notifications.filter((notification) => !notification.read).length;
  const activeCategories = new Set(favorites.map((tool) => tool.categorySlug)).size || 1;

  return {
    stats: [
      { labelAr: 'الأدوات المحفوظة', labelEn: 'Saved tools', value: String(favorites.length), change: '+4' },
      { labelAr: 'عمليات المقارنة', labelEn: 'Comparisons', value: String(userComparisons.length), change: '+2' },
      { labelAr: 'تنبيهات جديدة', labelEn: 'New alerts', value: String(unread), change: '+3' },
      { labelAr: 'تصنيفات نشطة', labelEn: 'Active categories', value: String(activeCategories), change: '+1' },
    ],
    recentActivity: [
      { ar: `لديك ${favorites.length} أدوات محفوظة`, en: `You have ${favorites.length} saved tools`, time: '08:40' },
      { ar: `تم حفظ ${userComparisons.length} مقارنة`, en: `${userComparisons.length} comparisons saved`, time: '10:15' },
      { ar: `يوجد ${unread} تنبيهات غير مقروءة`, en: `${unread} unread notifications`, time: '12:05' },
    ],
    recommendedTools: tools.filter((tool) => !favorites.some((favorite) => favorite.id === tool.id)).slice(0, 3),
    notifications: notifications.slice(0, 4),
  };
}

export async function getAdminDashboardData(): Promise<AdminDashboardData> {
  const [tools, categories, reviews, users, contactMessages, reports] = await Promise.all([
    getCollection('tools'),
    getCollection('categories'),
    getCollection('reviews'),
    getCollection('users'),
    getCollection('contactMessages'),
    getCollection('reports'),
  ]);

  return { tools, categories, reviews, users, contactMessages, reports };
}
