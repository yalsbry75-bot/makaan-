import type { AuditLogRecord } from '@/types/database';
import type { AuthUser, UserRole } from '@/types/auth';
import { createRecord, getCollection } from '@/services/databaseService';
import { createId, nowIso, sanitizeText } from '@/utils/security';

export type AuditEventPayload = Omit<AuditLogRecord, 'id' | 'createdAt' | 'updatedAt'>;

export async function logAuditEvent(payload: AuditEventPayload) {
  try {
    const createdAt = nowIso();
    return await createRecord('auditLogs', {
      id: createId('audit'),
      event: sanitizeText(payload.event, 120),
      severity: payload.severity,
      actorId: payload.actorId,
      resource: payload.resource ? sanitizeText(payload.resource, 120) : undefined,
      metadata: payload.metadata,
      createdAt,
      updatedAt: createdAt,
    });
  } catch {
    return null;
  }
}

export async function getRecentAuditLogs(limit = 50) {
  const logs = await getCollection('auditLogs');
  return logs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, limit);
}

export function assertUserCan(user: AuthUser | null, roles?: UserRole[]) {
  if (!user) return false;
  if (!roles?.length) return true;
  return roles.includes(user.role);
}

export function validateSensitiveOperation(user: AuthUser | null, resource: string, roles?: UserRole[]) {
  const allowed = assertUserCan(user, roles);
  if (!allowed) {
    void logAuditEvent({
      actorId: user?.id,
      event: 'permission_denied',
      severity: 'warning',
      resource,
      metadata: { requiredRole: roles?.join(',') ?? 'authenticated' },
    });
  }
  return allowed;
}

export function redactError(error: unknown) {
  if (error instanceof Error) return sanitizeText(error.message, 300);
  return 'Unknown error';
}
