/**
 * Auth Service — AI Hub Arabia
 * Phase 14: Real Services Integration
 *
 * وضع التشغيل:
 * - VITE_USE_FIREBASE=true  → يستخدم Firebase Authentication + Firestore
 * - VITE_USE_FIREBASE=false → يستخدم localStorage (التطوير/التجربة)
 *
 * لا تُغيَّر الواجهة الخارجية — AuthContext يعمل بنفس الطريقة في الحالتين.
 */

import type {
  AccountSettingsPayload,
  AuthSession,
  AuthUser,
  PasswordChangePayload,
  PasswordResetPayload,
  ProfileUpdatePayload,
  SignInPayload,
  SignUpPayload,
  StoredUser,
  UserRole,
} from '@/types/auth';
import { AuthServiceError } from '@/types/auth';
import { delay } from '@/services/databaseService';
import { createUser, getUserByEmail, getUserById, updateUser } from '@/services/repositories/userRepository';
import { hasErrors, isValidEmail, validatePasswordChange, validateProfile, validateSignIn, validateSignUp } from '@/utils/authValidation';
import { logAuditEvent } from '@/services/securityService';
import { addDays, addHours, createId, hashPassword, normalizeEmail, nowIso, safeJsonParse, sanitizeOptionalUrl, sanitizeText } from '@/utils/security';
import { isFirebaseConfigured } from '@/firebase/config';
import {
  firebaseSignIn,
  firebaseSignUp,
  firebaseSignOut,
  firebaseSendPasswordReset,
  firebaseChangePassword,
  firebaseUpdateProfile,
  firebaseCurrentUser,
} from '@/firebase/auth';

// ── إعداد localStorage ──────────────────────────────────────────────────────

const LOCAL_SESSION_KEY = 'ai-hub-arabia-auth-session';
const TAB_SESSION_KEY = 'ai-hub-arabia-tab-session';
const RESET_REQUESTS_KEY = 'ai-hub-arabia-password-reset-requests';
const SESSION_HOURS = 8;
const REMEMBER_DAYS = 30;
const LOGIN_ATTEMPTS_KEY = 'ai-hub-arabia-login-attempts';
const MAX_LOGIN_ATTEMPTS = 6;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;

type ResetRequest = { email: string; token: string; createdAt: string };
type LoginAttempt = { email: string; count: number; lastAttemptAt: number };

// ── دوال مساعدة (localStorage) ─────────────────────────────────────────────

function getLoginAttempts() {
  return safeJsonParse<LoginAttempt[]>(window.localStorage.getItem(LOGIN_ATTEMPTS_KEY), []);
}

function assertLoginAllowed(email: string) {
  const now = Date.now();
  const attempts = getLoginAttempts().filter((attempt) => now - attempt.lastAttemptAt < LOGIN_WINDOW_MS);
  const current = attempts.find((attempt) => attempt.email === email);
  window.localStorage.setItem(LOGIN_ATTEMPTS_KEY, JSON.stringify(attempts));
  if (current && current.count >= MAX_LOGIN_ATTEMPTS) {
    throw new AuthServiceError('تم إيقاف محاولات الدخول مؤقتًا. حاول لاحقًا.', 'RATE_LIMITED', {
      email: 'تم تجاوز عدد المحاولات المسموح.',
    });
  }
}

function registerFailedLogin(email: string) {
  const now = Date.now();
  const attempts = getLoginAttempts().filter((attempt) => now - attempt.lastAttemptAt < LOGIN_WINDOW_MS);
  const current = attempts.find((attempt) => attempt.email === email);
  const nextAttempts = current
    ? attempts.map((attempt) => attempt.email === email ? { ...attempt, count: attempt.count + 1, lastAttemptAt: now } : attempt)
    : [...attempts, { email, count: 1, lastAttemptAt: now }];
  window.localStorage.setItem(LOGIN_ATTEMPTS_KEY, JSON.stringify(nextAttempts));
}

function clearFailedLogins(email: string) {
  window.localStorage.setItem(
    LOGIN_ATTEMPTS_KEY,
    JSON.stringify(getLoginAttempts().filter((attempt) => attempt.email !== email)),
  );
}

function omitPassword(user: StoredUser): AuthUser {
  const { passwordHash: _passwordHash, ...publicUser } = user;
  return publicUser;
}

function saveSession(session: AuthSession) {
  const target = session.remember ? window.localStorage : window.sessionStorage;
  const other = session.remember ? window.sessionStorage : window.localStorage;
  target.setItem(session.remember ? LOCAL_SESSION_KEY : TAB_SESSION_KEY, JSON.stringify(session));
  other.removeItem(session.remember ? TAB_SESSION_KEY : LOCAL_SESSION_KEY);
}

function clearStoredSessions() {
  window.localStorage.removeItem(LOCAL_SESSION_KEY);
  window.sessionStorage.removeItem(TAB_SESSION_KEY);
}

function createSession(user: AuthUser, remember = false): AuthSession {
  const issuedAt = new Date();
  const expiresAt = remember ? addDays(issuedAt, REMEMBER_DAYS) : addHours(issuedAt, SESSION_HOURS);
  return {
    user,
    remember,
    issuedAt: issuedAt.toISOString(),
    expiresAt: expiresAt.toISOString(),
    token: createId('session'),
  };
}

// ── دوال Firebase المساعدة ──────────────────────────────────────────────────

/**
 * يُحوِّل Firebase User + Firestore document إلى AuthUser.
 * إذا لم يوجد document في Firestore، يُنشئه تلقائيًا.
 */
async function resolveFirebaseUser(firebaseUid: string): Promise<AuthUser | null> {
  // ابحث عن المستخدم في Firestore بالـ UID
  let storedUser = await getUserById(firebaseUid);

  if (!storedUser) {
    // المستخدم موجود في Firebase Auth لكن ليس في Firestore
    // هذا يحدث إذا أُنشئ الحساب يدويًا في Firebase Console
    const fbUser = firebaseCurrentUser();
    if (!fbUser) return null;

    const createdAt = nowIso();
    const newUser: StoredUser = {
      id: firebaseUid,
      name: fbUser.displayName ?? fbUser.email?.split('@')[0] ?? 'مستخدم',
      email: normalizeEmail(fbUser.email ?? ''),
      role: 'user',
      status: 'active',
      title: 'AI Tools Explorer',
      company: '',
      bio: '',
      createdAt,
      updatedAt: createdAt,
      preferences: { locale: 'ar', theme: 'system', newsletter: true, productUpdates: true },
      passwordHash: '',
    };
    storedUser = await createUser(newUser);
  }

  if (storedUser.status !== 'active') return null;
  return omitPassword(storedUser);
}

// ── الدوال الرئيسية المُصدَّرة ──────────────────────────────────────────────

export async function getCurrentSession(): Promise<AuthSession | null> {
  if (isFirebaseConfigured()) {
    // في وضع Firebase، الجلسة تُدار بـ onAuthStateChanged في AuthContext
    // هذه الدالة لا تُستخدم مباشرةً في وضع Firebase
    const fbUser = firebaseCurrentUser();
    if (!fbUser) return null;
    const authUser = await resolveFirebaseUser(fbUser.uid);
    if (!authUser) return null;
    return createSession(authUser, true);
  }

  await delay(80);
  const session =
    safeJsonParse<AuthSession | null>(window.localStorage.getItem(LOCAL_SESSION_KEY), null) ??
    safeJsonParse<AuthSession | null>(window.sessionStorage.getItem(TAB_SESSION_KEY), null);

  if (!session) return null;
  if (new Date(session.expiresAt).getTime() < Date.now()) {
    await logAuditEvent({ actorId: session.user.id, event: 'session_expired', severity: 'info', resource: 'auth' });
    clearStoredSessions();
    return null;
  }

  const storedUser = await getUserById(session.user.id);
  if (!storedUser || storedUser.status !== 'active') {
    await logAuditEvent({ actorId: session.user.id, event: 'session_invalid_user', severity: 'warning', resource: 'auth' });
    clearStoredSessions();
    return null;
  }

  const hydratedSession = { ...session, user: omitPassword(storedUser) };
  saveSession(hydratedSession);
  return hydratedSession;
}

export async function signIn(payload: SignInPayload): Promise<AuthSession> {
  if (isFirebaseConfigured()) {
    const fieldErrors = validateSignIn(payload);
    if (hasErrors(fieldErrors)) {
      throw new AuthServiceError('يرجى تصحيح بيانات تسجيل الدخول.', 'VALIDATION_ERROR', fieldErrors);
    }

    try {
      const fbUser = await firebaseSignIn(payload.email.trim(), payload.password);
      const authUser = await resolveFirebaseUser(fbUser.uid);
      if (!authUser) throw new AuthServiceError('هذا الحساب غير نشط حاليًا.', 'ACCOUNT_INACTIVE');

      await logAuditEvent({ actorId: fbUser.uid, event: 'login_success', severity: 'info', resource: 'auth' });
      // في وضع Firebase، الجلسة تُدار بـ onAuthStateChanged — نُعيد session محلية فقط للتوافق
      return createSession(authUser, Boolean(payload.remember));
    } catch (error: unknown) {
      const code = (error as { code?: string }).code ?? '';
      if (code === 'auth/user-not-found' || code === 'auth/wrong-password' || code === 'auth/invalid-credential') {
        throw new AuthServiceError('البريد الإلكتروني أو كلمة المرور غير صحيحة.', 'INVALID_CREDENTIALS', {
          email: 'تحقق من البريد الإلكتروني.',
          password: 'تحقق من كلمة المرور.',
        });
      }
      if (code === 'auth/too-many-requests') {
        throw new AuthServiceError('تم إيقاف محاولات الدخول مؤقتًا. حاول لاحقًا.', 'RATE_LIMITED', {
          email: 'تم تجاوز عدد المحاولات المسموح.',
        });
      }
      if (error instanceof AuthServiceError) throw error;
      throw new AuthServiceError('تعذر تسجيل الدخول. حاول مجددًا.', 'UNKNOWN_ERROR');
    }
  }

  // ── وضع localStorage ──
  await delay();
  const fieldErrors = validateSignIn(payload);
  if (hasErrors(fieldErrors)) {
    throw new AuthServiceError('يرجى تصحيح بيانات تسجيل الدخول.', 'VALIDATION_ERROR', fieldErrors);
  }

  const email = normalizeEmail(payload.email);
  assertLoginAllowed(email);
  const user = await getUserByEmail(email);
  if (!user || user.passwordHash !== hashPassword(payload.password)) {
    registerFailedLogin(email);
    await logAuditEvent({ event: 'login_failed', severity: 'warning', resource: 'auth', metadata: { email: normalizeEmail(payload.email) } });
    throw new AuthServiceError('البريد الإلكتروني أو كلمة المرور غير صحيحة.', 'INVALID_CREDENTIALS', {
      email: 'تحقق من البريد الإلكتروني.',
      password: 'تحقق من كلمة المرور.',
    });
  }

  if (user.status !== 'active') {
    await logAuditEvent({ actorId: user.id, event: 'login_blocked_inactive_account', severity: 'warning', resource: 'auth' });
    throw new AuthServiceError('هذا الحساب غير نشط حاليًا.', 'ACCOUNT_INACTIVE');
  }

  clearFailedLogins(email);
  const session = createSession(omitPassword(user), Boolean(payload.remember));
  saveSession(session);
  await logAuditEvent({ actorId: user.id, event: 'login_success', severity: 'info', resource: 'auth' });
  return session;
}

export async function signUp(payload: SignUpPayload): Promise<AuthSession> {
  if (isFirebaseConfigured()) {
    const fieldErrors = validateSignUp(payload);
    if (hasErrors(fieldErrors)) {
      throw new AuthServiceError('يرجى تصحيح بيانات إنشاء الحساب.', 'VALIDATION_ERROR', fieldErrors);
    }

    try {
      const fbUser = await firebaseSignUp(payload.email.trim(), payload.password, payload.name.trim());

      const createdAt = nowIso();
      const newUser: StoredUser = {
        id: fbUser.uid,
        name: sanitizeText(payload.name, 120),
        email: normalizeEmail(payload.email),
        role: 'user',
        status: 'active',
        title: 'AI Tools Explorer',
        company: '',
        bio: '',
        createdAt,
        updatedAt: createdAt,
        preferences: { locale: 'ar', theme: 'system', newsletter: true, productUpdates: true },
        passwordHash: '', // لا تُخزَّن كلمة المرور محليًا — Firebase يُديرها
      };

      await createUser(newUser);
      await logAuditEvent({ actorId: fbUser.uid, event: 'account_created', severity: 'info', resource: 'auth' });
      return createSession(omitPassword(newUser), true);
    } catch (error: unknown) {
      const code = (error as { code?: string }).code ?? '';
      if (code === 'auth/email-already-in-use') {
        throw new AuthServiceError('يوجد حساب مسجل بهذا البريد الإلكتروني.', 'EMAIL_EXISTS', {
          email: 'استخدم بريدًا آخر أو سجل الدخول.',
        });
      }
      if (code === 'auth/weak-password') {
        throw new AuthServiceError('كلمة المرور ضعيفة جدًا.', 'VALIDATION_ERROR', {
          password: 'اختر كلمة مرور أقوى (8 أحرف على الأقل).',
        });
      }
      if (error instanceof AuthServiceError) throw error;
      throw new AuthServiceError('تعذر إنشاء الحساب. حاول مجددًا.', 'UNKNOWN_ERROR');
    }
  }

  // ── وضع localStorage ──
  await delay();
  const fieldErrors = validateSignUp(payload);
  if (hasErrors(fieldErrors)) {
    throw new AuthServiceError('يرجى تصحيح بيانات إنشاء الحساب.', 'VALIDATION_ERROR', fieldErrors);
  }

  const email = normalizeEmail(payload.email);
  const existingUser = await getUserByEmail(email);
  if (existingUser) {
    throw new AuthServiceError('يوجد حساب مسجل بهذا البريد الإلكتروني.', 'EMAIL_EXISTS', {
      email: 'استخدم بريدًا آخر أو سجل الدخول.',
    });
  }

  const createdAt = nowIso();
  const newUser: StoredUser = {
    id: createId('user'),
    name: sanitizeText(payload.name, 120),
    email,
    role: 'user',
    status: 'active',
    title: 'AI Tools Explorer',
    company: '',
    bio: '',
    createdAt,
    updatedAt: createdAt,
    preferences: { locale: 'ar', theme: 'system', newsletter: true, productUpdates: true },
    passwordHash: hashPassword(payload.password),
  };

  await createUser(newUser);
  await logAuditEvent({ actorId: newUser.id, event: 'account_created', severity: 'info', resource: 'auth' });
  const session = createSession(omitPassword(newUser), true);
  saveSession(session);
  return session;
}

export async function signOut() {
  if (isFirebaseConfigured()) {
    await firebaseSignOut();
    await logAuditEvent({ event: 'logout', severity: 'info', resource: 'auth' });
    return;
  }

  await delay(100);
  clearStoredSessions();
  await logAuditEvent({ event: 'logout', severity: 'info', resource: 'auth' });
}

export async function requestPasswordReset(payload: PasswordResetPayload) {
  if (isFirebaseConfigured()) {
    const email = normalizeEmail(payload.email);
    if (!email || !isValidEmail(email)) {
      throw new AuthServiceError('أدخل بريدًا إلكترونيًا صحيحًا.', 'VALIDATION_ERROR', {
        email: 'صيغة البريد الإلكتروني غير صحيحة.',
      });
    }
    // Firebase يُرسل البريد تلقائيًا — لا حاجة للتحقق من وجود المستخدم محليًا
    await firebaseSendPasswordReset(email);
    return { email };
  }

  await delay();
  const email = normalizeEmail(payload.email);
  if (!email || !isValidEmail(email)) {
    throw new AuthServiceError('أدخل بريدًا إلكترونيًا صحيحًا.', 'VALIDATION_ERROR', {
      email: 'صيغة البريد الإلكتروني غير صحيحة.',
    });
  }

  const user = await getUserByEmail(email);
  if (!user) {
    throw new AuthServiceError('لا يوجد حساب مسجل بهذا البريد الإلكتروني.', 'USER_NOT_FOUND', {
      email: 'تحقق من البريد الإلكتروني أو أنشئ حسابًا جديدًا.',
    });
  }

  const requests = safeJsonParse<ResetRequest[]>(window.localStorage.getItem(RESET_REQUESTS_KEY), []);
  window.localStorage.setItem(
    RESET_REQUESTS_KEY,
    JSON.stringify([...requests.slice(-9), { email, token: createId('reset'), createdAt: nowIso() }]),
  );

  return { email };
}

export async function updateProfile(userId: string, payload: ProfileUpdatePayload): Promise<AuthUser> {
  if (isFirebaseConfigured()) {
    const fieldErrors = validateProfile(payload);
    if (hasErrors(fieldErrors)) {
      throw new AuthServiceError('يرجى تصحيح بيانات الملف الشخصي.', 'VALIDATION_ERROR', fieldErrors);
    }

    const email = normalizeEmail(payload.email);
    // تحديث Firebase Auth displayName
    const fbUser = firebaseCurrentUser();
    if (fbUser) {
      await firebaseUpdateProfile(fbUser, { displayName: sanitizeText(payload.name, 120) });
    }

    // تحديث Firestore document
    const updatedUser = await updateUser(userId, {
      name: sanitizeText(payload.name, 120),
      email,
      title: sanitizeText(payload.title ?? '', 120),
      company: sanitizeText(payload.company ?? '', 120),
      bio: sanitizeText(payload.bio ?? '', 1000),
      avatarUrl: sanitizeOptionalUrl(payload.avatarUrl),
    });

    return omitPassword(updatedUser);
  }

  await delay();
  const fieldErrors = validateProfile(payload);
  if (hasErrors(fieldErrors)) {
    throw new AuthServiceError('يرجى تصحيح بيانات الملف الشخصي.', 'VALIDATION_ERROR', fieldErrors);
  }

  const email = normalizeEmail(payload.email);
  const duplicateUser = await getUserByEmail(email);
  if (duplicateUser && duplicateUser.id !== userId) {
    throw new AuthServiceError('هذا البريد مستخدم في حساب آخر.', 'EMAIL_EXISTS', { email: 'استخدم بريدًا آخر.' });
  }

  const updatedUser = await updateUser(userId, {
    name: sanitizeText(payload.name, 120),
    email,
    title: sanitizeText(payload.title ?? '', 120),
    company: sanitizeText(payload.company ?? '', 120),
    bio: sanitizeText(payload.bio ?? '', 1000),
    avatarUrl: sanitizeOptionalUrl(payload.avatarUrl),
  });

  const session = await getCurrentSession();
  if (session?.user.id === userId) saveSession({ ...session, user: omitPassword(updatedUser) });
  return omitPassword(updatedUser);
}

export async function changePassword(userId: string, payload: PasswordChangePayload) {
  if (isFirebaseConfigured()) {
    const fieldErrors = validatePasswordChange(payload);
    if (hasErrors(fieldErrors)) {
      throw new AuthServiceError('يرجى تصحيح بيانات كلمة المرور.', 'VALIDATION_ERROR', fieldErrors);
    }

    const fbUser = firebaseCurrentUser();
    if (!fbUser) throw new AuthServiceError('تعذر العثور على المستخدم.', 'USER_NOT_FOUND');

    try {
      await firebaseChangePassword(fbUser, payload.currentPassword, payload.newPassword);
      return { changed: true };
    } catch (error: unknown) {
      const code = (error as { code?: string }).code ?? '';
      if (code === 'auth/wrong-password' || code === 'auth/invalid-credential') {
        throw new AuthServiceError('كلمة المرور الحالية غير صحيحة.', 'INVALID_CURRENT_PASSWORD', {
          currentPassword: 'كلمة المرور الحالية غير صحيحة.',
        });
      }
      throw new AuthServiceError('تعذر تغيير كلمة المرور.', 'UNKNOWN_ERROR');
    }
  }

  await delay();
  const fieldErrors = validatePasswordChange(payload);
  if (hasErrors(fieldErrors)) {
    throw new AuthServiceError('يرجى تصحيح بيانات كلمة المرور.', 'VALIDATION_ERROR', fieldErrors);
  }

  const user = await getUserById(userId);
  if (!user) throw new AuthServiceError('تعذر العثور على المستخدم.', 'USER_NOT_FOUND');
  if (user.passwordHash !== hashPassword(payload.currentPassword)) {
    throw new AuthServiceError('كلمة المرور الحالية غير صحيحة.', 'INVALID_CURRENT_PASSWORD', {
      currentPassword: 'كلمة المرور الحالية غير صحيحة.',
    });
  }

  await updateUser(userId, { passwordHash: hashPassword(payload.newPassword) });
  return { changed: true };
}

export async function updateAccountSettings(userId: string, payload: AccountSettingsPayload): Promise<AuthUser> {
  await delay(180);
  const user = await getUserById(userId);
  if (!user) throw new AuthServiceError('تعذر العثور على المستخدم.', 'USER_NOT_FOUND');

  const updatedUser = await updateUser(userId, {
    preferences: {
      ...user.preferences,
      newsletter: payload.newsletter,
      productUpdates: payload.productUpdates,
    },
  });

  if (!isFirebaseConfigured()) {
    const session = await getCurrentSession();
    if (session?.user.id === userId) saveSession({ ...session, user: omitPassword(updatedUser) });
  }
  return omitPassword(updatedUser);
}

export function userHasRole(user: AuthUser | null, allowedRoles?: UserRole[]) {
  if (!allowedRoles?.length) return Boolean(user);
  return Boolean(user && allowedRoles.includes(user.role));
}
