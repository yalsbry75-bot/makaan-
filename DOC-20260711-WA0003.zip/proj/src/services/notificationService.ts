import type { NotificationRecord } from '@/types/database';
import { createRecord, getCollection, updateRecord } from '@/services/databaseService';
import { createId, nowIso } from '@/utils/security';

export async function getUserNotifications(userId: string) {
  const notifications = await getCollection('notifications');
  return notifications.filter((notification) => notification.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function createNotification(payload: Omit<NotificationRecord, 'id' | 'createdAt' | 'updatedAt' | 'read'>) {
  const createdAt = nowIso();
  return createRecord('notifications', {
    ...payload,
    id: createId('notification'),
    read: false,
    createdAt,
    updatedAt: createdAt,
  });
}

export async function markNotificationAsRead(notificationId: string) {
  return updateRecord('notifications', notificationId, { read: true });
}
