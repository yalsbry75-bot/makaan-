import type { ReportRecord } from '@/types/database';
import { createRecord, getCollection, updateRecord } from '@/services/databaseService';
import { createId, nowIso, sanitizeText } from '@/utils/security';

export async function getReports() {
  return getCollection('reports');
}

export async function createReport(payload: Omit<ReportRecord, 'id' | 'createdAt' | 'updatedAt' | 'status'>) {
  const createdAt = nowIso();
  return createRecord('reports', {
    ...payload,
    reason: sanitizeText(payload.reason, 1000),
    id: createId('report'),
    status: 'open',
    createdAt,
    updatedAt: createdAt,
  });
}

export async function updateReportStatus(reportId: string, status: ReportRecord['status']) {
  return updateRecord('reports', reportId, { status });
}
