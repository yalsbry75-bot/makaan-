import type { PlatformSettingsRecord } from '@/types/database';
import { getCollection, updateRecord } from '@/services/databaseService';

export async function getPlatformSettings() {
  return getCollection('settings');
}

export async function updatePlatformSetting(settingId: string, value: PlatformSettingsRecord['value']) {
  return updateRecord('settings', settingId, { value });
}
