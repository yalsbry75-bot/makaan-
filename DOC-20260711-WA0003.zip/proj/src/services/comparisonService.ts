import type { ComparisonRecord } from '@/types/database';
import { createRecord, getCollection } from '@/services/databaseService';
import { getComparisonItems } from '@/services/repositories/catalogRepository';
import { createId, nowIso } from '@/utils/security';

export async function getDefaultComparisonItems() {
  return getComparisonItems();
}

export async function getUserComparisons(userId: string) {
  const comparisons = await getCollection('comparisons');
  return comparisons.filter((comparison) => comparison.userId === userId);
}

export async function saveComparison(userId: string, name: string, toolIds: string[]) {
  const createdAt = nowIso();
  const record: ComparisonRecord = {
    id: createId('comparison'),
    userId,
    name: name.trim() || 'AI tools comparison',
    toolIds: [...new Set(toolIds)].slice(0, 4),
    createdAt,
    updatedAt: createdAt,
  };
  return createRecord('comparisons', record);
}
