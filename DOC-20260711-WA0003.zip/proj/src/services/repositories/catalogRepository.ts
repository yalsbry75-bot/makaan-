import type { AITool, Pricing, ToolCategory, ToolPlatform, ToolVisibilityStatus } from '@/types';
import type { ToolQueryParams, ToolSearchResult } from '@/types/database';
import { comparisonItems } from '@/constants/catalogSeed';
import { createRecord, deleteRecord, getCollection, setCollection, updateRecord } from '@/services/databaseService';
import { makeRecordId } from '@/data/seedDatabase';
import { normalizeCategories, normalizeTool, slugifyToolName } from '@/utils/toolNormalization';
import { editDistance, normalizeSearchText } from '@/utils/searchUtils';
import { nowIso } from '@/utils/security';

function normalize(value: string) {
  return normalizeSearchText(value);
}

function parseUsers(users: string) {
  const normalized = users.toUpperCase().replace(/,/g, '').trim();
  const multiplier = normalized.endsWith('M') ? 1_000_000 : normalized.endsWith('K') ? 1_000 : 1;
  const value = Number.parseFloat(normalized.replace(/[^\d.]/g, ''));
  return Number.isFinite(value) ? value * multiplier : 0;
}

function isPricing(value: string): value is Pricing {
  return ['free', 'freemium', 'paid', 'enterprise'].includes(value);
}

function isPlatform(value: string): value is ToolPlatform {
  return ['web', 'android', 'ios', 'api', 'desktop'].includes(value);
}

function isVisibility(value: string): value is ToolVisibilityStatus {
  return ['active', 'hidden'].includes(value);
}

function tokenize(value: string) {
  return normalize(value).split(/\s+/).filter((token) => token.length >= 2);
}

function toolSearchFields(tool: AITool) {
  return [
    tool.name,
    tool.taglineAr,
    tool.taglineEn,
    tool.descriptionAr,
    tool.descriptionEn,
    tool.fullDescriptionAr ?? '',
    tool.fullDescriptionEn ?? '',
    tool.categorySlug,
    tool.pricing,
    ...(tool.platform ?? []),
    ...tool.tags,
    ...tool.featuresAr,
    ...tool.featuresEn,
    ...tool.useCasesAr,
    ...tool.useCasesEn,
    ...tool.integrations,
  ];
}

function getRelevanceScore(tool: AITool, rawSearch: string) {
  const search = normalize(rawSearch);
  if (!search) return 1;

  const name = normalize(tool.name);
  const tags = tool.tags.map(normalize);
  const category = normalize(tool.categorySlug);
  const pricing = normalize(tool.pricing);
  const platforms = (tool.platform ?? []).map(normalize);
  const description = normalize([tool.taglineAr, tool.taglineEn, tool.descriptionAr, tool.descriptionEn, tool.fullDescriptionAr ?? '', tool.fullDescriptionEn ?? ''].join(' '));
  const features = normalize([...tool.featuresAr, ...tool.featuresEn, ...tool.useCasesAr, ...tool.useCasesEn].join(' '));
  const content = normalize(toolSearchFields(tool).join(' '));
  const searchTokens = tokenize(search);
  const contentTokens = new Set(tokenize(content));

  let score = 0;
  if (name === search) score += 160;
  if (name.startsWith(search)) score += 120;
  if (name.includes(search)) score += 95;
  if (tags.some((tag) => tag === search)) score += 80;
  if (tags.some((tag) => tag.includes(search) || search.includes(tag))) score += 60;
  if (category === search || category.includes(search)) score += 50;
  if (pricing === search || platforms.includes(search)) score += 35;
  if (description.includes(search)) score += 30;
  if (features.includes(search)) score += 22;
  if (content.includes(search)) score += 12;

  searchTokens.forEach((token) => {
    if (name.includes(token)) score += 28;
    if (tags.some((tag) => tag.includes(token))) score += 24;
    if (category.includes(token)) score += 18;
    if (description.includes(token)) score += 12;
    if (features.includes(token)) score += 8;
    if (contentTokens.has(token)) score += 6;
    if (token.length >= 4) {
      const fuzzyMatch = [...contentTokens].some((contentToken) => {
        if (Math.abs(contentToken.length - token.length) > 2) return false;
        return editDistance(contentToken, token) <= 2;
      });
      if (fuzzyMatch) score += 7;
    }
  });

  return score;
}

/**
 * Short-lived in-memory cache for the full tools+reviews scan that backs
 * every list/search/filter call. Firestore has no native full-text search,
 * so relevance search stays client-side over this cached snapshot — the
 * cache just prevents re-fetching both collections on every keystroke or
 * rapid filter change (typeahead, sort toggles, pagination).
 */
const NORMALIZED_TOOLS_CACHE_TTL_MS = 15_000;
let normalizedToolsCache: { value: AITool[]; expiresAt: number } | null = null;
let normalizedToolsInFlight: Promise<AITool[]> | null = null;

export function invalidateCatalogCache() {
  normalizedToolsCache = null;
  normalizedToolsInFlight = null;
}

async function getNormalizedTools() {
  const now = Date.now();
  if (normalizedToolsCache && normalizedToolsCache.expiresAt > now) {
    return normalizedToolsCache.value;
  }
  if (normalizedToolsInFlight) return normalizedToolsInFlight;

  normalizedToolsInFlight = (async () => {
    // Only approved reviews should influence public ratings — matches the
    // Firestore security rule (`reviews` read: approved | own | admin) so
    // rating aggregation is correct even when the rule silently drops
    // non-approved documents from an unfiltered collection read.
    const [tools, reviews] = await Promise.all([getCollection('tools'), getCollection('reviews')]);
    const approvedReviews = reviews.filter((review) => review.status === 'approved');
    const normalizedTools = tools.map((tool) => normalizeTool(tool, approvedReviews));
    normalizedToolsCache = { value: normalizedTools, expiresAt: Date.now() + NORMALIZED_TOOLS_CACHE_TTL_MS };
    return normalizedTools;
  })();

  try {
    return await normalizedToolsInFlight;
  } finally {
    normalizedToolsInFlight = null;
  }
}

/**
 * Recomputes category stats (tool counts, etc.) and persists them.
 * IMPORTANT: this performs a Firestore write and is only allowed for admins
 * per firestore.rules (`categories` write: admin-only). It must only run
 * after an authenticated admin mutation (create/update/delete tool) — never
 * on a plain read path, or anonymous/regular users will hit permission-denied
 * errors just from loading the categories list.
 */
async function persistNormalizedCategories(tools: AITool[]) {
  const categories = await getCollection('categories');
  const normalized = normalizeCategories(categories, tools);
  try {
    await setCollection('categories', normalized);
  } catch (error) {
    // Best-effort cache refresh — surfaced stats will simply lag until the
    // next successful admin mutation instead of breaking the read path.
    console.warn('Skipped persisting recomputed categories:', error);
  }
  return normalized;
}

/** Read-only category list — computes live stats in memory, never writes. */
export async function listCategories() {
  const [categories, tools] = await Promise.all([getCollection('categories'), getNormalizedTools()]);
  return normalizeCategories(categories, tools);
}

export function filterAndSortTools(tools: AITool[], params: ToolQueryParams = {}) {
  const search = normalize(params.search ?? params.keyword ?? '');
  const category = params.category ?? 'all';
  const pricing = params.pricing ?? 'all';
  const platform = params.platform ?? 'all';
  const tag = normalize(params.tag ?? '');
  const status = params.status ?? 'active';
  const tags = params.tags?.map(normalize).filter(Boolean) ?? [];
  const scoredTools = new Map<string, number>();

  const filtered = tools.filter((tool) => {
    const visibility = tool.visibilityStatus ?? 'active';
    const relevanceScore = getRelevanceScore(tool, search);
    scoredTools.set(tool.id, relevanceScore);

    const matchesSearch = !search || relevanceScore > 0;
    const matchesCategory = category === 'all' || tool.categorySlug === category;
    const matchesPricing = pricing === 'all' || (typeof pricing === 'string' && isPricing(pricing) && tool.pricing === pricing);
    const matchesPlatform = platform === 'all' || (typeof platform === 'string' && isPlatform(platform) && (tool.platform ?? []).includes(platform));
    const matchesTag = !tag || tool.tags.some((toolTag) => normalize(toolTag).includes(tag));
    const matchesTags = !tags.length || tags.every((selectedTag) => tool.tags.some((toolTag) => normalize(toolTag).includes(selectedTag)));
    const matchesStatus = status === 'all' || (typeof status === 'string' && isVisibility(status) && visibility === status);
    const matchesFeatured = typeof params.featured === 'boolean' ? Boolean(tool.featured) === params.featured : true;
    const matchesRating = typeof params.minRating === 'number' ? tool.rating >= params.minRating : true;

    return matchesSearch && matchesCategory && matchesPricing && matchesPlatform && matchesTag && matchesTags && matchesStatus && matchesFeatured && matchesRating;
  });

  return [...filtered].sort((a, b) => {
    if (search && (params.sort === 'relevance' || !params.sort)) return (scoredTools.get(b.id) ?? 0) - (scoredTools.get(a.id) ?? 0) || b.rating - a.rating;
    if (params.sort === 'newest') return new Date(b.addedAt ?? b.lastUpdatedAt ?? b.launchYear).getTime() - new Date(a.addedAt ?? a.lastUpdatedAt ?? a.launchYear).getTime();
    if (params.sort === 'most-used') return parseUsers(b.users) - parseUsers(a.users);
    if (params.sort === 'name') return a.name.localeCompare(b.name);
    if (params.sort === 'featured') return Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || b.rating - a.rating;
    return b.rating - a.rating;
  });
}

export async function listTools(params: ToolQueryParams = {}) {
  const sorted = filterAndSortTools(await getNormalizedTools(), params);
  return typeof params.limit === 'number' ? sorted.slice(0, params.limit) : sorted;
}

export async function searchToolsPaginated(params: ToolQueryParams = {}): Promise<ToolSearchResult> {
  const page = Math.max(1, params.page ?? 1);
  const pageSize = Math.max(1, params.pageSize ?? 9);
  const sorted = filterAndSortTools(await getNormalizedTools(), { ...params, sort: params.sort ?? 'relevance' });
  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  return {
    items: sorted.slice((page - 1) * pageSize, page * pageSize),
    total: sorted.length,
    page,
    pageSize,
    totalPages,
  };
}

export async function getFeaturedTools(limit = 6) {
  return listTools({ featured: true, sort: 'featured', limit });
}

export async function getLatestTools(limit = 6) {
  return listTools({ sort: 'newest', limit });
}

export async function getMostUsedTools(limit = 6) {
  return listTools({ sort: 'most-used', limit });
}

export async function getToolsByCategory(categorySlug: string, limit?: number) {
  return listTools({ category: categorySlug, limit });
}

export async function getToolBySlug(slug: string | undefined) {
  if (!slug) return null;
  const tools = await getNormalizedTools();
  return tools.find((tool) => tool.slug === slug) ?? null;
}

export async function getToolById(toolId: string) {
  const tools = await getNormalizedTools();
  return tools.find((tool) => tool.id === toolId) ?? null;
}

export async function getToolsByIds(toolIds: string[]) {
  const tools = await getNormalizedTools();
  const order = new Map(toolIds.map((toolId, index) => [toolId, index]));
  return tools.filter((tool) => order.has(tool.id)).sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0));
}

export async function getRelatedTools(tool: AITool, limit = 3) {
  const tools = await getNormalizedTools();
  const toolTagSet = new Set(tool.tags.map(normalize));
  return filterAndSortTools(tools, { status: 'active' })
    .filter((item) => item.id !== tool.id)
    .sort((a, b) => {
      const score = (item: AITool) => Number(item.categorySlug === tool.categorySlug) * 5 + item.tags.filter((tag) => toolTagSet.has(normalize(tag))).length * 2 + item.rating;
      return score(b) - score(a);
    })
    .slice(0, limit);
}

export async function createToolRecord(payload: Omit<AITool, 'id' | 'slug' | 'addedAt' | 'lastUpdatedAt' | 'reviewsCount'> & { slug?: string }) {
  const records = await getCollection('tools');
  const timestamp = nowIso();
  const slug = payload.slug?.trim() || slugifyToolName(payload.name);
  if (records.some((tool) => tool.slug === slug)) throw new Error('A tool with the same slug already exists.');
  const record = normalizeTool({
    ...payload,
    id: makeRecordId('tool'),
    slug,
    reviewsCount: 0,
    addedAt: timestamp,
    lastUpdatedAt: timestamp,
  });
  await createRecord('tools', record);
  invalidateCatalogCache();
  await persistNormalizedCategories(await getNormalizedTools());
  return record;
}

export async function updateToolRecord(toolId: string, patch: Partial<AITool>) {
  const timestamp = nowIso();
  const updated = await updateRecord('tools', toolId, { ...patch, lastUpdatedAt: timestamp });
  const normalized = normalizeTool(updated);
  await updateRecord('tools', toolId, normalized);
  invalidateCatalogCache();
  await persistNormalizedCategories(await getNormalizedTools());
  return normalized;
}

export async function deleteToolRecord(toolId: string) {
  const result = await deleteRecord('tools', toolId);
  const favorites = await getCollection('favorites');
  await setCollection('favorites', favorites.filter((favorite) => favorite.toolId !== toolId));
  const reviews = await getCollection('reviews');
  await setCollection('reviews', reviews.filter((review) => review.toolId !== toolId));
  invalidateCatalogCache();
  await persistNormalizedCategories(await getNormalizedTools());
  return result;
}

export async function createCategoryRecord(payload: Omit<ToolCategory, 'id' | 'toolsCount' | 'createdAt' | 'updatedAt'> & { id?: string; toolsCount?: number }) {
  const categories = await getCollection('categories');
  if (categories.some((category) => category.slug === payload.slug)) throw new Error('A category with the same slug already exists.');
  const timestamp = nowIso();
  const record: ToolCategory = {
    ...payload,
    id: payload.id ?? makeRecordId('cat'),
    toolsCount: payload.toolsCount ?? 0,
    status: payload.status ?? 'active',
    createdAt: timestamp,
    updatedAt: timestamp,
  };
  await createRecord('categories', record);
  return record;
}

export async function updateCategoryRecord(categoryId: string, patch: Partial<ToolCategory>) {
  return updateRecord('categories', categoryId, patch);
}

export async function deleteCategoryRecord(categoryId: string) {
  const categories = await getCollection('categories');
  const target = categories.find((category) => category.id === categoryId);
  if (!target) return { deleted: false };
  const tools = await getCollection('tools');
  if (tools.some((tool) => tool.categorySlug === target.slug)) {
    throw new Error('Cannot delete a category that still contains tools. Move or delete its tools first.');
  }
  return deleteRecord('categories', categoryId);
}

export async function getComparisonItems() {
  const tools = await getNormalizedTools();
  return comparisonItems.map((item) => {
    const hydratedTool = tools.find((tool) => tool.id === item.id);
    return hydratedTool ? { ...item, pricing: hydratedTool.pricing, rating: hydratedTool.rating, categorySlug: hydratedTool.categorySlug, tags: hydratedTool.tags } : item;
  });
}
