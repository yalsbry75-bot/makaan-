import type { StoredUser } from '@/types/auth';
import { createRecord, findRecord, getCollection, setCollection, updateRecord } from '@/services/databaseService';
import { normalizeEmail } from '@/utils/security';

export async function listUsers() {
  return getCollection('users');
}

export async function getUserById(userId: string) {
  return findRecord('users', (user) => user.id === userId);
}

export async function getUserByEmail(email: string) {
  const normalizedEmail = normalizeEmail(email);
  return findRecord('users', (user) => user.email === normalizedEmail);
}

export async function createUser(user: StoredUser) {
  return createRecord('users', user);
}

export async function updateUser(userId: string, patch: Partial<StoredUser>) {
  return updateRecord('users', userId, patch);
}

export async function replaceUsers(users: StoredUser[]) {
  return setCollection('users', users);
}
