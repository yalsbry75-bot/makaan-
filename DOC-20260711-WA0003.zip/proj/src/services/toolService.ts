import type { AITool, ToolCategory } from '@/types';
import type { ToolQueryParams } from '@/types/database';
import {
  createCategoryRecord,
  createToolRecord,
  deleteCategoryRecord,
  deleteToolRecord,
  getComparisonItems,
  getFeaturedTools as repositoryGetFeaturedTools,
  getLatestTools as repositoryGetLatestTools,
  getMostUsedTools as repositoryGetMostUsedTools,
  getRelatedTools,
  getToolById,
  getToolBySlug,
  getToolsByCategory,
  getToolsByIds,
  listCategories,
  listTools,
  searchToolsPaginated,
  updateCategoryRecord,
  updateToolRecord,
} from '@/services/repositories/catalogRepository';

export async function getTools(params: ToolQueryParams = {}) {
  return listTools(params);
}

export async function searchTools(params: ToolQueryParams = {}) {
  return listTools(params);
}

export async function searchToolsAdvanced(params: ToolQueryParams = {}) {
  return searchToolsPaginated(params);
}

export async function getFeaturedTools(limit?: number) {
  return repositoryGetFeaturedTools(limit);
}

export async function getLatestTools(limit?: number) {
  return repositoryGetLatestTools(limit);
}

export async function getMostUsedTools(limit?: number) {
  return repositoryGetMostUsedTools(limit);
}

export async function getTool(slug: string | undefined) {
  return getToolBySlug(slug);
}

export async function createTool(payload: Parameters<typeof createToolRecord>[0]) {
  return createToolRecord(payload);
}

export async function updateTool(toolId: string, patch: Partial<AITool>) {
  return updateToolRecord(toolId, patch);
}

export async function deleteTool(toolId: string) {
  return deleteToolRecord(toolId);
}

export async function createCategory(payload: Parameters<typeof createCategoryRecord>[0]) {
  return createCategoryRecord(payload);
}

export async function updateCategory(categoryId: string, patch: Partial<ToolCategory>) {
  return updateCategoryRecord(categoryId, patch);
}

export async function deleteCategory(categoryId: string) {
  return deleteCategoryRecord(categoryId);
}

export { getToolById, getToolBySlug, getToolsByIds, getRelatedTools, getToolsByCategory, getComparisonItems };

export async function getCategories() {
  return listCategories();
}
