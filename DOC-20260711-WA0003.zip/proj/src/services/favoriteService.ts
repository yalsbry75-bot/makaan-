import type { AITool } from '@/types';
import type { FavoriteRecord } from '@/types/database';
import { createRecord, deleteRecord, getCollection } from '@/services/databaseService';
import { getToolsByIds } from '@/services/repositories/catalogRepository';
import { createId, nowIso } from '@/utils/security';

export async function getUserFavorites(userId: string): Promise<AITool[]> {
  const favorites = await getCollection('favorites');
  const userFavoriteToolIds = favorites.filter((favorite) => favorite.userId === userId).map((favorite) => favorite.toolId);
  return getToolsByIds(userFavoriteToolIds);
}

export async function getUserFavoriteIds(userId: string) {
  const favorites = await getCollection('favorites');
  return new Set(favorites.filter((favorite) => favorite.userId === userId).map((favorite) => favorite.toolId));
}

export async function isToolFavorite(userId: string, toolId: string) {
  const favorites = await getCollection('favorites');
  return favorites.some((favorite) => favorite.userId === userId && favorite.toolId === toolId);
}

export async function toggleFavorite(userId: string, toolId: string) {
  const favorites = await getCollection('favorites');
  const existing = favorites.find((favorite) => favorite.userId === userId && favorite.toolId === toolId);
  if (existing) {
    await deleteRecord('favorites', existing.id);
    return { favorite: false };
  }

  const createdAt = nowIso();
  const record: FavoriteRecord = {
    id: createId('favorite'),
    userId,
    toolId,
    createdAt,
    updatedAt: createdAt,
  };
  await createRecord('favorites', record);
  return { favorite: true };
}
