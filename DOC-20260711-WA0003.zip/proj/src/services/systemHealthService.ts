import { getAdminOverviewStats } from '@/services/adminService';
import { databaseMetadata, getCollection } from '@/services/databaseService';
import { getRecentAuditLogs } from '@/services/securityService';
import type { AuditLogRecord } from '@/types/database';
import { productionReadinessChecklist, productionRelease } from '@/config/production';

export type SystemHealthStatus = 'healthy' | 'attention' | 'critical';

export type SystemHealthCheck = {
  id: string;
  labelAr: string;
  labelEn: string;
  descriptionAr: string;
  descriptionEn: string;
  status: SystemHealthStatus;
  score: number;
};

export type SystemHealthSummary = {
  score: number;
  status: SystemHealthStatus;
  checks: SystemHealthCheck[];
  auditLogs: AuditLogRecord[];
  database: ReturnType<typeof databaseMetadata>;
  counters: {
    users: number;
    tools: number;
    categories: number;
    reviews: number;
    pendingReviews: number;
    openReports: number;
    auditLogs: number;
  };
};

function statusFromScore(score: number): SystemHealthStatus {
  if (score >= 85) return 'healthy';
  if (score >= 65) return 'attention';
  return 'critical';
}

function createCheck(check: Omit<SystemHealthCheck, 'status'>): SystemHealthCheck {
  return { ...check, status: statusFromScore(check.score) };
}

export async function getSystemHealthSummary(): Promise<SystemHealthSummary> {
  const [overview, auditLogs, settings, reports, reviews] = await Promise.all([
    getAdminOverviewStats(),
    getRecentAuditLogs(30),
    getCollection('settings'),
    getCollection('reports'),
    getCollection('reviews'),
  ]);

  const criticalLogs = auditLogs.filter((log) => log.severity === 'critical').length;
  const warningLogs = auditLogs.filter((log) => log.severity === 'warning').length;
  const unresolvedReports = reports.filter((report) => report.status !== 'resolved').length;
  const pendingReviews = reviews.filter((review) => review.status === 'pending').length;
  const hasSeoSettings = settings.some((setting) => setting.key === 'seoTitle') && settings.some((setting) => setting.key === 'seoDescription');
  const hasLanguageSettings = settings.some((setting) => setting.key === 'supportedLanguages');
  const activeToolRatio = overview.toolsCount ? Math.round((overview.activeToolsCount / overview.toolsCount) * 100) : 100;

  const checks = [
    createCheck({
      id: 'security-audit',
      labelAr: 'سجل الأمان',
      labelEn: 'Security audit log',
      descriptionAr: criticalLogs ? 'يوجد حدث أمني حرج يحتاج مراجعة.' : warningLogs ? 'يوجد تنبيهات أمنية متوسطة للمراجعة.' : 'لا توجد أحداث أمنية حرجة في السجل الأخير.',
      descriptionEn: criticalLogs ? 'A critical security event needs review.' : warningLogs ? 'Recent warning events should be reviewed.' : 'No critical security events in the recent audit trail.',
      score: criticalLogs ? 45 : warningLogs ? 78 : 96,
    }),
    createCheck({
      id: 'content-readiness',
      labelAr: 'جاهزية المحتوى',
      labelEn: 'Content readiness',
      descriptionAr: `توجد ${overview.activeToolsCount} أداة نشطة من أصل ${overview.toolsCount}.`,
      descriptionEn: `${overview.activeToolsCount} active tools out of ${overview.toolsCount}.`,
      score: Math.min(100, Math.max(60, activeToolRatio)),
    }),
    createCheck({
      id: 'moderation-queue',
      labelAr: 'قائمة المراجعة',
      labelEn: 'Moderation queue',
      descriptionAr: `${pendingReviews} مراجعة معلقة و ${unresolvedReports} بلاغ غير مغلق.`,
      descriptionEn: `${pendingReviews} pending reviews and ${unresolvedReports} unresolved reports.`,
      score: Math.max(55, 100 - pendingReviews * 4 - unresolvedReports * 8),
    }),
    createCheck({
      id: 'seo-pwa',
      labelAr: 'SEO وPWA',
      labelEn: 'SEO and PWA',
      descriptionAr: hasSeoSettings && hasLanguageSettings ? 'إعدادات SEO واللغات الأساسية متاحة.' : 'بعض إعدادات SEO أو اللغات تحتاج استكمالًا.',
      descriptionEn: hasSeoSettings && hasLanguageSettings ? 'Core SEO and language settings are available.' : 'Some SEO or language settings need completion.',
      score: hasSeoSettings && hasLanguageSettings ? 95 : 70,
    }),
    createCheck({
      id: 'production-readiness',
      labelAr: 'جاهزية الإنتاج',
      labelEn: 'Production readiness',
      descriptionAr: `إصدار ${productionRelease.version} يحتوي على ${productionReadinessChecklist.filter((item) => item.required).length} متطلب إنتاج أساسي.`,
      descriptionEn: `Release ${productionRelease.version} includes ${productionReadinessChecklist.filter((item) => item.required).length} required production controls.`,
      score: 96,
    }),
    createCheck({
      id: 'data-integrity',
      labelAr: 'تكامل البيانات',
      labelEn: 'Data integrity',
      descriptionAr: 'المجموعات الأساسية متاحة من طبقة قاعدة البيانات الموحدة.',
      descriptionEn: 'Core collections are available through the unified database layer.',
      score: 94,
    }),
  ];

  const score = Math.round(checks.reduce((total, check) => total + check.score, 0) / checks.length);

  return {
    score,
    status: statusFromScore(score),
    checks,
    auditLogs,
    database: databaseMetadata(),
    counters: {
      users: overview.usersCount,
      tools: overview.toolsCount,
      categories: overview.categoriesCount,
      reviews: overview.reviewsCount,
      pendingReviews: overview.pendingReviewsCount,
      openReports: overview.openReportsCount,
      auditLogs: auditLogs.length,
    },
  };
}
