import type { ContactMessageRecord } from '@/types/database';
import { createRecord, getCollection, updateRecord } from '@/services/databaseService';
import { isValidEmail } from '@/utils/authValidation';
import { createId, nowIso, normalizeEmail, sanitizeText } from '@/utils/security';

export type ContactPayload = {
  name: string;
  email: string;
  message: string;
};

export class ContactServiceError extends Error {
  fieldErrors: Partial<Record<keyof ContactPayload, string>>;

  constructor(message: string, fieldErrors: Partial<Record<keyof ContactPayload, string>> = {}) {
    super(message);
    this.name = 'ContactServiceError';
    this.fieldErrors = fieldErrors;
  }
}

function validateContact(payload: ContactPayload) {
  const errors: ContactServiceError['fieldErrors'] = {};
  if (payload.name.trim().length < 3) errors.name = 'الاسم يجب أن يحتوي على 3 أحرف على الأقل.';
  if (!isValidEmail(payload.email)) errors.email = 'صيغة البريد الإلكتروني غير صحيحة.';
  if (payload.message.trim().length < 10) errors.message = 'الرسالة يجب أن تحتوي على 10 أحرف على الأقل.';
  return errors;
}

export async function submitContactMessage(payload: ContactPayload) {
  const errors = validateContact(payload);
  if (Object.keys(errors).length) throw new ContactServiceError('يرجى تصحيح بيانات نموذج التواصل.', errors);
  const createdAt = nowIso();
  const record: ContactMessageRecord = {
    id: createId('contact'),
    name: sanitizeText(payload.name, 120),
    email: normalizeEmail(payload.email),
    message: sanitizeText(payload.message, 2000),
    status: 'new',
    createdAt,
    updatedAt: createdAt,
  };
  return createRecord('contactMessages', record);
}

export async function getContactMessages() {
  return getCollection('contactMessages');
}

export async function updateContactMessageStatus(messageId: string, status: ContactMessageRecord['status']) {
  return updateRecord('contactMessages', messageId, { status });
}
