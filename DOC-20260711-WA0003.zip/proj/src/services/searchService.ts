import type { AITool, Pricing, ToolCategory, ToolPlatform } from '@/types';
import { getCategories, getTools } from '@/services/toolService';
import { editDistance, normalizeSearchText } from '@/utils/searchUtils';

export type SearchSuggestion = {
  id: string;
  label: string;
  type: 'tool' | 'category' | 'tag' | 'pricing' | 'platform' | 'keyword';
  value: string;
  href: string;
};

export type SmartSearchSnapshot = {
  suggestions: SearchSuggestion[];
  correctedQuery: string | null;
};

const pricingOptions: Array<{ value: Pricing; labels: string[] }> = [
  { value: 'free', labels: ['free', 'مجاني'] },
  { value: 'freemium', labels: ['freemium', 'فريميوم', 'مجاني ومدفوع'] },
  { value: 'paid', labels: ['paid', 'مدفوع'] },
  { value: 'enterprise', labels: ['enterprise', 'مؤسسات', 'شركات'] },
];

const suggestionCache = new Map<string, { expiresAt: number; value: SmartSearchSnapshot }>();
const CACHE_TTL_MS = 30_000;

const platformOptions: Array<{ value: ToolPlatform; labels: string[] }> = [
  { value: 'web', labels: ['web', 'ويب'] },
  { value: 'android', labels: ['android', 'أندرويد'] },
  { value: 'ios', labels: ['ios', 'آيفون', 'ايفون'] },
  { value: 'api', labels: ['api', 'واجهة برمجية'] },
  { value: 'desktop', labels: ['desktop', 'سطح المكتب'] },
];

function tokenMatchesQuery(token: string, query: string) {
  const normalizedToken = normalizeSearchText(token);
  const normalizedQuery = normalizeSearchText(query);
  if (!normalizedQuery) return false;
  if (normalizedToken.includes(normalizedQuery) || normalizedQuery.includes(normalizedToken)) return true;
  return normalizedQuery.length >= 4 && editDistance(normalizedToken, normalizedQuery) <= 2;
}

function makeToolSuggestion(tool: AITool): SearchSuggestion {
  return {
    id: `tool-${tool.id}`,
    label: tool.name,
    type: 'tool',
    value: tool.name,
    href: `/tools/${tool.slug}`,
  };
}

function makeCategorySuggestion(category: ToolCategory): SearchSuggestion {
  return {
    id: `category-${category.id}`,
    label: `${category.nameAr} / ${category.nameEn}`,
    type: 'category',
    value: category.slug,
    href: `/search/results?category=${encodeURIComponent(category.slug)}`,
  };
}

function closestDictionaryTerm(query: string, dictionary: string[]) {
  const normalizedQuery = normalizeSearchText(query);
  if (normalizedQuery.length < 3) return null;
  const allowed = normalizedQuery.length <= 5 ? 1 : 2;
  const best = dictionary.reduce<{ term: string; distance: number } | null>((currentBest, term) => {
    const distance = editDistance(normalizedQuery, normalizeSearchText(term));
    if (distance > allowed) return currentBest;
    if (!currentBest || distance < currentBest.distance) return { term, distance };
    return currentBest;
  }, null);
  return best && normalizeSearchText(best.term) !== normalizedQuery ? best.term : null;
}

export async function getSearchSuggestions(query: string, limit = 8): Promise<SmartSearchSnapshot> {
  const normalizedQuery = normalizeSearchText(query);
  if (!normalizedQuery) return { suggestions: [], correctedQuery: null };
  const cacheKey = `${normalizedQuery}:${limit}`;
  const cached = suggestionCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.value;

  const [tools, categories] = await Promise.all([getTools({ status: 'active' }), getCategories()]);
  const suggestions: SearchSuggestion[] = [];

  tools
    .filter((tool) => [tool.name, tool.taglineAr, tool.taglineEn, ...tool.tags].some((value) => tokenMatchesQuery(value, normalizedQuery)))
    .slice(0, 4)
    .forEach((tool) => suggestions.push(makeToolSuggestion(tool)));

  categories
    .filter((category) => [category.nameAr, category.nameEn, category.slug].some((value) => tokenMatchesQuery(value, normalizedQuery)))
    .slice(0, 3)
    .forEach((category) => suggestions.push(makeCategorySuggestion(category)));

  const tags = Array.from(new Set(tools.flatMap((tool) => tool.tags)));
  tags
    .filter((tag) => tokenMatchesQuery(tag, normalizedQuery))
    .slice(0, 3)
    .forEach((tag) => suggestions.push({ id: `tag-${tag}`, label: tag, type: 'tag', value: tag, href: `/search/results?tag=${encodeURIComponent(tag)}&q=${encodeURIComponent(tag)}` }));

  pricingOptions
    .filter((option) => option.labels.some((label) => tokenMatchesQuery(label, normalizedQuery)))
    .forEach((option) => suggestions.push({ id: `pricing-${option.value}`, label: option.labels[0], type: 'pricing', value: option.value, href: `/search/results?pricing=${option.value}` }));

  platformOptions
    .filter((option) => option.labels.some((label) => tokenMatchesQuery(label, normalizedQuery)))
    .forEach((option) => suggestions.push({ id: `platform-${option.value}`, label: option.labels[0], type: 'platform', value: option.value, href: `/search/results?platform=${option.value}` }));

  const dictionary = [
    ...tools.flatMap((tool) => [tool.name, ...tool.tags, tool.categorySlug]),
    ...categories.flatMap((category) => [category.nameAr, category.nameEn, category.slug]),
    ...pricingOptions.flatMap((option) => option.labels),
    ...platformOptions.flatMap((option) => option.labels),
  ];
  const correctedQuery = closestDictionaryTerm(query, dictionary);

  const uniqueSuggestions = suggestions.filter((suggestion, index, array) => array.findIndex((item) => item.id === suggestion.id) === index).slice(0, limit);
  const value = { suggestions: uniqueSuggestions, correctedQuery };
  suggestionCache.set(cacheKey, { expiresAt: Date.now() + CACHE_TTL_MS, value });
  return value;
}

export function clearSearchSuggestionCache() {
  suggestionCache.clear();
}
