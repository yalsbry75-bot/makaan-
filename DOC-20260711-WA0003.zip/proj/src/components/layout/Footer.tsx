import { Link } from 'react-router-dom';
import { BrandLogo } from '@/assets/brand/BrandLogo';
import { siteConfig } from '@/config/site';
import { useLocale } from '@/hooks/useLocale';

export function Footer() {
  const { locale } = useLocale();
  return (
    <footer className="relative border-t border-white/10 bg-black/40">
      <div className="divider-glow absolute inset-x-0 top-0" />
      <div className="container grid gap-8 py-14 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <BrandLogo />
          <p className="mt-4 max-w-md text-sm leading-7 text-muted-foreground">
            {locale === 'ar'
              ? 'منصة حديثة لاكتشاف أدوات الذكاء الاصطناعي وتنظيمها ومقارنتها ضمن تجربة عربية وإنجليزية متسقة.'
              : 'A modern platform for discovering, organizing, and comparing AI tools through a consistent Arabic and English experience.'}
          </p>
        </div>
        <div>
          <h3 className="font-bold">{locale === 'ar' ? 'الاستكشاف' : 'Explore'}</h3>
          <div className="mt-4 grid gap-2 text-sm text-muted-foreground">
            {siteConfig.nav.slice(1, 5).map((item) => <Link key={item.href} to={item.href}>{locale === 'ar' ? item.labelAr : item.labelEn}</Link>)}
          </div>
        </div>
        <div>
          <h3 className="font-bold">{locale === 'ar' ? 'الحساب' : 'Account'}</h3>
          <div className="mt-4 grid gap-2 text-sm text-muted-foreground">
            {siteConfig.dashboardNav.map((item) => <Link key={item.href} to={item.href}>{locale === 'ar' ? item.labelAr : item.labelEn}</Link>)}
          </div>
        </div>
        <div>
          <h3 className="font-bold">{locale === 'ar' ? 'قانوني ودعم' : 'Legal & Support'}</h3>
          <div className="mt-4 grid gap-2 text-sm text-muted-foreground">
            {siteConfig.footerNav.map((item) => <Link key={item.href} to={item.href}>{locale === 'ar' ? item.labelAr : item.labelEn}</Link>)}
            <Link to="/brand">{locale === 'ar' ? 'دليل الهوية' : 'Brand guide'}</Link>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} <span className="gold-text font-semibold">{siteConfig.name}</span>. {locale === 'ar' ? 'جميع الحقوق محفوظة.' : 'All rights reserved.'}
      </div>
    </footer>
  );
}
