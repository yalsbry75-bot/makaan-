import { Link, NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, LogOut, Menu, ShieldCheck, UserRound } from 'lucide-react';
import { BrandLogo } from '@/assets/brand/BrandLogo';
import { LanguageToggle } from '@/components/common/LanguageToggle';
import { ThemeToggle } from '@/components/common/ThemeToggle';
import { BottomSheet } from '@/components/ui/BottomSheet';
import { Button } from '@/components/ui/Button';
import { useToast } from '@/components/ui/Toast';
import { siteConfig } from '@/config/site';
import { useDisclosure } from '@/hooks/useDisclosure';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { cn } from '@/utils/cn';

export function Navbar() {
  const { isOpen, open, close } = useDisclosure(false);
  const { locale, t } = useLocale();
  const { isAuthenticated, logout, user } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    close();
    showToast({ title: locale === 'ar' ? 'تم تسجيل الخروج' : 'Signed out', tone: 'success' });
    navigate('/');
  };

  return (
    <header className="glass-nav sticky top-0 z-40">
      <div className="container flex h-20 items-center justify-between gap-4">
        <BrandLogo />
        <nav className="hidden items-center gap-1 xl:flex" aria-label="Main navigation">
          {siteConfig.nav.map((item) => (
            <NavLink
              key={item.href}
              to={item.href}
              className={({ isActive }) => cn('rounded-xl px-3 py-2 text-sm font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground', isActive && 'bg-muted text-foreground')}
            >
              {locale === 'ar' ? item.labelAr : item.labelEn}
            </NavLink>
          ))}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <LanguageToggle />
          <ThemeToggle />
          {isAuthenticated ? (
            <>
              {user?.role === 'admin' ? (
                <Link className="focus-ring inline-flex h-10 items-center justify-center gap-2 rounded-xl border px-4 text-sm font-semibold transition hover:bg-muted" to="/admin">
                  <ShieldCheck className="h-4 w-4" />
                  {locale === 'ar' ? 'الإدارة' : 'Admin'}
                </Link>
              ) : null}
              <Link className="focus-ring inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-card transition hover:bg-primary/90" to="/dashboard">
                <LayoutDashboard className="h-4 w-4" />
                {locale === 'ar' ? 'لوحتي' : 'Dashboard'}
              </Link>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4" />
                {locale === 'ar' ? 'خروج' : 'Logout'}
              </Button>
            </>
          ) : (
            <>
              <Link className="focus-ring inline-flex h-10 items-center justify-center rounded-xl border px-4 text-sm font-semibold transition hover:bg-muted" to="/login">{t('auth.login')}</Link>
              <Link className="focus-ring hidden h-10 items-center justify-center rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-card transition hover:bg-primary/90 lg:inline-flex" to="/register">{t('auth.register')}</Link>
            </>
          )}
        </div>
        <Button className="md:hidden" variant="outline" size="sm" aria-label="Open menu" onClick={open}>
          <Menu className="h-5 w-5" />
        </Button>
      </div>
      <BottomSheet open={isOpen} onClose={close} title="AI Hub Arabia">
        <div className="grid gap-2">
          {siteConfig.nav.map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.href} to={item.href} onClick={close} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold hover:bg-muted">
                <Icon className="h-4 w-4" />
                {locale === 'ar' ? item.labelAr : item.labelEn}
              </Link>
            );
          })}
          {isAuthenticated ? (
            <>
              {siteConfig.dashboardNav.filter((item) => item.href !== '/admin' || user?.role === 'admin').map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.href} to={item.href} onClick={close} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold hover:bg-muted">
                    <Icon className="h-4 w-4" />
                    {locale === 'ar' ? item.labelAr : item.labelEn}
                  </Link>
                );
              })}
              <Button className="mt-2 justify-start" variant="danger" onClick={handleLogout}>
                <LogOut className="h-4 w-4" />
                {locale === 'ar' ? 'تسجيل الخروج' : 'Logout'}
              </Button>
            </>
          ) : (
            <Link to="/login" onClick={close} className="mt-2 flex items-center gap-3 rounded-xl bg-primary px-3 py-3 text-sm font-semibold text-primary-foreground">
              <UserRound className="h-4 w-4" />
              {t('auth.login')}
            </Link>
          )}
          <div className="mt-3 flex gap-2">
            <LanguageToggle />
            <ThemeToggle />
          </div>
        </div>
      </BottomSheet>
    </header>
  );
}
