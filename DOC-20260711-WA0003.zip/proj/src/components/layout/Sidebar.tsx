import { NavLink, useNavigate } from 'react-router-dom';
import { LogOut, UserRound } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useToast } from '@/components/ui/Toast';
import { siteConfig } from '@/config/site';
import { useAuth } from '@/hooks/useAuth';
import { useLocale } from '@/hooks/useLocale';
import { cn } from '@/utils/cn';

export function Sidebar() {
  const { locale } = useLocale();
  const { logout, user } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    showToast({ title: locale === 'ar' ? 'تم تسجيل الخروج' : 'Signed out', tone: 'success' });
    navigate('/');
  };

  return (
    <aside className="hidden w-72 shrink-0 border-e bg-card/50 p-4 lg:block">
      <div className="sticky top-24 grid gap-4">
        <div className="rounded-3xl border bg-background p-4">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-primary/10 text-primary">
              <UserRound className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-bold">{user?.name}</p>
              <p className="truncate text-xs text-muted-foreground">{user?.email}</p>
            </div>
          </div>
          <span className="mt-3 inline-flex rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
            {user?.role === 'admin' ? (locale === 'ar' ? 'مدير النظام' : 'Administrator') : (locale === 'ar' ? 'مستخدم' : 'User')}
          </span>
        </div>
        <nav className="grid gap-2" aria-label="Dashboard navigation">
          {siteConfig.dashboardNav.filter((item) => item.href !== '/admin' || user?.role === 'admin').map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.href}
                to={item.href}
                className={({ isActive }) => cn('flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground', isActive && 'bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground')}
              >
                <Icon className="h-5 w-5" />
                {locale === 'ar' ? item.labelAr : item.labelEn}
              </NavLink>
            );
          })}
        </nav>
        <Button variant="outline" className="justify-start" onClick={handleLogout}>
          <LogOut className="h-4 w-4" />
          {locale === 'ar' ? 'تسجيل الخروج' : 'Logout'}
        </Button>
      </div>
    </aside>
  );
}
