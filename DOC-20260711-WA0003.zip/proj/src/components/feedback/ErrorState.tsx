import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { useLocale } from '@/hooks/useLocale';

export function ErrorState({ title, description, onRetry }: { title: string; description: string; onRetry?: () => void }) {
  const { locale } = useLocale();
  return (
    <Card className="flex min-h-72 flex-col items-center justify-center p-8 text-center">
      <div className="mb-4 rounded-2xl bg-destructive/10 p-4 text-destructive">
        <AlertTriangle className="h-8 w-8" />
      </div>
      <h3 className="text-lg font-bold">{title}</h3>
      <p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">{description}</p>
      {onRetry ? <Button className="mt-5" onClick={onRetry}>{locale === 'ar' ? 'إعادة المحاولة' : 'Retry'}</Button> : null}
    </Card>
  );
}
