import { Languages } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useLocale } from '@/hooks/useLocale';

export function LanguageToggle() {
  const { locale, toggleLocale } = useLocale();
  return (
    <Button aria-label="Toggle language" variant="outline" size="sm" onClick={toggleLocale}>
      <Languages className="h-4 w-4" />
      <span>{locale === 'ar' ? 'EN' : 'AR'}</span>
    </Button>
  );
}
