import { Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useTheme } from '@/hooks/useTheme';

export function ThemeToggle() {
  const { resolvedTheme, toggleTheme } = useTheme();
  const Icon = resolvedTheme === 'dark' ? Sun : Moon;
  return (
    <Button aria-label="Toggle theme" variant="outline" size="sm" onClick={toggleTheme}>
      <Icon className="h-4 w-4" />
    </Button>
  );
}
