import { CheckCircle2, MinusCircle, Star } from 'lucide-react';
import type { ComparisonItem } from '@/types';
import { Badge } from '@/components/ui/Badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { useLocale } from '@/hooks/useLocale';
import { categoryName, formatRating, pricingLabel } from '@/utils/format';

export function CompareCard({ item }: { item: ComparisonItem }) {
  const { locale } = useLocale();
  const strengths = locale === 'ar' ? item.strengthsAr : item.strengthsEn;
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>{item.name}</CardTitle>
        <div className="flex flex-wrap gap-2">
          <Badge>{categoryName(item.categorySlug, locale)}</Badge>
          <Badge variant="muted">{pricingLabel(item.pricing, locale)}</Badge>
          <Badge variant="warning"><Star className="h-3.5 w-3.5 fill-current" /> {formatRating(item.rating, locale)}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        <div>
          <h3 className="text-sm font-bold">{locale === 'ar' ? 'نقاط القوة' : 'Strengths'}</h3>
          <div className="mt-3 grid gap-2">
            {strengths.map((strength) => (
              <p key={strength} className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                {strength}
              </p>
            ))}
          </div>
        </div>
        <div className="rounded-2xl bg-muted p-4 text-sm">
          <strong>{locale === 'ar' ? 'الأفضل لـ: ' : 'Best for: '}</strong>
          <span className="text-muted-foreground">{locale === 'ar' ? item.bestForAr : item.bestForEn}</span>
        </div>
        <p className="flex gap-2 text-sm text-muted-foreground">
          <MinusCircle className="mt-0.5 h-4 w-4 text-amber-500" />
          {locale === 'ar' ? item.limitsAr : item.limitsEn}
        </p>
      </CardContent>
    </Card>
  );
}
