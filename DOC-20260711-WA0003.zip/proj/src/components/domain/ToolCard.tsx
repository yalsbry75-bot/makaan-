import { Link } from 'react-router-dom';
import { ArrowUpRight, GitCompare, Heart, Star, MonitorSmartphone } from 'lucide-react';
import type { AITool } from '@/types';
import { Badge } from '@/components/ui/Badge';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/Card';
import { useLocale } from '@/hooks/useLocale';
import { categoryName, formatRating, pricingLabel } from '@/utils/format';
import { platformLabel } from '@/utils/toolNormalization';
import { cn } from '@/utils/cn';

type ToolCardProps = {
  tool: AITool;
  compact?: boolean;
  isFavorite?: boolean;
  onToggleFavorite?: (tool: AITool) => void | Promise<void>;
};

export function ToolCard({ tool, compact = false, isFavorite = false, onToggleFavorite }: ToolCardProps) {
  const { locale, t } = useLocale();
  const primaryPlatform = tool.platform?.[0] ?? 'web';

  return (
    <Card className="group h-full overflow-hidden transition duration-300 hover:-translate-y-1 hover:shadow-soft">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className={cn('grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br text-sm font-extrabold text-white shadow-card', tool.logoGradient)}>
            {tool.logoUrl ? <img alt="" className="h-8 w-8 rounded-xl object-cover" src={tool.logoUrl} loading="lazy" decoding="async" /> : tool.name.slice(0, 2).toUpperCase()}
          </div>
          <div className="flex flex-wrap justify-end gap-2">
            {tool.featured ? <Badge variant="warning">{t('common.featured')}</Badge> : null}
            {tool.verified ? <Badge variant="success">{t('common.verified')}</Badge> : null}
            {tool.visibilityStatus === 'hidden' ? <Badge variant="muted">{locale === 'ar' ? 'مخفية' : 'Hidden'}</Badge> : null}
          </div>
        </div>
        <CardTitle className="mt-4 flex items-center justify-between gap-3">
          <Link className="hover:text-primary" to={`/tools/${tool.slug}`}>{tool.name}</Link>
          <button
            className={cn('rounded-full p-2 text-muted-foreground transition hover:bg-muted hover:text-primary', isFavorite && 'bg-primary/10 text-primary')}
            type="button"
            aria-label={isFavorite ? (locale === 'ar' ? 'إزالة من المفضلة' : 'Remove saved tool') : (locale === 'ar' ? 'حفظ في المفضلة' : 'Save tool')}
            onClick={() => onToggleFavorite?.(tool)}
          >
            <Heart className={cn('h-4 w-4', isFavorite && 'fill-current')} />
          </button>
        </CardTitle>
        <p className="text-sm leading-6 text-muted-foreground">{locale === 'ar' ? tool.taglineAr : tool.taglineEn}</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3 rounded-2xl bg-muted p-3 text-sm">
          <span className="flex items-center gap-1 font-semibold">
            <Star className="h-4 w-4 fill-accent text-accent" />
            {formatRating(tool.rating, locale)}
          </span>
          <span className="text-end text-muted-foreground">{pricingLabel(tool.pricing, locale)}</span>
          {!compact ? <span className="col-span-2 text-muted-foreground">{categoryName(tool.categorySlug, locale)}</span> : null}
          {!compact ? (
            <span className="col-span-2 flex items-center gap-2 text-muted-foreground">
              <MonitorSmartphone className="h-4 w-4" />
              {platformLabel(primaryPlatform, locale)} · {locale === 'ar' ? `${tool.reviewsCount ?? 0} مراجعة` : `${tool.reviewsCount ?? 0} reviews`}
            </span>
          ) : null}
        </div>
        {!compact ? (
          <div className="mt-4 flex flex-wrap gap-2">
            {tool.tags.slice(0, 3).map((tag) => <Badge key={tag} variant="muted">{tag}</Badge>)}
          </div>
        ) : null}
      </CardContent>
      <CardFooter className="grid gap-2">
        <Link to={`/compare?tool=${tool.slug}`} className="focus-ring inline-flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-border bg-background px-4 text-sm font-semibold transition hover:bg-muted">
          {locale === 'ar' ? 'أضف للمقارنة' : 'Add to compare'}
          <GitCompare className="h-4 w-4" />
        </Link>
        <Link to={`/tools/${tool.slug}`} className="focus-ring inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-border bg-background px-4 text-sm font-semibold transition hover:bg-muted">
          {t('common.viewDetails')}
          <ArrowUpRight className="h-4 w-4" />
        </Link>
      </CardFooter>
    </Card>
  );
}
