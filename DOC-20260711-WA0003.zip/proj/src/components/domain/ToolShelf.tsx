import type { ReactNode } from 'react';
import type { AITool } from '@/types';
import { ToolCard } from '@/components/domain/ToolCard';
import { SectionHeader } from '@/components/ui/SectionHeader';

export type ToolShelfProps = {
  title: string;
  description: string;
  tools: AITool[];
  action?: ReactNode;
  compact?: boolean;
};

export function ToolShelf({ title, description, tools, action, compact = true }: ToolShelfProps) {
  if (!tools.length) return null;

  return (
    <section className="content-visibility-auto mb-10">
      <SectionHeader title={title} description={description} action={action} />
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        {tools.map((tool) => <ToolCard key={tool.id} tool={tool} compact={compact} />)}
      </div>
    </section>
  );
}
