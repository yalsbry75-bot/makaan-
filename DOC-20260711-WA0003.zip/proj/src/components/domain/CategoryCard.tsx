import { Link } from 'react-router-dom';
import { ArrowUpRight, AudioLines, BriefcaseBusiness, Clapperboard, Code2, GraduationCap, Languages, LineChart, Megaphone, Palette, PenLine, SearchCheck, ShieldCheck, Sparkles, Workflow } from 'lucide-react';
import type { ToolCategory } from '@/types';
import { Card, CardContent } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { useLocale } from '@/hooks/useLocale';

const icons = { PenLine, Palette, Code2, Sparkles, Clapperboard, LineChart, GraduationCap, ShieldCheck, Megaphone, AudioLines, Languages, BriefcaseBusiness, SearchCheck, Workflow };

type IconKey = keyof typeof icons;

export function CategoryCard({ category }: { category: ToolCategory }) {
  const { locale } = useLocale();
  const Icon = icons[category.icon as IconKey] ?? Sparkles;
  return (
    <Link to={`/tools?category=${category.slug}`} className="group block h-full">
      <Card className="h-full transition duration-300 hover:-translate-y-1 hover:shadow-soft">
        <CardContent className="p-5">
          <div className="mb-5 flex items-center justify-between">
            <div className="grid h-12 w-12 place-items-center rounded-2xl bg-primary/10 text-primary">
              <Icon className="h-6 w-6" />
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="success">{category.growth}</Badge>
              <ArrowUpRight className="h-5 w-5 text-muted-foreground transition group-hover:text-primary" />
            </div>
          </div>
          <h3 className="text-lg font-bold">{locale === 'ar' ? category.nameAr : category.nameEn}</h3>
          <p className="mt-2 text-sm leading-6 text-muted-foreground">
            {locale === 'ar' ? category.descriptionAr : category.descriptionEn}
          </p>
          <p className="mt-4 text-sm font-semibold text-primary">{category.toolsCount}+ {locale === 'ar' ? 'أداة' : 'tools'}</p>
        </CardContent>
      </Card>
    </Link>
  );
}
