import type { Pricing, ToolCategory, ToolPlatform } from '@/types';
import { categories as seedCategories } from '@/constants/catalogSeed';
import { Card } from '@/components/ui/Card';
import { useLocale } from '@/hooks/useLocale';
import { pricingLabel } from '@/utils/format';
import { platformLabel } from '@/utils/toolNormalization';
import { cn } from '@/utils/cn';

type ToolFiltersProps = {
  selectedCategory: string;
  selectedPricing: string;
  selectedPlatform?: string;
  minRating?: number;
  selectedTag?: string;
  tagOptions?: string[];
  categories?: ToolCategory[];
  onCategoryChange: (category: string) => void;
  onPricingChange: (pricing: string) => void;
  onPlatformChange?: (platform: string) => void;
  onMinRatingChange?: (rating: number | undefined) => void;
  onTagChange?: (tag: string) => void;
  className?: string;
};

const pricingOptions: Array<Pricing | 'all'> = ['all', 'free', 'freemium', 'paid', 'enterprise'];
const platformOptions: Array<ToolPlatform | 'all'> = ['all', 'web', 'android', 'ios', 'api', 'desktop'];

export function ToolFilters({
  selectedCategory,
  selectedPricing,
  selectedPlatform = 'all',
  minRating,
  selectedTag = 'all',
  tagOptions = [],
  categories = seedCategories,
  onCategoryChange,
  onPricingChange,
  onPlatformChange,
  onMinRatingChange,
  onTagChange,
  className,
}: ToolFiltersProps) {
  const { locale } = useLocale();

  return (
    <Card className={cn('p-4', className)}>
      <div className="space-y-6">
        <div>
          <h2 className="font-bold">{locale === 'ar' ? 'التصنيفات' : 'Categories'}</h2>
          <div className="mt-4 grid gap-2">
            <button className={filterClass(selectedCategory === 'all')} onClick={() => onCategoryChange('all')} type="button">
              {locale === 'ar' ? 'كل التصنيفات' : 'All categories'}
            </button>
            {categories.map((category) => (
              <button key={category.id} className={filterClass(selectedCategory === category.slug)} onClick={() => onCategoryChange(category.slug)} type="button">
                <span>{locale === 'ar' ? category.nameAr : category.nameEn}</span>
                <span className="text-xs text-muted-foreground">{category.toolsCount}</span>
              </button>
            ))}
          </div>
        </div>
        <div>
          <h2 className="font-bold">{locale === 'ar' ? 'خطة السعر' : 'Pricing'}</h2>
          <div className="mt-4 grid gap-2">
            {pricingOptions.map((pricing) => (
              <button key={pricing} className={filterClass(selectedPricing === pricing)} onClick={() => onPricingChange(pricing)} type="button">
                {pricing === 'all' ? (locale === 'ar' ? 'كل الخطط' : 'All plans') : pricingLabel(pricing, locale)}
              </button>
            ))}
          </div>
        </div>
        <div>
          <h2 className="font-bold">{locale === 'ar' ? 'المنصة' : 'Platform'}</h2>
          <div className="mt-4 grid gap-2">
            {platformOptions.map((platform) => (
              <button key={platform} className={filterClass(selectedPlatform === platform)} onClick={() => onPlatformChange?.(platform)} type="button">
                {platform === 'all' ? (locale === 'ar' ? 'كل المنصات' : 'All platforms') : platformLabel(platform, locale)}
              </button>
            ))}
          </div>
        </div>
        {tagOptions.length ? (
          <div>
            <h2 className="font-bold">{locale === 'ar' ? 'الوسوم' : 'Tags'}</h2>
            <div className="mt-4 grid gap-2">
              <button className={filterClass(selectedTag === 'all')} onClick={() => onTagChange?.('all')} type="button">
                {locale === 'ar' ? 'كل الوسوم' : 'All tags'}
              </button>
              {tagOptions.slice(0, 10).map((tag) => (
                <button key={tag} className={filterClass(selectedTag === tag)} onClick={() => onTagChange?.(tag)} type="button">
                  {tag}
                </button>
              ))}
            </div>
          </div>
        ) : null}
        <div>
          <h2 className="font-bold">{locale === 'ar' ? 'التقييم' : 'Rating'}</h2>
          <div className="mt-4 grid gap-2">
            {[undefined, 4.5, 4.0].map((rating) => (
              <button key={rating ?? 'all'} className={filterClass(minRating === rating)} onClick={() => onMinRatingChange?.(rating)} type="button">
                {rating ? (locale === 'ar' ? `${rating}+ نجوم` : `${rating}+ stars`) : (locale === 'ar' ? 'كل التقييمات' : 'All ratings')}
              </button>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}

function filterClass(active: boolean) {
  return cn(
    'flex items-center justify-between rounded-xl px-3 py-2 text-start text-sm transition hover:bg-muted',
    active && 'bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground',
  );
}
