import { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useLocale } from '@/hooks/useLocale';

const pageLabels: Record<string, { ar: string; en: string }> = {
  '/': { ar: 'الصفحة الرئيسية', en: 'Home page' },
  '/tools': { ar: 'صفحة الأدوات', en: 'Tools page' },
  '/categories': { ar: 'صفحة التصنيفات', en: 'Categories page' },
  '/compare': { ar: 'صفحة المقارنة', en: 'Comparison page' },
  '/search': { ar: 'صفحة البحث', en: 'Search page' },
  '/search/results': { ar: 'نتائج البحث', en: 'Search results' },
  '/login': { ar: 'تسجيل الدخول', en: 'Login' },
  '/register': { ar: 'إنشاء حساب', en: 'Register' },
  '/forgot-password': { ar: 'استعادة كلمة المرور', en: 'Forgot password' },
  '/profile': { ar: 'الملف الشخصي', en: 'Profile' },
  '/favorites': { ar: 'المفضلة', en: 'Favorites' },
  '/dashboard': { ar: 'لوحة المستخدم', en: 'User dashboard' },
  '/admin': { ar: 'لوحة الإدارة', en: 'Admin dashboard' },
  '/admin/tools': { ar: 'إدارة الأدوات', en: 'Admin tools' },
  '/admin/users': { ar: 'إدارة المستخدمين', en: 'Admin users' },
  '/admin/reviews': { ar: 'إدارة المراجعات', en: 'Admin reviews' },
  '/admin/messages': { ar: 'إدارة الرسائل والبلاغات', en: 'Admin messages and reports' },
  '/admin/stats': { ar: 'إحصائيات الإدارة', en: 'Admin analytics' },
  '/admin/settings': { ar: 'إعدادات الموقع', en: 'Site settings' },
  '/about': { ar: 'من نحن', en: 'About' },
  '/contact': { ar: 'تواصل معنا', en: 'Contact' },
  '/privacy': { ar: 'سياسة الخصوصية', en: 'Privacy policy' },
  '/terms': { ar: 'الشروط والأحكام', en: 'Terms and conditions' },
  '/brand': { ar: 'دليل الهوية', en: 'Brand guide' },
};

function resolveRouteLabel(pathname: string, locale: 'ar' | 'en') {
  if (pathname.startsWith('/tools/') && pathname !== '/tools') {
    return locale === 'ar' ? 'تفاصيل الأداة' : 'Tool details';
  }
  return pageLabels[pathname]?.[locale] ?? (locale === 'ar' ? 'صفحة جديدة' : 'New page');
}

export function RouteAnnouncer() {
  const location = useLocation();
  const { locale } = useLocale();
  const [announcement, setAnnouncement] = useState('');
  const label = useMemo(() => resolveRouteLabel(location.pathname, locale), [location.pathname, locale]);

  useEffect(() => {
    setAnnouncement(locale === 'ar' ? `تم الانتقال إلى ${label}` : `Navigated to ${label}`);

    window.requestAnimationFrame(() => {
      const mainContent = document.getElementById('main-content');
      mainContent?.focus({ preventScroll: true });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }, [label, locale, location.key]);

  return (
    <div className="sr-only" aria-live="polite" aria-atomic="true">
      {announcement}
    </div>
  );
}
