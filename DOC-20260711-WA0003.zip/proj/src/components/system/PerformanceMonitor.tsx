import { useEffect } from 'react';
import { logAuditEvent } from '@/services/securityService';

export function PerformanceMonitor() {
  useEffect(() => {
    if (typeof PerformanceObserver === 'undefined') return undefined;

    let observer: PerformanceObserver | null = null;
    try {
      observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.duration >= 120) {
            void logAuditEvent({
              event: 'long_task_detected',
              severity: 'warning',
              resource: 'performance',
              metadata: {
                durationMs: Math.round(entry.duration),
                name: entry.name || 'long-task',
              },
            });
          }
        }
      });
      observer.observe({ type: 'longtask', buffered: true } as PerformanceObserverInit);
    } catch {
      observer = null;
    }

    return () => observer?.disconnect();
  }, []);

  return null;
}
