import { useEffect, useState } from 'react';
import { WifiOff } from 'lucide-react';
import { useLocale } from '@/hooks/useLocale';
import { useToast } from '@/components/ui/Toast';

export function NetworkStatus() {
  const { locale } = useLocale();
  const { showToast } = useToast();
  const [isOnline, setIsOnline] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine));

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      showToast({
        title: locale === 'ar' ? 'عاد الاتصال' : 'Connection restored',
        description: locale === 'ar' ? 'يمكنك متابعة التصفح بشكل طبيعي.' : 'You can continue browsing normally.',
        tone: 'success',
      });
    };
    const handleOffline = () => {
      setIsOnline(false);
      showToast({
        title: locale === 'ar' ? 'لا يوجد اتصال' : 'You are offline',
        description: locale === 'ar' ? 'ستظل الصفحات المخزنة متاحة بفضل PWA.' : 'Cached pages remain available through the PWA.',
        tone: 'error',
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [locale, showToast]);

  if (isOnline) return null;

  return (
    <div className="fixed inset-x-3 bottom-3 z-[80] mx-auto flex max-w-xl items-center gap-3 rounded-2xl border border-destructive/30 bg-destructive px-4 py-3 text-sm font-semibold text-destructive-foreground shadow-soft" role="status" aria-live="assertive">
      <WifiOff className="h-5 w-5 shrink-0" />
      <span>{locale === 'ar' ? 'أنت غير متصل حاليًا. سيتم استخدام البيانات المخزنة عند توفرها.' : 'You are offline. Cached data will be used when available.'}</span>
    </div>
  );
}
