import { Component, type ErrorInfo, type ReactNode } from 'react';
import { Button } from '@/components/ui/Button';
import { logAuditEvent, redactError } from '@/services/securityService';

export class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; message: string }> {
  state = { hasError: false, message: '' };

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    void logAuditEvent({
      event: 'runtime_error_boundary',
      severity: 'critical',
      resource: 'react',
      metadata: {
        message: redactError(error),
        stack: (info.componentStack ?? '').slice(0, 800),
      },
    });
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <main className="section-padding">
        <div className="container grid min-h-[60vh] place-items-center text-center">
          <div className="max-w-xl rounded-[2rem] border border-border bg-card p-8 shadow-card">
            <p className="text-sm font-semibold text-primary">AI Hub Arabia</p>
            <h1 className="mt-3 text-2xl font-black text-foreground">تعذر تحميل هذه الواجهة</h1>
            <p className="mt-3 text-sm leading-7 text-muted-foreground">
              تم تسجيل الخطأ محليًا للمراجعة. أعد تحميل الصفحة، وإذا استمر الخطأ استخدم صفحة التواصل.
            </p>
            <Button className="mt-6" onClick={() => window.location.reload()}>إعادة التحميل</Button>
          </div>
        </div>
      </main>
    );
  }
}
