import type { ReactNode } from 'react';
import { Card } from '@/components/ui/Card';
import { cn } from '@/utils/cn';

type StatCardProps = {
  label: string;
  value: string;
  change?: string;
  icon?: ReactNode;
  className?: string;
};

export function StatCard({ label, value, change, icon, className }: StatCardProps) {
  return (
    <Card className={cn('p-5', className)}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm text-muted-foreground">{label}</p>
          <strong className="mt-2 block text-3xl font-extrabold">{value}</strong>
        </div>
        {icon ? <div className="grid h-11 w-11 place-items-center rounded-2xl bg-primary/10 text-primary">{icon}</div> : null}
      </div>
      {change ? <p className="mt-4 text-sm font-semibold text-primary">{change}</p> : null}
    </Card>
  );
}
