import type { ReactNode } from 'react';
import { Badge } from '@/components/ui/Badge';
import { cn } from '@/utils/cn';

type SectionHeaderProps = {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: ReactNode;
  centered?: boolean;
  className?: string;
};

export function SectionHeader({ eyebrow, title, description, action, centered = false, className }: SectionHeaderProps) {
  return (
    <div className={cn('mb-8 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between', centered && 'mx-auto max-w-3xl text-center lg:block', className)}>
      <div>
        {eyebrow ? <Badge className="mb-3">{eyebrow}</Badge> : null}
        <h1 className="text-3xl font-extrabold tracking-tight md:text-4xl"><span className="gradient-text">{title}</span></h1>
        {description ? <p className="mt-3 max-w-2xl text-muted-foreground">{description}</p> : null}
      </div>
      {action ? <div>{action}</div> : null}
    </div>
  );
}
