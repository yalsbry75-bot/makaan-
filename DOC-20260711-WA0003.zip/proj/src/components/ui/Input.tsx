import { forwardRef } from 'react';
import type { InputHTMLAttributes } from 'react';
import { cn } from '@/utils/cn';

export type InputProps = InputHTMLAttributes<HTMLInputElement> & {
  label?: string;
  helperText?: string;
  error?: string;
};

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, helperText, error, id, ...props }, ref) => {
    const inputId = id ?? props.name;
    return (
      <label className="block space-y-2" htmlFor={inputId}>
        {label ? <span className="text-sm font-semibold text-foreground">{label}</span> : null}
        <input
          id={inputId}
          ref={ref}
          className={cn(
            'focus-ring h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none transition placeholder:text-muted-foreground/70',
            error && 'border-destructive focus-visible:ring-destructive',
            className,
          )}
          {...props}
        />
        {error ? <span className="text-xs font-medium text-destructive">{error}</span> : null}
        {!error && helperText ? <span className="text-xs text-muted-foreground">{helperText}</span> : null}
      </label>
    );
  },
);
Input.displayName = 'Input';
