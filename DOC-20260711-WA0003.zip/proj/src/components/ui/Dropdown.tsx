import type { ReactNode } from 'react';
import { ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { cn } from '@/utils/cn';

type DropdownItem = {
  label: string;
  onSelect?: () => void;
  icon?: ReactNode;
};

type DropdownProps = {
  label: string;
  items: DropdownItem[];
  className?: string;
};

export function Dropdown({ label, items, className }: DropdownProps) {
  return (
    <div className={cn('group relative inline-block', className)}>
      <Button variant="outline" className="gap-2">
        {label}
        <ChevronDown className="h-4 w-4" />
      </Button>
      <Card className="invisible absolute end-0 top-full z-40 mt-2 min-w-48 translate-y-1 p-1 opacity-0 transition group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100">
        {items.map((item) => (
          <button
            className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-start text-sm hover:bg-muted"
            key={item.label}
            onClick={item.onSelect}
            type="button"
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </Card>
    </div>
  );
}
