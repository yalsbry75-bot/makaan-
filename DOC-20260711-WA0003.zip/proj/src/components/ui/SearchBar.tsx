import { ArrowRight, Search, Sparkles } from 'lucide-react';
import type { InputHTMLAttributes } from 'react';
import { FormEvent, useEffect, useId, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/Button';
import type { SearchSuggestion } from '@/services/searchService';
import { getSearchSuggestions } from '@/services/searchService';
import { useLocale } from '@/hooks/useLocale';
import { cn } from '@/utils/cn';

type SearchBarProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'onSubmit'> & {
  initialValue?: string;
  showButton?: boolean;
  onSearch?: (query: string) => void;
  enableSuggestions?: boolean;
};

function suggestionTypeLabel(type: SearchSuggestion['type'], locale: 'ar' | 'en') {
  const labels: Record<SearchSuggestion['type'], { ar: string; en: string }> = {
    tool: { ar: 'أداة', en: 'Tool' },
    category: { ar: 'تصنيف', en: 'Category' },
    tag: { ar: 'وسم', en: 'Tag' },
    pricing: { ar: 'سعر', en: 'Pricing' },
    platform: { ar: 'منصة', en: 'Platform' },
    keyword: { ar: 'كلمة', en: 'Keyword' },
  };
  return labels[type][locale];
}

export function SearchBar({ className, placeholder, initialValue = '', showButton = false, onSearch, enableSuggestions = true, ...props }: SearchBarProps) {
  const { t, locale } = useLocale();
  const navigate = useNavigate();
  const inputId = useId();
  const suggestionsId = `${inputId}-suggestions`;
  const helpId = `${inputId}-help`;
  const [query, setQuery] = useState(initialValue);
  const [isFocused, setIsFocused] = useState(false);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([]);
  const [correctedQuery, setCorrectedQuery] = useState<string | null>(null);
  const suggestionPanelRef = useRef<HTMLDivElement | null>(null);
  const shouldShowSuggestions = enableSuggestions && isFocused && query.trim().length >= 2 && (isSuggesting || suggestions.length > 0 || correctedQuery);

  useEffect(() => {
    setQuery(initialValue);
  }, [initialValue]);

  useEffect(() => {
    if (!enableSuggestions || query.trim().length < 2) {
      setSuggestions([]);
      setCorrectedQuery(null);
      setIsSuggesting(false);
      return;
    }
    let isMounted = true;
    setIsSuggesting(true);
    const timer = window.setTimeout(() => {
      getSearchSuggestions(query)
        .then((snapshot) => {
          if (!isMounted) return;
          setSuggestions(snapshot.suggestions);
          setCorrectedQuery(snapshot.correctedQuery);
        })
        .catch(() => {
          if (!isMounted) return;
          setSuggestions([]);
          setCorrectedQuery(null);
        })
        .finally(() => {
          if (isMounted) setIsSuggesting(false);
        });
    }, 160);
    return () => {
      isMounted = false;
      window.clearTimeout(timer);
    };
  }, [enableSuggestions, query]);

  const correctedHref = useMemo(() => (correctedQuery ? `/search/results?q=${encodeURIComponent(correctedQuery)}` : ''), [correctedQuery]);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const normalized = query.trim();
    if (onSearch) {
      onSearch(normalized);
      return;
    }
    if (normalized) {
      navigate(`/search/results?q=${encodeURIComponent(normalized)}`);
    } else {
      navigate('/search');
    }
  }

  return (
    <form className={cn('relative flex gap-2', className)} onSubmit={handleSubmit} role="search">
      <div className="relative min-w-0 flex-1">
        <Search className="pointer-events-none absolute start-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
        <input
          id={inputId}
          className="focus-ring h-14 w-full rounded-2xl border border-white/10 bg-white/[0.04] px-12 text-sm shadow-glow outline-none backdrop-blur-xl placeholder:text-muted-foreground/70"
          role="combobox"
          aria-autocomplete="list"
          aria-expanded={Boolean(shouldShowSuggestions)}
          aria-controls={shouldShowSuggestions ? suggestionsId : undefined}
          aria-describedby={helpId}
          placeholder={placeholder ?? t('common.search')}
          value={query}
          onBlur={(event) => {
            if (suggestionPanelRef.current?.contains(event.relatedTarget as Node)) return;
            window.setTimeout(() => setIsFocused(false), 120);
          }}
          onChange={(event) => setQuery(event.target.value)}
          onFocus={() => setIsFocused(true)}
          {...props}
        />
        <span id={helpId} className="sr-only">{locale === 'ar' ? 'اكتب للبحث، ثم استخدم Tab للوصول إلى اقتراحات البحث.' : 'Type to search, then use Tab to reach search suggestions.'}</span>
        {shouldShowSuggestions ? (
          <div id={suggestionsId} ref={suggestionPanelRef} className="glass-panel absolute inset-x-0 top-[calc(100%+0.5rem)] z-50 overflow-hidden rounded-2xl" tabIndex={-1} role="listbox" aria-label={locale === 'ar' ? 'اقتراحات البحث' : 'Search suggestions'}>
            <div className="border-b px-4 py-3 text-xs font-semibold text-muted-foreground">
              {isSuggesting ? (locale === 'ar' ? 'جاري تجهيز الاقتراحات...' : 'Preparing suggestions...') : (locale === 'ar' ? 'اقتراحات بحث فورية' : 'Instant search suggestions')}
            </div>
            {correctedQuery ? (
              <Link className="focus-ring flex items-center gap-2 border-b px-4 py-3 text-sm transition hover:bg-muted" to={correctedHref} role="option" aria-selected="false">
                <Sparkles className="h-4 w-4 text-primary" />
                <span>{locale === 'ar' ? 'هل تقصد:' : 'Did you mean:'}</span>
                <strong>{correctedQuery}</strong>
              </Link>
            ) : null}
            {suggestions.length ? (
              <div className="max-h-80 overflow-y-auto p-2">
                {suggestions.map((suggestion) => (
                  <Link key={suggestion.id} className="focus-ring flex items-center justify-between gap-3 rounded-xl px-3 py-2 text-sm transition hover:bg-muted" to={suggestion.href} role="option" aria-selected="false">
                    <span className="truncate font-medium">{suggestion.label}</span>
                    <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-muted px-2 py-1 text-[11px] text-muted-foreground">
                      {suggestionTypeLabel(suggestion.type, locale)} <ArrowRight className="h-3 w-3 rtl:rotate-180" />
                    </span>
                  </Link>
                ))}
              </div>
            ) : !isSuggesting ? (
              <div className="px-4 py-4 text-sm text-muted-foreground">{locale === 'ar' ? 'لا توجد اقتراحات مباشرة. اضغط بحث لعرض أقرب النتائج.' : 'No direct suggestions. Press search to show closest results.'}</div>
            ) : null}
          </div>
        ) : null}
      </div>
      {showButton ? <Button type="submit">{locale === 'ar' ? 'بحث' : 'Search'}</Button> : null}
    </form>
  );
}
