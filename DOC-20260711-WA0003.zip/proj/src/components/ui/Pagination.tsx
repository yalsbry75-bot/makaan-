import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useLocale } from '@/hooks/useLocale';
import { cn } from '@/utils/cn';

type PaginationProps = {
  page: number;
  totalPages: number;
  onPageChange?: (page: number) => void;
  className?: string;
};

export function Pagination({ page, totalPages, onPageChange, className }: PaginationProps) {
  const { direction, locale } = useLocale();
  const PreviousIcon = direction === 'rtl' ? ChevronRight : ChevronLeft;
  const NextIcon = direction === 'rtl' ? ChevronLeft : ChevronRight;
  const pages = Array.from({ length: totalPages }, (_, index) => index + 1);

  return (
    <div className={cn('flex flex-wrap items-center justify-center gap-2', className)}>
      <Button variant="outline" size="sm" disabled={page === 1} onClick={() => onPageChange?.(page - 1)}>
        <PreviousIcon className="h-4 w-4" />
        {locale === 'ar' ? 'السابق' : 'Previous'}
      </Button>
      {pages.map((pageNumber) => (
        <Button
          key={pageNumber}
          variant={pageNumber === page ? 'primary' : 'outline'}
          size="sm"
          aria-current={pageNumber === page ? 'page' : undefined}
          onClick={() => onPageChange?.(pageNumber)}
        >
          {pageNumber}
        </Button>
      ))}
      <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => onPageChange?.(page + 1)}>
        {locale === 'ar' ? 'التالي' : 'Next'}
        <NextIcon className="h-4 w-4" />
      </Button>
    </div>
  );
}
