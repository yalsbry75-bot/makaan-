import { Loader2 } from 'lucide-react';
import { cn } from '@/utils/cn';

export function Loading({ label = 'Loading', className }: { label?: string; className?: string }) {
  return (
    <div className={cn('flex items-center justify-center gap-3 text-muted-foreground', className)} role="status">
      <Loader2 className="h-5 w-5 animate-spin" />
      <span className="text-sm">{label}</span>
    </div>
  );
}
