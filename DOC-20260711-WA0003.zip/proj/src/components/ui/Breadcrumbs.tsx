import { ChevronLeft, ChevronRight, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLocale } from '@/hooks/useLocale';
import { cn } from '@/utils/cn';

type Crumb = { label: string; href?: string };

export function Breadcrumbs({ items, className }: { items: Crumb[]; className?: string }) {
  const { direction, locale } = useLocale();
  const Separator = direction === 'rtl' ? ChevronLeft : ChevronRight;

  return (
    <nav className={cn('flex flex-wrap items-center gap-2 text-sm text-muted-foreground', className)} aria-label="Breadcrumb">
      <Link className="inline-flex items-center gap-1 rounded-lg hover:text-foreground" to="/">
        <Home className="h-4 w-4" />
        {locale === 'ar' ? 'الرئيسية' : 'Home'}
      </Link>
      {items.map((item, index) => (
        <span key={`${item.label}-${index}`} className="inline-flex items-center gap-2">
          <Separator className="h-4 w-4" />
          {item.href ? <Link className="hover:text-foreground" to={item.href}>{item.label}</Link> : <span className="font-medium text-foreground">{item.label}</span>}
        </span>
      ))}
    </nav>
  );
}
