import type { HTMLAttributes } from 'react';
import { cn } from '@/utils/cn';

type BadgeVariant = 'default' | 'success' | 'warning' | 'muted';

const variants: Record<BadgeVariant, string> = {
  default: 'bg-primary-500/10 text-primary-300 ring-primary-500/25',
  success: 'bg-emerald-500/10 text-emerald-300 ring-emerald-500/25',
  warning: 'bg-accent/10 text-accent ring-accent/30',
  muted: 'bg-muted text-muted-foreground ring-border',
};

export function Badge({ className, variant = 'default', ...props }: HTMLAttributes<HTMLSpanElement> & { variant?: BadgeVariant }) {
  return (
    <span
      className={cn('inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset', variants[variant], className)}
      {...props}
    />
  );
}
