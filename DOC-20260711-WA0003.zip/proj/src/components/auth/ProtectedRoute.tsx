import type { ReactNode } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { Loading } from '@/components/ui/Loading';
import { useAuth } from '@/hooks/useAuth';
import type { UserRole } from '@/types/auth';
import { logAuditEvent } from '@/services/securityService';

export function ProtectedRoute({ children, roles }: { children?: ReactNode; roles?: UserRole[] }) {
  const location = useLocation();
  const { canAccess, status } = useAuth();

  if (status === 'loading') {
    return (
      <div className="grid min-h-[calc(100vh-10rem)] place-items-center">
        <Loading label="جاري التحقق من الجلسة" />
      </div>
    );
  }

  if (!canAccess()) {
    void logAuditEvent({ event: 'protected_route_redirect_guest', severity: 'info', resource: location.pathname });
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  if (!canAccess(roles)) {
    void logAuditEvent({ event: 'protected_route_permission_denied', severity: 'warning', resource: location.pathname, metadata: { roles: roles?.join(',') ?? '' } });
    return <Navigate to="/dashboard" replace state={{ denied: true }} />;
  }

  return children ? <>{children}</> : <Outlet />;
}
