import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { Loading } from '@/components/ui/Loading';
import { useAuth } from '@/hooks/useAuth';

export function PublicOnlyRoute() {
  const location = useLocation();
  const { isAuthenticated, status } = useAuth();
  const from = (location.state as { from?: { pathname?: string } } | null)?.from?.pathname ?? '/dashboard';

  if (status === 'loading') {
    return (
      <div className="grid min-h-[calc(100vh-10rem)] place-items-center">
        <Loading label="جاري تجهيز صفحة الحساب" />
      </div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to={from} replace />;
  }

  return <Outlet />;
}
