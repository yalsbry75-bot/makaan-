import { useEffect } from 'react';
import { seoDefaults, siteConfig } from '@/config/site';

type SeoOptions = {
  title?: string;
  description?: string;
  canonicalPath?: string;
  image?: string;
  type?: 'website' | 'article';
  structuredData?: Record<string, unknown>;
};

function setMeta(selector: string, attr: 'content' | 'href', value: string) {
  const element = document.querySelector<HTMLMetaElement | HTMLLinkElement>(selector);
  if (element) element.setAttribute(attr, value);
}

function ensureMeta(name: string, value: string, property = false) {
  const attribute = property ? 'property' : 'name';
  let element = document.querySelector<HTMLMetaElement>(`meta[${attribute}="${name}"]`);
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attribute, name);
    document.head.appendChild(element);
  }
  element.content = value;
}

function ensureCanonical(url: string) {
  let element = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
  if (!element) {
    element = document.createElement('link');
    element.rel = 'canonical';
    document.head.appendChild(element);
  }
  element.href = url;
}

function ensureStructuredData(data: Record<string, unknown>) {
  const id = 'ai-hub-arabia-structured-data';
  let element = document.getElementById(id) as HTMLScriptElement | null;
  if (!element) {
    element = document.createElement('script');
    element.id = id;
    element.type = 'application/ld+json';
    document.head.appendChild(element);
  }
  element.textContent = JSON.stringify(data);
}

export function useSeo(titleOrOptions?: string | SeoOptions, description?: string) {
  useEffect(() => {
    const options: SeoOptions = typeof titleOrOptions === 'object' ? titleOrOptions : { title: titleOrOptions, description };
    const title = options.title ? `${options.title} | AI Hub Arabia` : seoDefaults.title;
    const metaDescription = options.description ?? seoDefaults.description;
    const baseUrl = seoDefaults.siteUrl;
    const canonicalUrl = `${baseUrl}${options.canonicalPath ?? window.location.pathname}`;
    const image = options.image ?? `${baseUrl}/icons/brand-mark.svg`;

    document.title = title;
    document.documentElement.lang = document.documentElement.lang || 'ar';

    ensureMeta('description', metaDescription);
    ensureMeta('robots', 'index,follow,max-image-preview:large');
    ensureMeta('referrer', 'strict-origin-when-cross-origin');
    ensureMeta('og:site_name', siteConfig.name, true);
    ensureMeta('og:title', title, true);
    ensureMeta('og:description', metaDescription, true);
    ensureMeta('og:type', options.type ?? 'website', true);
    ensureMeta('og:url', canonicalUrl, true);
    ensureMeta('og:image', image, true);
    ensureMeta('twitter:card', 'summary_large_image');
    ensureMeta('twitter:title', title);
    ensureMeta('twitter:description', metaDescription);
    ensureMeta('twitter:image', image);
    setMeta('meta[name="theme-color"]', 'content', '#0F766E');
    ensureCanonical(canonicalUrl);

    ensureStructuredData(
      options.structuredData ?? {
        '@context': 'https://schema.org',
        '@type': 'WebSite',
        name: siteConfig.name,
        alternateName: siteConfig.nameAr,
        url: baseUrl,
        description: metaDescription,
        potentialAction: {
          '@type': 'SearchAction',
          target: `${baseUrl}/search/results?q={search_term_string}`,
          'query-input': 'required name=search_term_string',
        },
      },
    );
  }, [description, titleOrOptions]);
}
