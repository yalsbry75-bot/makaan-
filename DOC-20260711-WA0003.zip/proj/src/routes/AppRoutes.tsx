import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { PublicOnlyRoute } from '@/components/auth/PublicOnlyRoute';
import { Loading } from '@/components/ui/Loading';
import { AdminLayout } from '@/layouts/AdminLayout';
import { AuthLayout } from '@/layouts/AuthLayout';
import { DashboardLayout } from '@/layouts/DashboardLayout';
import { RootLayout } from '@/layouts/RootLayout';

const AboutPage = lazy(() => import('@/pages/AboutPage').then((module) => ({ default: module.AboutPage })));
const AdminDashboardPage = lazy(() => import('@/pages/AdminDashboardPage').then((module) => ({ default: module.AdminDashboardPage })));
const AdminToolsPage = lazy(() => import('@/pages/AdminToolsPage').then((module) => ({ default: module.AdminToolsPage })));
const AdminUsersPage = lazy(() => import('@/pages/AdminUsersPage').then((module) => ({ default: module.AdminUsersPage })));
const AdminReviewsPage = lazy(() => import('@/pages/AdminReviewsPage').then((module) => ({ default: module.AdminReviewsPage })));
const AdminMessagesPage = lazy(() => import('@/pages/AdminMessagesPage').then((module) => ({ default: module.AdminMessagesPage })));
const AdminStatsPage = lazy(() => import('@/pages/AdminStatsPage').then((module) => ({ default: module.AdminStatsPage })));
const AdminSettingsPage = lazy(() => import('@/pages/AdminSettingsPage').then((module) => ({ default: module.AdminSettingsPage })));
const AdminSystemPage = lazy(() => import('@/pages/AdminSystemPage').then((module) => ({ default: module.AdminSystemPage })));
const BrandGuidePage = lazy(() => import('@/pages/BrandGuidePage').then((module) => ({ default: module.BrandGuidePage })));
const CategoriesPage = lazy(() => import('@/pages/CategoriesPage').then((module) => ({ default: module.CategoriesPage })));
const ComparePage = lazy(() => import('@/pages/ComparePage').then((module) => ({ default: module.ComparePage })));
const ContactPage = lazy(() => import('@/pages/ContactPage').then((module) => ({ default: module.ContactPage })));
const FavoritesPage = lazy(() => import('@/pages/FavoritesPage').then((module) => ({ default: module.FavoritesPage })));
const UserComparisonsPage = lazy(() => import('@/pages/UserComparisonsPage').then((module) => ({ default: module.UserComparisonsPage })));
const UserReviewsPage = lazy(() => import('@/pages/UserReviewsPage').then((module) => ({ default: module.UserReviewsPage })));
const ForgotPasswordPage = lazy(() => import('@/pages/ForgotPasswordPage').then((module) => ({ default: module.ForgotPasswordPage })));
const HomePage = lazy(() => import('@/pages/HomePage').then((module) => ({ default: module.HomePage })));
const LoginPage = lazy(() => import('@/pages/LoginPage').then((module) => ({ default: module.LoginPage })));
const NotFoundPage = lazy(() => import('@/pages/NotFoundPage').then((module) => ({ default: module.NotFoundPage })));
const PrivacyPage = lazy(() => import('@/pages/PrivacyPage').then((module) => ({ default: module.PrivacyPage })));
const ProfilePage = lazy(() => import('@/pages/ProfilePage').then((module) => ({ default: module.ProfilePage })));
const RegisterPage = lazy(() => import('@/pages/RegisterPage').then((module) => ({ default: module.RegisterPage })));
const SearchPage = lazy(() => import('@/pages/SearchPage').then((module) => ({ default: module.SearchPage })));
const SearchResultsPage = lazy(() => import('@/pages/SearchResultsPage').then((module) => ({ default: module.SearchResultsPage })));
const TermsPage = lazy(() => import('@/pages/TermsPage').then((module) => ({ default: module.TermsPage })));
const ToolDetailsPage = lazy(() => import('@/pages/ToolDetailsPage').then((module) => ({ default: module.ToolDetailsPage })));
const ToolsPage = lazy(() => import('@/pages/ToolsPage').then((module) => ({ default: module.ToolsPage })));
const UserDashboardPage = lazy(() => import('@/pages/UserDashboardPage').then((module) => ({ default: module.UserDashboardPage })));

function RouteFallback() {
  return (
    <div className="section-padding">
      <div className="container flex min-h-[36vh] items-center justify-center">
        <Loading label="Loading page" />
      </div>
    </div>
  );
}

export function AppRoutes() {
  return (
    <Suspense fallback={<RouteFallback />}>
      <Routes>
        <Route element={<RootLayout />}>
          <Route index element={<HomePage />} />
          <Route path="tools" element={<ToolsPage />} />
          <Route path="tools/:slug" element={<ToolDetailsPage />} />
          <Route path="categories" element={<CategoriesPage />} />
          <Route path="compare" element={<ComparePage />} />
          <Route path="search" element={<SearchPage />} />
          <Route path="search/results" element={<SearchResultsPage />} />
          <Route path="about" element={<AboutPage />} />
          <Route path="contact" element={<ContactPage />} />
          <Route path="privacy" element={<PrivacyPage />} />
          <Route path="terms" element={<TermsPage />} />
          <Route path="brand" element={<BrandGuidePage />} />

          <Route element={<PublicOnlyRoute />}>
            <Route element={<AuthLayout />}>
              <Route path="login" element={<LoginPage />} />
              <Route path="register" element={<RegisterPage />} />
              <Route path="forgot-password" element={<ForgotPasswordPage />} />
            </Route>
          </Route>

          <Route element={<ProtectedRoute />}>
            <Route element={<DashboardLayout />}>
              <Route path="profile" element={<ProfilePage />} />
              <Route path="favorites" element={<FavoritesPage />} />
              <Route path="my-comparisons" element={<UserComparisonsPage />} />
              <Route path="my-reviews" element={<UserReviewsPage />} />
              <Route path="dashboard" element={<UserDashboardPage />} />
            </Route>
          </Route>

          <Route element={<ProtectedRoute roles={['admin']} />}>
            <Route path="admin" element={<AdminLayout />}>
              <Route index element={<AdminDashboardPage />} />
              <Route path="tools" element={<AdminToolsPage />} />
              <Route path="users" element={<AdminUsersPage />} />
              <Route path="reviews" element={<AdminReviewsPage />} />
              <Route path="messages" element={<AdminMessagesPage />} />
              <Route path="stats" element={<AdminStatsPage />} />
              <Route path="settings" element={<AdminSettingsPage />} />
              <Route path="system" element={<AdminSystemPage />} />
            </Route>
          </Route>

          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
    </Suspense>
  );
}
