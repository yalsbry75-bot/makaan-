/**
 * Firebase Authentication Adapter — AI Hub Arabia
 * Phase 14: Real Services Integration
 *
 * يُغلِّف Firebase Auth ويُوفِّر واجهة موحَّدة لعمليات المصادقة.
 * يُستدعى فقط عندما تكون isFirebaseConfigured() = true.
 */

import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  onAuthStateChanged,
  type User,
  type Auth,
  type Unsubscribe,
} from 'firebase/auth';
import { getFirebaseApp } from './config';

let _auth: Auth | null = null;

/** يُعيد Firebase Auth instance (Singleton) */
export function getFirebaseAuth(): Auth {
  if (!_auth) _auth = getAuth(getFirebaseApp());
  return _auth;
}

/** تسجيل الدخول بالبريد وكلمة المرور */
export async function firebaseSignIn(email: string, password: string): Promise<User> {
  const credential = await signInWithEmailAndPassword(getFirebaseAuth(), email, password);
  return credential.user;
}

/** إنشاء حساب جديد وتحديث الاسم */
export async function firebaseSignUp(email: string, password: string, displayName: string): Promise<User> {
  const credential = await createUserWithEmailAndPassword(getFirebaseAuth(), email, password);
  await updateProfile(credential.user, { displayName });
  // أعِد قراءة المستخدم بعد التحديث
  return credential.user;
}

/** تسجيل الخروج */
export async function firebaseSignOut(): Promise<void> {
  await signOut(getFirebaseAuth());
}

/** إرسال رابط استعادة كلمة المرور */
export async function firebaseSendPasswordReset(email: string): Promise<void> {
  await sendPasswordResetEmail(getFirebaseAuth(), email);
}

/**
 * تغيير كلمة المرور — يتطلب إعادة التحقق من الهوية أولًا.
 * currentPassword: كلمة المرور الحالية
 * newPassword: كلمة المرور الجديدة
 */
export async function firebaseChangePassword(
  user: User,
  currentPassword: string,
  newPassword: string,
): Promise<void> {
  if (!user.email) throw new Error('No email associated with this account.');
  const credential = EmailAuthProvider.credential(user.email, currentPassword);
  await reauthenticateWithCredential(user, credential);
  await updatePassword(user, newPassword);
}

/** تحديث بيانات الملف الشخصي في Firebase Auth */
export async function firebaseUpdateProfile(
  user: User,
  updates: { displayName?: string; photoURL?: string },
): Promise<void> {
  await updateProfile(user, updates);
}

/**
 * الاستماع لتغييرات حالة المصادقة.
 * يُعيد دالة unsubscribe لإيقاف الاستماع.
 */
export function firebaseOnAuthStateChanged(
  callback: (user: User | null) => void,
): Unsubscribe {
  return onAuthStateChanged(getFirebaseAuth(), callback);
}

/** يُعيد المستخدم الحالي من Firebase Auth (null إذا لم يكن مسجلًا) */
export function firebaseCurrentUser(): User | null {
  return getFirebaseAuth().currentUser;
}
