/**
 * Firestore Database Adapter — AI Hub Arabia
 * Phase 14: Real Services Integration
 *
 * يُوفِّر واجهة موحَّدة لعمليات Firestore تطابق واجهة databaseService.ts
 * لضمان التوافق التام عند التحوُّل من localStorage إلى Firestore.
 */

import {
  getFirestore,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  writeBatch,
  type Firestore,
  type DocumentData,
} from 'firebase/firestore';
import { getFirebaseApp } from './config';
import type { CollectionName, DatabaseCollectionMap } from '@/types/database';
import { nowIso } from '@/utils/security';

let _db: Firestore | null = null;

/** يُعيد Firestore instance (Singleton) */
export function getFirestoreDb(): Firestore {
  if (!_db) _db = getFirestore(getFirebaseApp());
  return _db;
}

/** تحويل بيانات Firestore إلى النوع المطلوب */
function fromFirestore<T>(data: DocumentData, id: string): T {
  return { ...data, id } as T;
}

/** قراءة كل السجلات من Collection */
export async function firestoreGetCollection<TCollection extends CollectionName>(
  collectionName: TCollection,
): Promise<Array<DatabaseCollectionMap[TCollection]>> {
  const db = getFirestoreDb();
  const snap = await getDocs(collection(db, collectionName));
  return snap.docs.map((d) =>
    fromFirestore<DatabaseCollectionMap[TCollection]>(d.data(), d.id),
  );
}

/**
 * استبدال كل سجلات Collection بسجلات جديدة (batch write).
 * تحذير: هذه العملية مكلفة — استخدمها فقط عند الضرورة.
 */
export async function firestoreSetCollection<TCollection extends CollectionName>(
  collectionName: TCollection,
  records: Array<DatabaseCollectionMap[TCollection]>,
): Promise<Array<DatabaseCollectionMap[TCollection]>> {
  const db = getFirestoreDb();

  // حدود Firestore: 500 عملية كحد أقصى لكل batch — نستخدم 400 هامشًا للأمان
  const BATCH_LIMIT = 400;

  // حذف السجلات القديمة — تسلسلي (sequential) لتجنب الحالات غير المتسقة
  const existing = await getDocs(collection(db, collectionName));
  for (let i = 0; i < existing.docs.length; i += BATCH_LIMIT) {
    const batch = writeBatch(db);
    existing.docs.slice(i, i + BATCH_LIMIT).forEach((d) => batch.delete(d.ref));
    await batch.commit(); // انتظر اكتمال كل batch قبل البدء بالتالي
  }

  // إضافة السجلات الجديدة — تسلسلي للحفاظ على الاتساق
  for (let i = 0; i < records.length; i += BATCH_LIMIT) {
    const batch = writeBatch(db);
    records.slice(i, i + BATCH_LIMIT).forEach((record) => {
      const recordId = 'id' in record ? String(record.id) : doc(collection(db, collectionName)).id;
      batch.set(doc(db, collectionName, recordId), record as DocumentData);
    });
    await batch.commit(); // انتظر اكتمال كل batch قبل البدء بالتالي
  }

  return records;
}


/** البحث عن سجل واحد يطابق شرطًا */
export async function firestoreFindRecord<TCollection extends CollectionName>(
  collectionName: TCollection,
  predicate: (record: DatabaseCollectionMap[TCollection]) => boolean,
): Promise<DatabaseCollectionMap[TCollection] | null> {
  const records = await firestoreGetCollection(collectionName);
  return records.find(predicate) ?? null;
}

/** إنشاء سجل جديد */
export async function firestoreCreateRecord<TCollection extends CollectionName>(
  collectionName: TCollection,
  record: DatabaseCollectionMap[TCollection],
): Promise<DatabaseCollectionMap[TCollection]> {
  const db = getFirestoreDb();
  const recordId = 'id' in record && record.id ? String(record.id) : doc(collection(db, collectionName)).id;
  const ref = doc(db, collectionName, recordId);
  const finalRecord = { ...record, id: recordId } as DatabaseCollectionMap[TCollection];
  await setDoc(ref, finalRecord as DocumentData);
  return finalRecord;
}

/** تحديث سجل موجود */
export async function firestoreUpdateRecord<TCollection extends CollectionName>(
  collectionName: TCollection,
  id: string,
  patch: Partial<DatabaseCollectionMap[TCollection]>,
): Promise<DatabaseCollectionMap[TCollection]> {
  const db = getFirestoreDb();
  const ref = doc(db, collectionName, id);
  const snap = await getDoc(ref);
  if (!snap.exists()) throw new Error(`Record ${id} not found in ${collectionName}.`);

  const updatedPatch = { ...patch, updatedAt: nowIso() };
  await updateDoc(ref, updatedPatch as DocumentData);

  return fromFirestore<DatabaseCollectionMap[TCollection]>(
    { ...snap.data(), ...updatedPatch },
    id,
  );
}

/** حذف سجل */
export async function firestoreDeleteRecord(
  collectionName: CollectionName,
  id: string,
): Promise<{ deleted: boolean }> {
  const db = getFirestoreDb();
  const ref = doc(db, collectionName, id);
  const snap = await getDoc(ref);
  if (!snap.exists()) return { deleted: false };
  await deleteDoc(ref);
  return { deleted: true };
}
