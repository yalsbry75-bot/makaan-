/**
 * Firebase Configuration — AI Hub Arabia
 * Phase 14: Real Services Integration
 *
 * يُستخدم هذا الملف لتهيئة Firebase App.
 * لتفعيل وضع Firebase، أضف VITE_USE_FIREBASE=true في ملف .env
 * وأكمل باقي المتغيرات من إعدادات مشروع Firebase.
 */

import { initializeApp, getApps, getApp, type FirebaseApp } from 'firebase/app';

/** تحقق من أن جميع متغيرات Firebase مُعرَّفة وأن وضع Firebase مُفعَّل */
export function isFirebaseConfigured(): boolean {
  return (
    import.meta.env.VITE_USE_FIREBASE === 'true' &&
    Boolean(import.meta.env.VITE_FIREBASE_API_KEY) &&
    Boolean(import.meta.env.VITE_FIREBASE_PROJECT_ID)
  );
}

/**
 * يُعيد Firebase App المُهيَّأ مرة واحدة (Singleton).
 * يُقرأ الإعداد من متغيرات البيئة VITE_FIREBASE_*.
 * يجب استدعاؤه فقط عندما تكون isFirebaseConfigured() = true.
 *
 * الـ Singleton يُدار بواسطة Firebase SDK (getApps / getApp) مباشرةً،
 * وهو thread-safe بطبيعته لأن JavaScript single-threaded.
 */
export function getFirebaseApp(): FirebaseApp {
  // استخدم التطبيق الموجود إذا كان مُهيَّأ مسبقًا
  if (getApps().length > 0) return getApp();

  if (!isFirebaseConfigured()) {
    throw new Error(
      '[Firebase] لم يتم إعداد Firebase. تأكد من وجود VITE_FIREBASE_API_KEY وأن VITE_USE_FIREBASE=true في ملف .env',
    );
  }

  return initializeApp({
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
    appId: import.meta.env.VITE_FIREBASE_APP_ID,
    measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID,
  });
}
