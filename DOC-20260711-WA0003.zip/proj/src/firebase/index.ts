/**
 * Firebase Integration — AI Hub Arabia
 * Phase 14: Real Services Integration
 *
 * نقطة التصدير الموحَّدة لطبقة Firebase.
 */

export { isFirebaseConfigured, getFirebaseApp } from './config';

export {
  getFirebaseAuth,
  firebaseSignIn,
  firebaseSignUp,
  firebaseSignOut,
  firebaseSendPasswordReset,
  firebaseChangePassword,
  firebaseUpdateProfile,
  firebaseOnAuthStateChanged,
  firebaseCurrentUser,
} from './auth';

export {
  getFirestoreDb,
  firestoreGetCollection,
  firestoreSetCollection,
  firestoreFindRecord,
  firestoreCreateRecord,
  firestoreUpdateRecord,
  firestoreDeleteRecord,
} from './db';

export {
  getFirebaseStorage,
  uploadAvatar,
  deleteAvatar,
  uploadToolImage,
  uploadPublicAsset,
} from './storage';
