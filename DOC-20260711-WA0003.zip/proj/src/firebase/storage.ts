/**
 * Firebase Storage Adapter — AI Hub Arabia
 * Phase 14: Real Services Integration
 *
 * يُوفِّر وظائف رفع وحذف الملفات عبر Firebase Storage.
 */

import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject,
  type FirebaseStorage,
} from 'firebase/storage';
import { getFirebaseApp } from './config';

let _storage: FirebaseStorage | null = null;

/** يُعيد Firebase Storage instance (Singleton) */
export function getFirebaseStorage(): FirebaseStorage {
  if (!_storage) _storage = getStorage(getFirebaseApp());
  return _storage;
}

/**
 * رفع صورة الملف الشخصي للمستخدم.
 * المسار: avatars/{userId}/avatar.{ext}
 */
export async function uploadAvatar(userId: string, file: File): Promise<string> {
  const storage = getFirebaseStorage();
  const extension = file.name.split('.').pop()?.toLowerCase() ?? 'jpg';
  const avatarRef = ref(storage, `avatars/${userId}/avatar.${extension}`);

  await uploadBytes(avatarRef, file, {
    contentType: file.type,
    customMetadata: { userId, uploadedAt: new Date().toISOString() },
  });

  return getDownloadURL(avatarRef);
}

/**
 * حذف صورة الملف الشخصي.
 * يُتجاهل الخطأ إذا لم يكن الملف موجودًا.
 */
export async function deleteAvatar(avatarUrl: string): Promise<void> {
  const storage = getFirebaseStorage();
  try {
    const avatarRef = ref(storage, avatarUrl);
    await deleteObject(avatarRef);
  } catch {
    // الملف غير موجود أو تم حذفه مسبقًا — لا إجراء مطلوب
  }
}

/**
 * رفع صورة أداة AI.
 * المسار: tools/{toolId}/image.{ext}
 * (للاستخدام في لوحة الإدارة فقط)
 */
export async function uploadToolImage(toolId: string, file: File): Promise<string> {
  const storage = getFirebaseStorage();
  const extension = file.name.split('.').pop()?.toLowerCase() ?? 'jpg';
  const imageRef = ref(storage, `tools/${toolId}/image.${extension}`);

  await uploadBytes(imageRef, file, {
    contentType: file.type,
    customMetadata: { toolId, uploadedAt: new Date().toISOString() },
  });

  return getDownloadURL(imageRef);
}

/**
 * رفع ملف عام (مثل أيقونات أو موارد المنصة).
 * المسار: public/{path}
 */
export async function uploadPublicAsset(path: string, file: File): Promise<string> {
  const storage = getFirebaseStorage();
  const assetRef = ref(storage, `public/${path}`);

  await uploadBytes(assetRef, file, {
    contentType: file.type,
    customMetadata: { uploadedAt: new Date().toISOString() },
  });

  return getDownloadURL(assetRef);
}
