/// <reference types="vite/client" />

declare module '*.css';

/** متغيرات البيئة المدعومة — AI Hub Arabia Phase 14 */
interface ImportMetaEnv {
  // ── وضع Firebase ──────────────────────────────────────────────────────
  /** تفعيل وضع Firebase الحقيقي بدلًا من localStorage (true | false) */
  readonly VITE_USE_FIREBASE: string;

  // ── إعداد مشروع Firebase ──────────────────────────────────────────────
  /** مفتاح API من Firebase Console */
  readonly VITE_FIREBASE_API_KEY: string;
  /** نطاق المصادقة، مثل: my-project.firebaseapp.com */
  readonly VITE_FIREBASE_AUTH_DOMAIN: string;
  /** معرف المشروع، مثل: my-project */
  readonly VITE_FIREBASE_PROJECT_ID: string;
  /** نطاق التخزين، مثل: my-project.appspot.com */
  readonly VITE_FIREBASE_STORAGE_BUCKET: string;
  /** رقم المُرسِل لـ FCM */
  readonly VITE_FIREBASE_MESSAGING_SENDER_ID: string;
  /** معرف التطبيق */
  readonly VITE_FIREBASE_APP_ID: string;
  /** معرف قياس Google Analytics (اختياري) */
  readonly VITE_FIREBASE_MEASUREMENT_ID?: string;

  // ── إعدادات التطبيق ──────────────────────────────────────────────────
  /** رابط الموقع للإنتاج، مثل: https://aihubarabia.com */
  readonly VITE_APP_URL?: string;
  /** اسم البيئة (development | production) */
  readonly VITE_APP_ENV?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
