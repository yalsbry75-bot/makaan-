import { Link } from 'react-router-dom';
import { cn } from '@/utils/cn';

export function BrandLogo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <Link to="/" className={cn('focus-ring inline-flex items-center gap-3 rounded-xl', className)} aria-label="AI Hub Arabia home">
      <span className="grid h-10 w-10 place-items-center rounded-2xl bg-primary text-primary-foreground shadow-card">
        <svg className="h-6 w-6" viewBox="0 0 32 32" fill="none" aria-hidden="true">
          <path d="M7 21c0-7.1 3.9-12.2 9-12.2S25 13.9 25 21" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" />
          <path d="M11 21c0-4.4 2.2-7.4 5-7.4s5 3 5 7.4" stroke="currentColor" strokeOpacity=".65" strokeWidth="2.4" strokeLinecap="round" />
          <circle cx="16" cy="22" r="2.8" fill="#F59E0B" />
          <path d="M8.5 8h15" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
        </svg>
      </span>
      {!compact ? (
        <span className="flex flex-col leading-none">
          <span className="font-display text-base font-extrabold tracking-tight">AI Hub Arabia</span>
          <span className="mt-1 text-xs font-medium text-muted-foreground">SaaS AI Directory</span>
        </span>
      ) : null}
    </Link>
  );
}
