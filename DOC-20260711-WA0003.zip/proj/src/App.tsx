import { useEffect } from 'react';
import { AppRoutes } from '@/routes/AppRoutes';
import { NetworkStatus } from '@/components/system/NetworkStatus';
import { PerformanceMonitor } from '@/components/system/PerformanceMonitor';
import { RouteAnnouncer } from '@/components/system/RouteAnnouncer';
import { initializeDatabase } from '@/services/databaseService';

function runWhenIdle(task: () => void) {
  if ('requestIdleCallback' in window) {
    const idleId = window.requestIdleCallback(task, { timeout: 1600 });
    return () => window.cancelIdleCallback(idleId);
  }
  const timeoutId = globalThis.setTimeout(task, 120);
  return () => globalThis.clearTimeout(timeoutId);
}

export function App() {
  useEffect(() => runWhenIdle(() => {
    initializeDatabase().catch(() => undefined);
  }), []);

  return (
    <>
      <RouteAnnouncer />
      <PerformanceMonitor />
      <NetworkStatus />
      <AppRoutes />
    </>
  );
}
