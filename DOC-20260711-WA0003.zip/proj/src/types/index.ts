import type { ReactNode } from 'react';

export type Locale = 'ar' | 'en';
export type Direction = 'rtl' | 'ltr';
export type ThemeMode = 'light' | 'dark' | 'system';
export type Pricing = 'free' | 'freemium' | 'paid' | 'enterprise';
export type ToolStatus = 'verified' | 'beta' | 'new';
export type ToolVisibilityStatus = 'active' | 'hidden';
export type ToolPlatform = 'web' | 'android' | 'ios' | 'api' | 'desktop';

export type NavItem = {
  labelAr: string;
  labelEn: string;
  href: string;
  icon?: ReactNode;
};

export type ToolCategory = {
  id: string;
  slug: string;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  descriptionEn: string;
  icon: string;
  toolsCount: number;
  growth: string;
  status?: ToolVisibilityStatus;
  createdAt?: string;
  updatedAt?: string;
};

export type ToolMetric = {
  labelAr: string;
  labelEn: string;
  value: string;
};

export type AITool = {
  id: string;
  slug: string;
  name: string;
  taglineAr: string;
  taglineEn: string;
  descriptionAr: string;
  descriptionEn: string;
  fullDescriptionAr?: string;
  fullDescriptionEn?: string;
  categorySlug: string;
  pricing: Pricing;
  platform?: ToolPlatform[];
  rating: number;
  reviewsCount?: number;
  users: string;
  tags: string[];
  featured?: boolean;
  verified?: boolean;
  status?: ToolStatus;
  visibilityStatus?: ToolVisibilityStatus;
  logoGradient: string;
  logoUrl?: string;
  website: string;
  launchYear: string;
  addedAt?: string;
  lastUpdatedAt?: string;
  supportedLanguages: string[];
  useCasesAr: string[];
  useCasesEn: string[];
  featuresAr: string[];
  featuresEn: string[];
  integrations: string[];
  metrics: ToolMetric[];
};

export type ComparisonItem = Pick<AITool, 'id' | 'slug' | 'name' | 'pricing' | 'rating' | 'tags' | 'categorySlug'> & {
  strengthsAr: string[];
  strengthsEn: string[];
  bestForAr: string;
  bestForEn: string;
  limitsAr: string;
  limitsEn: string;
};

export type Metric = {
  labelAr: string;
  labelEn: string;
  value: string;
};

export type DashboardStat = {
  labelAr: string;
  labelEn: string;
  value: string;
  change: string;
};
