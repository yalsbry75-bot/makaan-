import type { AITool, ComparisonItem, Pricing, ToolCategory, ToolPlatform, ToolVisibilityStatus } from '@/types';
import type { StoredUser } from '@/types/auth';

export type CollectionName =
  | 'users'
  | 'tools'
  | 'categories'
  | 'favorites'
  | 'reviews'
  | 'comparisons'
  | 'settings'
  | 'contactMessages'
  | 'reports'
  | 'notifications'
  | 'auditLogs';

export type BaseRecord = {
  id: string;
  createdAt: string;
  updatedAt: string;
};

export type FavoriteRecord = BaseRecord & {
  userId: string;
  toolId: string;
};

export type ReviewRecord = BaseRecord & {
  userId: string;
  toolId: string;
  rating: number;
  title: string;
  comment: string;
  status: 'pending' | 'approved' | 'rejected';
};

export type ComparisonRecord = BaseRecord & {
  userId: string;
  name: string;
  toolIds: string[];
};

export type PlatformSettingsRecord = BaseRecord & {
  key: string;
  value: string | number | boolean | Record<string, unknown> | string[];
};

export type ContactMessageRecord = BaseRecord & {
  name: string;
  email: string;
  message: string;
  status: 'new' | 'read' | 'closed';
};

export type ReportRecord = BaseRecord & {
  reporterId: string;
  targetType: 'tool' | 'review' | 'user';
  targetId: string;
  reason: string;
  status: 'open' | 'investigating' | 'resolved';
};

export type NotificationRecord = BaseRecord & {
  userId: string;
  titleAr: string;
  titleEn: string;
  bodyAr: string;
  bodyEn: string;
  read: boolean;
  type: 'system' | 'favorite' | 'review' | 'security';
};


export type AuditLogRecord = BaseRecord & {
  actorId?: string;
  event: string;
  severity: 'info' | 'warning' | 'critical';
  resource?: string;
  metadata?: Record<string, string | number | boolean | null>;
};

export type DatabaseSchema = {
  users: StoredUser[];
  tools: AITool[];
  categories: ToolCategory[];
  favorites: FavoriteRecord[];
  reviews: ReviewRecord[];
  comparisons: ComparisonRecord[];
  settings: PlatformSettingsRecord[];
  contactMessages: ContactMessageRecord[];
  reports: ReportRecord[];
  notifications: NotificationRecord[];
  auditLogs: AuditLogRecord[];
};

export type DatabaseCollectionMap = {
  users: StoredUser;
  tools: AITool;
  categories: ToolCategory;
  favorites: FavoriteRecord;
  reviews: ReviewRecord;
  comparisons: ComparisonRecord;
  settings: PlatformSettingsRecord;
  contactMessages: ContactMessageRecord;
  reports: ReportRecord;
  notifications: NotificationRecord;
  auditLogs: AuditLogRecord;
};

export type ToolSortOption = 'relevance' | 'top-rated' | 'newest' | 'most-used' | 'name' | 'featured';

export type ToolQueryParams = {
  search?: string;
  keyword?: string;
  category?: string;
  pricing?: Pricing | 'all' | string;
  platform?: ToolPlatform | 'all' | string;
  tag?: string;
  tags?: string[];
  status?: ToolVisibilityStatus | 'all' | string;
  featured?: boolean;
  minRating?: number;
  sort?: ToolSortOption;
  limit?: number;
  page?: number;
  pageSize?: number;
};

export type ToolSearchResult = {
  items: AITool[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

export type DashboardData = {
  stats: Array<{ labelAr: string; labelEn: string; value: string; change: string }>;
  recentActivity: Array<{ ar: string; en: string; time: string }>;
  recommendedTools: AITool[];
  notifications: NotificationRecord[];
};

export type AdminDashboardData = {
  tools: AITool[];
  categories: ToolCategory[];
  reviews: ReviewRecord[];
  users: StoredUser[];
  contactMessages: ContactMessageRecord[];
  reports: ReportRecord[];
};

export type { ComparisonItem };
