export type UserRole = 'user' | 'admin';
export type AccountStatus = 'active' | 'locked';
export type AuthStatus = 'loading' | 'authenticated' | 'guest';

export type UserPreferences = {
  locale: 'ar' | 'en';
  theme: 'light' | 'dark' | 'system';
  newsletter: boolean;
  productUpdates: boolean;
};

export type AuthUser = {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: AccountStatus;
  avatarUrl?: string;
  title?: string;
  company?: string;
  bio?: string;
  createdAt: string;
  updatedAt: string;
  preferences: UserPreferences;
};

export type StoredUser = AuthUser & {
  passwordHash: string;
};

export type AuthSession = {
  user: AuthUser;
  token: string;
  remember: boolean;
  issuedAt: string;
  expiresAt: string;
};

export type SignInPayload = {
  email: string;
  password: string;
  remember?: boolean;
};

export type SignUpPayload = {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
};

export type PasswordResetPayload = {
  email: string;
};

export type ProfileUpdatePayload = {
  name: string;
  email: string;
  title?: string;
  company?: string;
  bio?: string;
  avatarUrl?: string;
};

export type PasswordChangePayload = {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
};

export type AccountSettingsPayload = {
  newsletter: boolean;
  productUpdates: boolean;
};

export type FieldErrors<T extends string = string> = Partial<Record<T, string>>;

export class AuthServiceError<T extends string = string> extends Error {
  code: string;
  fieldErrors: FieldErrors<T>;

  constructor(message: string, code = 'AUTH_ERROR', fieldErrors: FieldErrors<T> = {}) {
    super(message);
    this.name = 'AuthServiceError';
    this.code = code;
    this.fieldErrors = fieldErrors;
  }
}
