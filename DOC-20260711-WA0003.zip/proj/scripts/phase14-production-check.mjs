#!/usr/bin/env node
/**
 * Phase 14 Production Check — AI Hub Arabia
 * يتحقق من جاهزية ملفات Firebase وإعدادات الإنتاج للمرحلة الرابعة عشرة.
 */

import { readFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(__dirname, '..');

let passed = 0;
let failed = 0;

function check(label, condition, hint = '') {
  if (condition) {
    console.log(`  ✅ ${label}`);
    passed++;
  } else {
    console.log(`  ❌ ${label}${hint ? `\n     → ${hint}` : ''}`);
    failed++;
  }
}

function fileExists(rel) {
  return existsSync(resolve(ROOT, rel));
}

function fileContains(rel, ...patterns) {
  if (!fileExists(rel)) return false;
  const content = readFileSync(resolve(ROOT, rel), 'utf8');
  return patterns.every((p) => content.includes(p));
}

console.log('\n══════════════════════════════════════════════════════════');
console.log('  AI Hub Arabia — Phase 14 Production Check');
console.log('══════════════════════════════════════════════════════════\n');

// ── ملفات Firebase الأساسية ──────────────────────────────────────────────────
console.log('📦 ملفات Firebase الأساسية:');
check(
  'src/firebase/config.ts موجود',
  fileExists('src/firebase/config.ts'),
  'أنشئ ملف Firebase config',
);
check(
  'src/firebase/auth.ts موجود',
  fileExists('src/firebase/auth.ts'),
  'أنشئ ملف Firebase Auth adapter',
);
check(
  'src/firebase/db.ts موجود',
  fileExists('src/firebase/db.ts'),
  'أنشئ ملف Firestore adapter',
);
check(
  'src/firebase/storage.ts موجود',
  fileExists('src/firebase/storage.ts'),
  'أنشئ ملف Firebase Storage adapter',
);
check(
  'src/firebase/index.ts موجود',
  fileExists('src/firebase/index.ts'),
  'أنشئ barrel export لـ Firebase',
);

// ── ملفات قواعد الأمان ──────────────────────────────────────────────────────
console.log('\n🔒 قواعد الأمان:');
check(
  'firestore.rules موجود',
  fileExists('firestore.rules'),
  'أنشئ ملف Firestore security rules',
);
check(
  'firestore.rules يحتوي على قواعد users',
  fileContains('firestore.rules', 'match /users/{userId}'),
  'أضف قواعد collection users',
);
check(
  'firestore.rules يحتوي على قواعد reviews',
  fileContains('firestore.rules', 'match /reviews/{reviewId}'),
  'أضف قواعد collection reviews',
);
check(
  'firestore.rules يحتوي على قواعد favorites',
  fileContains('firestore.rules', 'match /favorites/{favoriteId}'),
  'أضف قواعد collection favorites',
);
check(
  'storage.rules موجود',
  fileExists('storage.rules'),
  'أنشئ ملف Storage security rules',
);
check(
  'storage.rules يحتوي على قواعد الصور الشخصية',
  fileContains('storage.rules', 'match /avatars/{userId}'),
  'أضف قواعد مجلد avatars',
);

// ── إعداد Firebase Hosting ────────────────────────────────────────────────────
console.log('\n🌐 Firebase Hosting:');
check(
  'firebase.json موجود',
  fileExists('firebase.json'),
  'أنشئ ملف firebase.json',
);
check(
  'firebase.json يحتوي على hosting config',
  fileContains('firebase.json', '"hosting"', '"rewrites"'),
  'أضف hosting + rewrites إلى firebase.json',
);
check(
  'firebase.json يحتوي على firestore config',
  fileContains('firebase.json', '"firestore"'),
  'أضف Firestore config إلى firebase.json',
);
check(
  'firestore.indexes.json موجود',
  fileExists('firestore.indexes.json'),
  'أنشئ ملف Firestore indexes',
);
check(
  '.firebaserc موجود',
  fileExists('.firebaserc'),
  'أنشئ .firebaserc وأضف project ID',
);

// ── متغيرات البيئة ───────────────────────────────────────────────────────────
console.log('\n🔑 متغيرات البيئة:');
check(
  '.env.example موجود',
  fileExists('.env.example'),
  'أنشئ ملف .env.example',
);
check(
  '.env.example يحتوي على VITE_FIREBASE_API_KEY',
  fileContains('.env.example', 'VITE_FIREBASE_API_KEY'),
  'أضف متغيرات Firebase إلى .env.example',
);
check(
  '.env.example يحتوي على VITE_USE_FIREBASE',
  fileContains('.env.example', 'VITE_USE_FIREBASE'),
  'أضف VITE_USE_FIREBASE إلى .env.example',
);
check(
  '.env غير موجود في المستودع (محمي بـ .gitignore)',
  !fileExists('.env') || fileContains('.gitignore', '.env'),
  'تأكد من إضافة .env إلى .gitignore',
);
check(
  'vite-env.d.ts يُعرِّف أنواع متغيرات البيئة',
  fileContains('src/vite-env.d.ts', 'VITE_FIREBASE_API_KEY', 'VITE_USE_FIREBASE'),
  'أضف أنواع TypeScript لمتغيرات Firebase',
);

// ── تكامل الكود ──────────────────────────────────────────────────────────────
console.log('\n🔗 تكامل الكود:');
check(
  'databaseService.ts يدعم Firestore',
  fileContains('src/services/databaseService.ts', 'isFirebaseConfigured', 'firestoreGetCollection'),
  'أضف دعم Firestore إلى databaseService',
);
check(
  'authService.ts يدعم Firebase Auth',
  fileContains('src/services/authService.ts', 'isFirebaseConfigured', 'firebaseSignIn'),
  'أضف دعم Firebase Auth إلى authService',
);
check(
  'AuthContext.tsx يستخدم onAuthStateChanged',
  fileContains('src/contexts/AuthContext.tsx', 'firebaseOnAuthStateChanged', 'isFirebaseConfigured'),
  'أضف Firebase listener إلى AuthContext',
);
check(
  'firebase مُضافة إلى package.json',
  fileContains('package.json', '"firebase"'),
  'أضف firebase إلى dependencies في package.json',
);

// ── أمان الإنتاج ─────────────────────────────────────────────────────────────
console.log('\n🛡️ أمان الإنتاج:');
check(
  'vite.config.ts يتضمن CSP لـ Firebase',
  fileContains('vite.config.ts', 'googleapis.com', 'firebaseio.com'),
  'أضف نطاقات Firebase إلى Content-Security-Policy',
);
check(
  'vite.config.ts يُنشئ chunk منفصل لـ Firebase',
  fileContains('vite.config.ts', "'firebase'"),
  'أضف Firebase chunk إلى manualChunks',
);
check(
  '.gitignore يُخفي ملفات .env',
  fileContains('.gitignore', '.env'),
  'أضف .env إلى .gitignore',
);
check(
  'التوثيق مُحدَّث لمرحلة Firebase',
  fileContains('DEPLOYMENT.md', 'Firebase') || fileExists('PHASE_14_REPORT.md'),
  'أضف توثيق Firebase إلى DEPLOYMENT.md أو PHASE_14_REPORT.md',
);

// ── الملخص ──────────────────────────────────────────────────────────────────
const total = passed + failed;
const percent = Math.round((passed / total) * 100);

console.log('\n══════════════════════════════════════════════════════════');
console.log(`  النتيجة: ${passed}/${total} (${percent}%)`);

if (failed === 0) {
  console.log('  🎉 المرحلة الرابعة عشرة اجتازت جميع الفحوصات!');
  console.log('  ✅ المشروع جاهز لربط Firebase وإطلاق الإنتاج.');
} else if (percent >= 70) {
  console.log(`  ⚠️  ${failed} بند ناقص — راجع التفاصيل أعلاه.`);
} else {
  console.log(`  ❌  ${failed} بند ناقص — يلزم مراجعة إعداد Firebase.`);
}

console.log('══════════════════════════════════════════════════════════\n');

process.exit(failed > 0 ? 1 : 0);
