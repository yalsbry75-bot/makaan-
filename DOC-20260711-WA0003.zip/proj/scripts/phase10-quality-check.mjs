import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const failures = [];
const checks = [];

function pass(name) {
  checks.push({ name, status: 'PASS' });
}

function fail(name, detail) {
  checks.push({ name, status: 'FAIL', detail });
  failures.push(`${name}: ${detail}`);
}

function assert(condition, name, detail = 'Requirement was not met') {
  if (condition) pass(name);
  else fail(name, detail);
}

function file(path) {
  return readFileSync(join(root, path), 'utf8');
}

function exists(path) {
  return existsSync(join(root, path));
}

function listFiles(dir) {
  const absoluteDir = join(root, dir);
  const output = [];
  for (const item of readdirSync(absoluteDir)) {
    const absolute = join(absoluteDir, item);
    const relative = join(dir, item);
    if (statSync(absolute).isDirectory()) output.push(...listFiles(relative));
    else output.push(relative);
  }
  return output;
}

const requiredPages = [
  'HomePage.tsx',
  'ToolsPage.tsx',
  'CategoriesPage.tsx',
  'ToolDetailsPage.tsx',
  'ComparePage.tsx',
  'SearchPage.tsx',
  'SearchResultsPage.tsx',
  'LoginPage.tsx',
  'RegisterPage.tsx',
  'ForgotPasswordPage.tsx',
  'ProfilePage.tsx',
  'FavoritesPage.tsx',
  'UserDashboardPage.tsx',
  'AdminDashboardPage.tsx',
  'AdminToolsPage.tsx',
  'AdminUsersPage.tsx',
  'AdminReviewsPage.tsx',
  'AdminMessagesPage.tsx',
  'AdminStatsPage.tsx',
  'AdminSettingsPage.tsx',
  'AboutPage.tsx',
  'ContactPage.tsx',
  'PrivacyPage.tsx',
  'TermsPage.tsx',
  'NotFoundPage.tsx',
];

for (const page of requiredPages) {
  assert(exists(`src/pages/${page}`), `page exists: ${page}`);
}

const routes = file('src/routes/AppRoutes.tsx');
for (const path of ['tools', 'categories', 'compare', 'search', 'search/results', 'login', 'register', 'forgot-password', 'profile', 'favorites', 'dashboard', 'admin', 'about', 'contact', 'privacy', 'terms']) {
  assert(routes.includes(`path="${path}"`) || (path === 'admin' && routes.includes('path="admin"')), `route registered: /${path}`);
}
assert(routes.includes('<ProtectedRoute />') && routes.includes("roles={['admin']}"), 'protected routes and admin authorization are configured');

const services = [
  'src/services/authService.ts',
  'src/services/toolService.ts',
  'src/services/searchService.ts',
  'src/services/favoriteService.ts',
  'src/services/comparisonService.ts',
  'src/services/reviewService.ts',
  'src/services/securityService.ts',
  'src/services/adminService.ts',
];
for (const service of services) assert(exists(service), `service exists: ${service}`);

const authService = file('src/services/authService.ts');
assert(authService.includes('MAX_LOGIN_ATTEMPTS') && authService.includes('assertLoginAllowed'), 'login rate limiting is present');
assert(authService.includes('hashPassword') && authService.includes('sanitizeText'), 'auth hashing and sanitization are present');

const toolDetails = file('src/pages/ToolDetailsPage.tsx');
assert(toolDetails.includes('handleShare') && toolDetails.includes('navigator.share') && toolDetails.includes('navigator.clipboard'), 'tool sharing and copy link are implemented');
assert(toolDetails.includes('createReview') && toolDetails.includes('updateUserReview') && toolDetails.includes('reportReview'), 'review create/update/report flows are implemented');

const compare = file('src/pages/ComparePage.tsx');
assert(compare.includes('saveComparison') && compare.includes('selectedIds') && compare.includes('sharedTags'), 'comparison flow is implemented');

const searchBar = file('src/components/ui/SearchBar.tsx');
assert(searchBar.includes('role="combobox"') && searchBar.includes('aria-controls') && searchBar.includes('getSearchSuggestions'), 'accessible smart search suggestions are implemented');

const rootLayout = file('src/layouts/RootLayout.tsx');
assert(rootLayout.includes('href="#main-content"') && rootLayout.includes('tabIndex={-1}'), 'skip link and main-content focus target are present');

const app = file('src/App.tsx');
assert(app.includes('RouteAnnouncer') && app.includes('NetworkStatus') && app.includes('PerformanceMonitor'), 'phase 10 UX/a11y/performance system components are mounted');

for (const publicFile of ['public/manifest.webmanifest', 'public/sw.js', 'public/offline.html', 'public/sitemap.xml', 'public/robots.txt', 'public/icons/brand-mark.svg']) {
  assert(exists(publicFile), `PWA/SEO asset exists: ${publicFile}`);
}

const index = file('index.html');
for (const token of ['og:title', 'og:description', 'twitter:card', 'application/ld+json', 'canonical']) {
  assert(index.includes(token), `SEO token present: ${token}`);
}

const css = file('src/styles/globals.css');
assert(css.includes('prefers-reduced-motion') && css.includes('forced-colors'), 'reduced motion and high contrast accessibility CSS are present');

const sourceFiles = listFiles('src').filter((path) => /\.(ts|tsx|css)$/.test(path));
const forbiddenPattern = /TODO|FIXME|console\.log|debugger/i;
const offenders = sourceFiles.filter((path) => forbiddenPattern.test(file(path)));
assert(offenders.length === 0, 'no TODO/FIXME/console.log/debugger in source', offenders.join(', '));

const seedData = file('src/constants/catalogSeed.ts');
const toolCount = (seedData.match(/id:\s*'tool-/g) ?? []).length;
const categoryCount = (seedData.match(/id:\s*'cat-/g) ?? []).length;
assert(toolCount >= 60, 'seed library contains at least 60 AI tools', `found ${toolCount}`);
assert(categoryCount >= 14, 'seed library contains at least 14 categories', `found ${categoryCount}`);

const distExists = exists('dist/index.html');
assert(distExists, 'production build output exists');
if (distExists) {
  const distAssets = listFiles('dist/assets');
  const largeAssets = distAssets
    .map((asset) => ({ asset, size: statSync(join(root, asset)).size }))
    .filter(({ size }) => size > 350 * 1024);
  assert(largeAssets.length === 0, 'no production JS/CSS asset exceeds 350KB raw', largeAssets.map(({ asset, size }) => `${asset}:${size}`).join(', '));
}

console.table(checks);
if (failures.length) {
  console.error('\nPhase 10 quality check failed:\n' + failures.map((item) => `- ${item}`).join('\n'));
  process.exit(1);
}
console.log(`\nPhase 10 quality check passed (${checks.length} checks).`);
