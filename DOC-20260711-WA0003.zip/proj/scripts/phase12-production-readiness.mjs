import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const failures = [];
const checks = [];

function file(path) {
  return readFileSync(join(root, path), 'utf8');
}

function exists(path) {
  return existsSync(join(root, path));
}

function listFiles(dir) {
  const absoluteDir = join(root, dir);
  if (!existsSync(absoluteDir)) return [];
  const output = [];
  for (const item of readdirSync(absoluteDir)) {
    const absolute = join(absoluteDir, item);
    const relative = join(dir, item);
    if (statSync(absolute).isDirectory()) output.push(...listFiles(relative));
    else output.push(relative);
  }
  return output;
}

function assert(condition, name, detail = 'Requirement was not met') {
  checks.push({ name, status: condition ? 'PASS' : 'FAIL', detail: condition ? '' : detail });
  if (!condition) failures.push(`${name}: ${detail}`);
}

const docs = ['README.md', 'INSTALL.md', 'PROJECT_STRUCTURE.md', 'DEPLOYMENT.md', 'CHANGELOG.md', 'PHASE_12_REPORT.md'];
for (const doc of docs) assert(exists(doc), `production documentation exists: ${doc}`);

const packageJson = JSON.parse(file('package.json'));
assert(['1.0.0', '1.0.1'].includes(packageJson.version), 'package version is production-ready 1.0.x', `found ${packageJson.version}`);
assert(Boolean(packageJson.scripts['test:phase12']), 'phase 12 readiness script is registered');
assert(packageJson.scripts['test:all']?.includes('test:phase12'), 'full test suite includes phase 12 readiness');
assert(packageJson.engines?.node?.includes('20'), 'Node 20+ engine is declared');

const databaseService = file('src/services/databaseService.ts');
assert((databaseService.includes('ai-hub-arabia-database-v12') || databaseService.includes('ai-hub-arabia-database-v13')) && (databaseService.includes("DATABASE_VERSION = '12.0.0'") || databaseService.includes("DATABASE_VERSION = '13.0.0'")), 'database adapter is phase 12 ready or later');
assert(databaseService.includes('ai-hub-arabia-database-v11'), 'database adapter migrates phase 11 data');

const productionConfig = file('src/config/production.ts');
for (const token of ['productionReadinessChecklist', 'protected-routes', 'manual-chunks', 'developer-docs']) {
  assert(productionConfig.includes(token), `production config includes ${token}`);
}

const vite = file('vite.config.ts');
assert(vite.includes('manualChunks') && vite.includes('sourcemap: false') && vite.includes('chunkSizeWarningLimit'), 'production build optimization is configured');

const routes = file('src/routes/AppRoutes.tsx');
for (const token of ['lazy(() => import', 'ProtectedRoute roles', 'AdminSystemPage', 'UserComparisonsPage', 'UserReviewsPage']) {
  assert(routes.includes(token), `route configuration includes ${token}`);
}

const protectedRoute = file('src/components/auth/ProtectedRoute.tsx');
assert(protectedRoute.includes('permission_denied') && protectedRoute.includes('<Navigate'), 'protected route authorization redirects and audits denied access');

const authService = file('src/services/authService.ts');
for (const token of ['MAX_LOGIN_ATTEMPTS', 'LOGIN_WINDOW_MS', 'validateSignIn', 'validateSignUp', 'sanitizeText', 'session_expired']) {
  assert(authService.includes(token), `auth security includes ${token}`);
}

const searchService = file('src/services/searchService.ts');
assert(searchService.includes('editDistance') && searchService.includes('tokenMatchesQuery') && searchService.includes('closestDictionaryTerm'), 'smart search typo tolerance and suggestion scoring helpers are present');

for (const publicFile of ['public/manifest.webmanifest', 'public/sw.js', 'public/offline.html', 'public/sitemap.xml', 'public/robots.txt', 'public/icons/brand-mark.svg']) {
  assert(exists(publicFile), `production public asset exists: ${publicFile}`);
}

const manifest = JSON.parse(file('public/manifest.webmanifest'));
assert(manifest.display === 'standalone' && manifest.icons?.length >= 1 && manifest.shortcuts?.length >= 2, 'PWA manifest has install metadata, icons, and shortcuts');
assert(['1.0.0', '1.0.1'].includes(manifest.version), 'PWA manifest carries release version');

const sw = file('public/sw.js');
assert((sw.includes("CACHE_VERSION = 'v12'") || sw.includes("CACHE_VERSION = 'v13'")) && sw.includes('offline.html') && sw.includes('staleWhileRevalidate') && sw.includes('networkFirst'), 'service worker has phase 12+ caching and offline strategy');

const index = file('index.html');
for (const token of ['og:title', 'twitter:card', 'application/ld+json', 'canonical', 'Permissions-Policy', 'apple-mobile-web-app-capable']) {
  assert(index.includes(token), `index SEO/PWA metadata includes ${token}`);
}

const rootLayout = file('src/layouts/RootLayout.tsx');
assert(rootLayout.includes('href="#main-content"') && rootLayout.includes('tabIndex={-1}'), 'skip link and main landmark are available');

const app = file('src/App.tsx');
for (const token of ['RouteAnnouncer', 'NetworkStatus', 'PerformanceMonitor', 'initializeDatabase']) {
  assert(app.includes(token), `app shell includes ${token}`);
}

const sourceFiles = listFiles('src').filter((path) => /\.(ts|tsx|css)$/.test(path));
const forbiddenPattern = /TODO|FIXME|console\.log|debugger/i;
const offenders = sourceFiles.filter((path) => forbiddenPattern.test(file(path)));
assert(offenders.length === 0, 'no TODO/FIXME/console.log/debugger in source', offenders.join(', '));

const pageFiles = listFiles('src/pages').filter((path) => path.endsWith('Page.tsx'));
assert(pageFiles.length >= 29, 'all major public, user, and admin pages are present', `found ${pageFiles.length}`);

const seedData = file('src/constants/catalogSeed.ts');
const toolCount = (seedData.match(/id:\s*'tool-/g) ?? []).length;
const categoryCount = (seedData.match(/id:\s*'cat-/g) ?? []).length;
assert(toolCount >= 60, 'seed library has production content baseline', `found ${toolCount} tools`);
assert(categoryCount >= 14, 'category library has production content baseline', `found ${categoryCount} categories`);

assert(exists('dist/index.html'), 'production build output exists');
if (exists('dist/assets')) {
  const largeAssets = listFiles('dist/assets')
    .map((asset) => ({ asset, size: statSync(join(root, asset)).size }))
    .filter(({ size }) => size > 700 * 1024);
  assert(largeAssets.length === 0, 'production assets stay under configured raw size threshold', largeAssets.map(({ asset, size }) => `${asset}:${size}`).join(', '));
}

console.table(checks.map(({ name, status, detail }) => ({ name, status, detail })));
if (failures.length) {
  console.error('\nPhase 12 production readiness check failed:\n' + failures.map((item) => `- ${item}`).join('\n'));
  process.exit(1);
}
console.log(`\nPhase 12 production readiness check passed (${checks.length} checks).`);
