import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const failures = [];
const checks = [];

function file(path) {
  return readFileSync(join(root, path), 'utf8');
}

function exists(path) {
  return existsSync(join(root, path));
}

function listFiles(dir) {
  const absoluteDir = join(root, dir);
  if (!existsSync(absoluteDir)) return [];
  const output = [];
  for (const item of readdirSync(absoluteDir)) {
    const absolute = join(absoluteDir, item);
    const relative = join(dir, item);
    if (statSync(absolute).isDirectory()) output.push(...listFiles(relative));
    else output.push(relative);
  }
  return output;
}

function assert(condition, name, detail = 'Requirement was not met') {
  checks.push({ name, status: condition ? 'PASS' : 'FAIL', detail: condition ? '' : detail });
  if (!condition) failures.push(`${name}: ${detail}`);
}

const requiredDocs = ['README.md', 'INSTALL.md', 'PROJECT_STRUCTURE.md', 'DEPLOYMENT.md', 'CHANGELOG.md', 'PHASE_13_FINAL_REPORT.md'];
for (const doc of requiredDocs) assert(exists(doc), `final documentation exists: ${doc}`);

const packageJson = JSON.parse(file('package.json'));
assert(packageJson.version === '1.0.1', 'final package version is 1.0.1', `found ${packageJson.version}`);
assert(Boolean(packageJson.scripts['test:phase13']), 'phase 13 final review script is registered');
assert(packageJson.scripts['test:all']?.includes('test:phase13'), 'full test suite includes phase 13 final review');
assert(packageJson.engines?.node?.includes('20'), 'Node 20+ engine requirement remains declared');

const routes = file('src/routes/AppRoutes.tsx');
const routeTokens = ['tools/:slug', 'categories', 'compare', 'search/results', 'profile', 'favorites', 'my-comparisons', 'my-reviews', 'dashboard', 'admin', 'admin" element={<AdminLayout', 'AdminSystemPage'];
for (const token of routeTokens) assert(routes.includes(token), `route configuration includes ${token}`);
assert(routes.includes('ProtectedRoute roles') || routes.includes("roles={['admin']}"), 'admin routes remain role-protected');

const requiredPages = [
  'HomePage.tsx', 'ToolsPage.tsx', 'ToolDetailsPage.tsx', 'CategoriesPage.tsx', 'ComparePage.tsx', 'SearchPage.tsx', 'SearchResultsPage.tsx',
  'LoginPage.tsx', 'RegisterPage.tsx', 'ForgotPasswordPage.tsx', 'ProfilePage.tsx', 'FavoritesPage.tsx', 'UserDashboardPage.tsx',
  'UserComparisonsPage.tsx', 'UserReviewsPage.tsx', 'AdminDashboardPage.tsx', 'AdminToolsPage.tsx', 'AdminUsersPage.tsx',
  'AdminReviewsPage.tsx', 'AdminMessagesPage.tsx', 'AdminStatsPage.tsx', 'AdminSettingsPage.tsx', 'AdminSystemPage.tsx',
  'AboutPage.tsx', 'ContactPage.tsx', 'PrivacyPage.tsx', 'TermsPage.tsx', 'NotFoundPage.tsx', 'BrandGuidePage.tsx',
];
for (const page of requiredPages) assert(exists(`src/pages/${page}`), `final page exists: ${page}`);

const requiredServices = [
  'authService.ts', 'databaseService.ts', 'toolService.ts', 'searchService.ts', 'favoriteService.ts', 'comparisonService.ts',
  'reviewService.ts', 'adminService.ts', 'settingsService.ts', 'securityService.ts', 'systemHealthService.ts', 'userWorkspaceService.ts',
  'contactService.ts', 'reportService.ts', 'notificationService.ts',
];
for (const service of requiredServices) assert(exists(`src/services/${service}`), `final service exists: ${service}`);

const databaseService = file('src/services/databaseService.ts');
assert(databaseService.includes('ai-hub-arabia-database-v13') && databaseService.includes("DATABASE_VERSION = '13.0.0'"), 'database adapter is bumped to final phase 13');
assert(databaseService.includes('ai-hub-arabia-database-v12') && databaseService.includes('ai-hub-arabia-database-v11'), 'database adapter migrates previous release data');

const productionConfig = file('src/config/production.ts');
for (const token of ["version: '1.0.1'", 'phase: 13', 'final-delivery-audit', 'protected-routes', 'manual-chunks', 'developer-docs']) {
  assert(productionConfig.includes(token), `production configuration includes ${token}`);
}

const authService = file('src/services/authService.ts');
for (const token of ['MAX_LOGIN_ATTEMPTS', 'LOGIN_WINDOW_MS', 'validateSignIn', 'validateSignUp', 'sanitizeText', 'session_expired']) {
  assert(authService.includes(token), `authentication security includes ${token}`);
}

const searchService = file('src/services/searchService.ts');
for (const token of ['getSearchSuggestions', 'editDistance', 'tokenMatchesQuery', 'closestDictionaryTerm']) {
  assert(searchService.includes(token), `smart search includes ${token}`);
}
assert(file('src/pages/SearchResultsPage.tsx').includes('searchToolsAdvanced') && file('src/pages/SearchResultsPage.tsx').includes('sort'), 'search results page connects to advanced catalog query and sorting');

const comparePage = file('src/pages/ComparePage.tsx');
assert(comparePage.includes('useSearchParams') && comparePage.includes('searchParams.getAll') && comparePage.includes('removeTool'), 'comparison page supports query-based selection and removal');

const favoritesPage = file('src/pages/FavoritesPage.tsx');
assert(favoritesPage.includes('getUserFavorites') && favoritesPage.includes('toggleFavorite') && favoritesPage.includes('handleRemoveFavorite'), 'favorites page is connected to user favorites service');

const toolDetails = file('src/pages/ToolDetailsPage.tsx');
for (const token of ['createReview', 'updateUserReview', 'deleteUserReview', 'reportReview', 'clipboard', 'navigator.share']) {
  assert(toolDetails.includes(token), `tool details supports ${token}`);
}

const vite = file('vite.config.ts');
assert(vite.includes('manualChunks') && vite.includes('sourcemap: false') && vite.includes('chunkSizeWarningLimit'), 'production build optimization remains configured');

const manifest = JSON.parse(file('public/manifest.webmanifest'));
assert(manifest.version === '1.0.1' && manifest.display === 'standalone' && manifest.icons?.length >= 1 && manifest.shortcuts?.length >= 2, 'PWA manifest is final and installable');
const sw = file('public/sw.js');
assert(sw.includes("CACHE_VERSION = 'v13'") && sw.includes('offline.html') && sw.includes('staleWhileRevalidate') && sw.includes('networkFirst'), 'service worker uses final cache version and offline strategies');

const index = file('index.html');
for (const token of ['og:title', 'og:description', 'twitter:card', 'application/ld+json', 'canonical', 'Permissions-Policy']) {
  assert(index.includes(token), `SEO/security metadata includes ${token}`);
}

const rootLayout = file('src/layouts/RootLayout.tsx');
assert(rootLayout.includes('href="#main-content"') && rootLayout.includes('tabIndex={-1}'), 'accessibility skip link and focus target remain available');
const app = file('src/App.tsx');
const main = file('src/main.tsx');
assert(main.includes('ErrorBoundary'), 'root render tree includes ErrorBoundary');
for (const token of ['RouteAnnouncer', 'NetworkStatus', 'PerformanceMonitor', 'initializeDatabase']) {
  assert(app.includes(token), `application shell includes ${token}`);
}

const sourceFiles = listFiles('src').filter((path) => /\.(ts|tsx|css)$/.test(path));
const forbiddenPattern = /TODO|FIXME|console\.log|debugger/i;
const offenders = sourceFiles.filter((path) => forbiddenPattern.test(file(path)));
assert(offenders.length === 0, 'no TODO/FIXME/console.log/debugger in source', offenders.join(', '));

const allProjectFiles = listFiles('.');
const forbiddenFolders = allProjectFiles.filter((path) => path.startsWith('node_modules/') || path.startsWith('dist/') || path.includes('/.DS_Store'));
assert(forbiddenFolders.length === 0 || exists('dist/index.html'), 'working tree has no temporary OS files; dist may exist only after build', forbiddenFolders.slice(0, 5).join(', '));

const seedData = file('src/constants/catalogSeed.ts');
const toolCount = (seedData.match(/id:\s*'tool-/g) ?? []).length;
const categoryCount = (seedData.match(/id:\s*'cat-/g) ?? []).length;
assert(toolCount >= 60, 'final AI tools library has at least 60 tools', `found ${toolCount}`);
assert(categoryCount >= 14, 'final category library has at least 14 categories', `found ${categoryCount}`);

assert(exists('dist/index.html'), 'production build output exists');
if (exists('dist/assets')) {
  const largeAssets = listFiles('dist/assets')
    .map((asset) => ({ asset, size: statSync(join(root, asset)).size }))
    .filter(({ size }) => size > 700 * 1024);
  assert(largeAssets.length === 0, 'production assets remain within final raw size threshold', largeAssets.map(({ asset, size }) => `${asset}:${size}`).join(', '));
}

console.table(checks.map(({ name, status, detail }) => ({ name, status, detail })));
if (failures.length) {
  console.error('\nPhase 13 final review failed:\n' + failures.map((item) => `- ${item}`).join('\n'));
  process.exit(1);
}
console.log(`\nPhase 13 final review passed (${checks.length} checks).`);
