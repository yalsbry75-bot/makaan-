/**
 * سكربت بذر قاعدة البيانات — AI Hub Arabia (Phase 15)
 * Firestore Seed Script — Uploads the 60 real AI tools + categories to production Firestore.
 *
 * الاستخدام (Usage):
 *   1. أنشئ Service Account في Firebase Console:
 *      Project Settings → Service accounts → Generate new private key
 *      وحمِّل الملف باسم `serviceAccountKey.json` في جذر المشروع.
 *      (هذا الملف مُستثنى بالفعل في .gitignore — لا ترفعه لأي مستودع عام)
 *
 *   2. شغّل السكربت:
 *      npm run seed:firestore
 *
 *   يمكنك أيضًا تمرير مسار مخصص لملف الاعتماد:
 *      GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json npm run seed:firestore
 *
 * ما يفعله السكربت:
 *   - يرفع 14 تصنيفًا (categories) إلى Firestore.
 *   - يرفع 60 أداة AI حقيقية (tools) إلى Firestore.
 *   - يحسب toolsCount الصحيح لكل تصنيف تلقائيًا بدلاً من القيمة الثابتة 0.
 *   - يستخدم batched writes (حد 400 لكل دفعة) لتفادي حدود Firestore.
 *   - العملية idempotent: تشغيله عدة مرات يُحدِّث نفس السجلات (نفس id) دون تكرار.
 */

import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { initializeApp, cert, type ServiceAccount } from 'firebase-admin/app';
import { getFirestore, type Firestore } from 'firebase-admin/firestore';
import { categories, tools } from '../src/constants/catalogSeed';

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(__dirname, '..');

function loadServiceAccount(): ServiceAccount {
  const envPath = process.env.GOOGLE_APPLICATION_CREDENTIALS;
  const defaultPath = resolve(projectRoot, 'serviceAccountKey.json');
  const keyPath = envPath && existsSync(envPath) ? envPath : defaultPath;

  if (!existsSync(keyPath)) {
    console.error(
      '❌ لم يتم العثور على ملف اعتماد Firebase Admin.\n' +
        `   المسار المتوقع: ${defaultPath}\n\n` +
        '   الخطوات:\n' +
        '   1. افتح Firebase Console → Project Settings → Service accounts\n' +
        '   2. اضغط "Generate new private key"\n' +
        '   3. احفظ الملف باسم serviceAccountKey.json في جذر المشروع\n' +
        '   4. أعد تشغيل: npm run seed:firestore\n',
    );
    process.exit(1);
  }

  return JSON.parse(readFileSync(keyPath, 'utf-8')) as ServiceAccount;
}

function chunk<T>(items: T[], size: number): T[][] {
  const result: T[][] = [];
  for (let i = 0; i < items.length; i += size) result.push(items.slice(i, i + size));
  return result;
}

async function seedCollection(
  db: Firestore,
  collectionName: string,
  records: Array<Record<string, unknown> & { id: string }>,
  labelAr: string,
): Promise<void> {
  const nowIso = new Date().toISOString();
  const batches = chunk(records, 400);

  console.log(`\n📦 رفع ${labelAr} (${records.length} سجل) إلى Firestore...`);

  for (const [batchIndex, batchRecords] of batches.entries()) {
    const batch = db.batch();
    for (const record of batchRecords) {
      const ref = db.collection(collectionName).doc(record.id);
      batch.set(
        ref,
        {
          ...record,
          createdAt: (record as { createdAt?: string }).createdAt ?? nowIso,
          updatedAt: nowIso,
        },
        { merge: true },
      );
    }
    await batch.commit();
    console.log(`   ✅ دفعة ${batchIndex + 1}/${batches.length} (${batchRecords.length} سجل)`);
  }
}

async function main(): Promise<void> {
  console.log('══════════════════════════════════════════════════════════');
  console.log('  🌱 AI Hub Arabia — Firestore Seed Script (Phase 15)');
  console.log('══════════════════════════════════════════════════════════');

  const serviceAccount = loadServiceAccount();
  const projectId =
    serviceAccount.projectId ?? (serviceAccount as unknown as { project_id?: string }).project_id;

  initializeApp({ credential: cert(serviceAccount) });
  const db = getFirestore();
  db.settings({ ignoreUndefinedProperties: true });

  console.log(`\n🔗 متصل بمشروع Firebase: ${projectId}`);

  // حساب toolsCount الحقيقي لكل تصنيف بناءً على عدد الأدوات الفعلي
  const countsBySlug = new Map<string, number>();
  for (const tool of tools) {
    countsBySlug.set(tool.categorySlug, (countsBySlug.get(tool.categorySlug) ?? 0) + 1);
  }
  const categoriesWithRealCounts = categories.map((category) => ({
    ...category,
    toolsCount: countsBySlug.get(category.slug) ?? 0,
  }));

  await seedCollection(db, 'categories', categoriesWithRealCounts, 'التصنيفات');
  await seedCollection(db, 'tools', tools, 'الأدوات');

  console.log('\n══════════════════════════════════════════════════════════');
  console.log(`  🎉 تم رفع ${categoriesWithRealCounts.length} تصنيفًا و ${tools.length} أداة بنجاح!`);
  console.log('  تحقق من Firebase Console → Firestore Database للتأكد.');
  console.log('══════════════════════════════════════════════════════════\n');

  process.exit(0);
}

main().catch((error) => {
  console.error('\n❌ فشل السكربت:', error);
  process.exit(1);
});
