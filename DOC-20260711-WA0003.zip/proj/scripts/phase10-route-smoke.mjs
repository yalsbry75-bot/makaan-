import { spawn } from 'node:child_process';
import http from 'node:http';

const host = '127.0.0.1';
const port = 4174;
const baseUrl = `http://${host}:${port}`;
const routes = [
  '/',
  '/tools',
  '/tools/chatgpt',
  '/categories',
  '/compare',
  '/search',
  '/search/results?q=chatgpt',
  '/login',
  '/register',
  '/forgot-password',
  '/profile',
  '/favorites',
  '/my-comparisons',
  '/my-reviews',
  '/dashboard',
  '/admin',
  '/admin/system',
  '/about',
  '/contact',
  '/privacy',
  '/terms',
  '/missing-page',
];

function waitForServer(timeoutMs = 20_000) {
  const startedAt = Date.now();
  return new Promise((resolve, reject) => {
    const tick = () => {
      const request = http.get(baseUrl, (response) => {
        response.resume();
        resolve();
      });
      request.on('error', () => {
        if (Date.now() - startedAt > timeoutMs) reject(new Error('Preview server did not start in time.'));
        else setTimeout(tick, 250);
      });
    };
    tick();
  });
}

async function readUrl(url) {
  const response = await fetch(url);
  const body = await response.text();
  return { status: response.status, body };
}

const preview = spawn('npm', ['run', 'preview', '--', '--host', host, '--port', String(port), '--strictPort'], {
  stdio: ['ignore', 'pipe', 'pipe'],
  detached: true,
});

try {
  await waitForServer();
  const results = [];
  for (const route of routes) {
    const { status, body } = await readUrl(`${baseUrl}${route}`);
    const pass = status === 200 && body.includes('<div id="root"></div>') && body.includes('AI Hub Arabia');
    results.push({ route, status: pass ? 'PASS' : 'FAIL', httpStatus: status });
    if (!pass) {
      console.table(results);
      throw new Error(`Route smoke check failed for ${route}`);
    }
  }
  console.table(results);
  console.log(`Route smoke test passed (${routes.length} routes).`);
} finally {
  try {
    process.kill(-preview.pid, 'SIGTERM');
  } catch {
    preview.kill('SIGTERM');
  }
}
process.exit(0);
