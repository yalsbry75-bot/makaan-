#!/usr/bin/env node
/**
 * Phase 15 Final Check — AI Hub Arabia
 * الفحص النهائي الشامل — المرحلة الخامسة عشرة
 *
 * يتحقق من جاهزية المشروع الكاملة للإطلاق النهائي.
 */

import { readFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(__dirname, '..');

let passed = 0;
let failed = 0;
const issues = [];

function check(label, condition, hint = '') {
  if (condition) {
    console.log(`  ✅ ${label}`);
    passed++;
  } else {
    console.log(`  ❌ ${label}${hint ? `\n     → ${hint}` : ''}`);
    issues.push({ label, hint });
    failed++;
  }
}

function fileExists(rel) {
  return existsSync(resolve(ROOT, rel));
}

function fileContains(rel, ...patterns) {
  if (!fileExists(rel)) return false;
  const content = readFileSync(resolve(ROOT, rel), 'utf8');
  return patterns.every((p) => content.includes(p));
}

function fileNotContains(rel, ...patterns) {
  if (!fileExists(rel)) return true;
  const content = readFileSync(resolve(ROOT, rel), 'utf8');
  return patterns.every((p) => !content.includes(p));
}

function readJson(rel) {
  try {
    return JSON.parse(readFileSync(resolve(ROOT, rel), 'utf8'));
  } catch {
    return null;
  }
}

console.log('\n══════════════════════════════════════════════════════════════════');
console.log('  AI Hub Arabia — Phase 15 Final Production Check');
console.log('  الفحص النهائي الشامل للإطلاق — المرحلة الخامسة عشرة');
console.log('══════════════════════════════════════════════════════════════════\n');

// ── 1. بنية المشروع ──────────────────────────────────────────────────────────
console.log('📁 بنية المشروع (Project Structure):');
check('package.json موجود', fileExists('package.json'));
check('vite.config.ts موجود', fileExists('vite.config.ts'));
check('tsconfig.app.json موجود', fileExists('tsconfig.app.json'));
check('index.html موجود', fileExists('index.html'));
check('tailwind.config.ts موجود', fileExists('tailwind.config.ts'));
check('postcss.config.js موجود', fileExists('postcss.config.js'));
check('src/main.tsx موجود', fileExists('src/main.tsx'));
check('src/App.tsx موجود', fileExists('src/App.tsx'));

// ── 2. الصفحات الأساسية ──────────────────────────────────────────────────────
console.log('\n📄 الصفحات الأساسية (Core Pages):');
const pages = [
  'src/pages/HomePage.tsx',
  'src/pages/ToolsPage.tsx',
  'src/pages/ToolDetailsPage.tsx',
  'src/pages/CategoriesPage.tsx',
  'src/pages/ComparePage.tsx',
  'src/pages/SearchPage.tsx',
  'src/pages/SearchResultsPage.tsx',
  'src/pages/AboutPage.tsx',
  'src/pages/ContactPage.tsx',
  'src/pages/NotFoundPage.tsx',
];
pages.forEach((p) => check(`${p.split('/').pop()} موجود`, fileExists(p)));

// ── 3. صفحات الحساب ──────────────────────────────────────────────────────────
console.log('\n👤 صفحات الحساب (Account Pages):');
const accountPages = [
  'src/pages/LoginPage.tsx',
  'src/pages/RegisterPage.tsx',
  'src/pages/ForgotPasswordPage.tsx',
  'src/pages/ProfilePage.tsx',
  'src/pages/FavoritesPage.tsx',
  'src/pages/UserDashboardPage.tsx',
  'src/pages/UserComparisonsPage.tsx',
  'src/pages/UserReviewsPage.tsx',
];
accountPages.forEach((p) => check(`${p.split('/').pop()} موجود`, fileExists(p)));

// ── 4. صفحات الإدارة ──────────────────────────────────────────────────────────
console.log('\n🔧 صفحات الإدارة (Admin Pages):');
const adminPages = [
  'src/pages/AdminDashboardPage.tsx',
  'src/pages/AdminToolsPage.tsx',
  'src/pages/AdminUsersPage.tsx',
  'src/pages/AdminReviewsPage.tsx',
  'src/pages/AdminMessagesPage.tsx',
  'src/pages/AdminStatsPage.tsx',
  'src/pages/AdminSettingsPage.tsx',
  'src/pages/AdminSystemPage.tsx',
];
adminPages.forEach((p) => check(`${p.split('/').pop()} موجود`, fileExists(p)));

// ── 5. الصفحات القانونية ─────────────────────────────────────────────────────
console.log('\n⚖️ الصفحات القانونية (Legal Pages):');
check('PrivacyPage.tsx موجود', fileExists('src/pages/PrivacyPage.tsx'));
check('PrivacyPage.tsx يحتوي على محتوى حقيقي', fileContains('src/pages/PrivacyPage.tsx', 'Section', 'ArabicContent', 'EnglishContent'));
check('TermsPage.tsx موجود', fileExists('src/pages/TermsPage.tsx'));
check('TermsPage.tsx يحتوي على محتوى حقيقي', fileContains('src/pages/TermsPage.tsx', 'Section', 'ArabicContent', 'EnglishContent'));

// ── 6. التوجيه والمسارات ──────────────────────────────────────────────────────
console.log('\n🗺️ التوجيه (Routing):');
check('AppRoutes.tsx موجود', fileExists('src/routes/AppRoutes.tsx'));
check('مسار catch-all لـ 404 موجود', fileContains('src/routes/AppRoutes.tsx', 'path="*"', 'NotFoundPage'));
check('جميع المسارات تستخدم lazy loading', fileContains('src/routes/AppRoutes.tsx', 'lazy(', 'Suspense'));
check('مسارات Admin محمية', fileContains('src/routes/AppRoutes.tsx', 'admin', 'ProtectedRoute'));
check('مسارات Profile/Dashboard محمية', fileContains('src/routes/AppRoutes.tsx', 'dashboard', 'profile', 'ProtectedRoute'));

// ── 7. المصادقة ──────────────────────────────────────────────────────────────
console.log('\n🔐 المصادقة (Authentication):');
check('AuthContext.tsx موجود', fileExists('src/contexts/AuthContext.tsx'));
check('AuthContext يدعم Firebase onAuthStateChanged', fileContains('src/contexts/AuthContext.tsx', 'firebaseOnAuthStateChanged', 'isMounted'));
check('authService.ts يدعم Firebase', fileContains('src/services/authService.ts', 'isFirebaseConfigured', 'firebaseSignIn'));
check('ProtectedRoute موجود', fileExists('src/components/auth/ProtectedRoute.tsx'));

// ── 8. Firebase ───────────────────────────────────────────────────────────────
console.log('\n🔥 Firebase:');
check('src/firebase/config.ts', fileExists('src/firebase/config.ts'));
check('src/firebase/auth.ts', fileExists('src/firebase/auth.ts'));
check('src/firebase/db.ts', fileExists('src/firebase/db.ts'));
check('src/firebase/storage.ts', fileExists('src/firebase/storage.ts'));
check('firebase في dependencies', fileContains('package.json', '"firebase"'));
check('firestore.rules مُعرَّفة', fileExists('firestore.rules'));
check('storage.rules مُعرَّفة', fileExists('storage.rules'));
check('firebase.json مُعرَّف', fileExists('firebase.json'));
check('firestore.indexes.json موجود', fileExists('firestore.indexes.json'));

// ── 9. قاعدة البيانات (localStorage adapter) ─────────────────────────────────
console.log('\n💾 قاعدة البيانات (Database):');
check('databaseService.ts موجود', fileExists('src/services/databaseService.ts'));
check('databaseService يدعم Firestore', fileContains('src/services/databaseService.ts', 'isFirebaseConfigured'));
check('repositories/userRepository.ts موجود', fileExists('src/services/repositories/userRepository.ts'));

// ── 10. SEO والـ PWA ──────────────────────────────────────────────────────────
console.log('\n🌐 SEO والـ PWA:');
check('index.html يحتوي على meta description', fileContains('index.html', 'name="description"'));
check('index.html يحتوي على og:title', fileContains('index.html', 'property="og:title"'));
check('index.html يحتوي على twitter:card', fileContains('index.html', 'name="twitter:card"'));
check('index.html يحتوي على JSON-LD', fileContains('index.html', 'application/ld+json'));
check('index.html يحتوي على canonical', fileContains('index.html', 'rel="canonical"'));
check('public/sitemap.xml موجود', fileExists('public/sitemap.xml'));
check('public/robots.txt موجود', fileExists('public/robots.txt'));
check('robots.txt يمنع الوصول للإدارة', fileContains('public/robots.txt', 'Disallow: /admin'));
check('public/manifest.webmanifest موجود', fileExists('public/manifest.webmanifest'));
check('public/sw.js موجود', fileExists('public/sw.js'));
check('public/offline.html موجود', fileExists('public/offline.html'));

// ── 11. متغيرات البيئة ────────────────────────────────────────────────────────
console.log('\n🔑 متغيرات البيئة (Environment):');
check('.env.example موجود', fileExists('.env.example'));
check('.env.example يحتوي على VITE_FIREBASE_API_KEY', fileContains('.env.example', 'VITE_FIREBASE_API_KEY'));
check('.env.example يحتوي على VITE_USE_FIREBASE', fileContains('.env.example', 'VITE_USE_FIREBASE'));
check('.env غير مُضمَّن في المستودع', fileContains('.gitignore', '.env'));
check('vite-env.d.ts يُعرِّف أنواع البيئة', fileContains('src/vite-env.d.ts', 'VITE_FIREBASE_API_KEY'));

// ── 12. أمان الإنتاج ──────────────────────────────────────────────────────────
console.log('\n🛡️ أمان الإنتاج (Production Security):');
check('vite.config.ts يحتوي على CSP', fileContains('vite.config.ts', 'Content-Security-Policy'));
check('vite.config.ts يحتوي على X-Frame-Options', fileContains('vite.config.ts', 'X-Frame-Options'));
check('vite.config.ts يحتوي على CSP لـ Firebase', fileContains('vite.config.ts', 'googleapis.com'));
check('vite.config.ts يُنشئ Firebase chunk', fileContains('vite.config.ts', "'firebase'"));

// ── 13. الجودة والتوثيق ───────────────────────────────────────────────────────
console.log('\n📚 الجودة والتوثيق (Quality & Docs):');
check('README.md موجود', fileExists('README.md'));
check('INSTALL.md موجود', fileExists('INSTALL.md'));
check('DEPLOYMENT.md موجود', fileExists('DEPLOYMENT.md'));
check('CHANGELOG.md موجود', fileExists('CHANGELOG.md'));
check('PROJECT_STRUCTURE.md موجود', fileExists('PROJECT_STRUCTURE.md'));
check('PHASE_15_FINAL_REPORT.md موجود', fileExists('PHASE_15_FINAL_REPORT.md'));

// ── 14. سكربتات الجودة ───────────────────────────────────────────────────────
console.log('\n🧪 سكربتات الجودة (Quality Scripts):');
const scripts = [
  'scripts/phase10-quality-check.mjs',
  'scripts/phase11-completion-check.mjs',
  'scripts/phase12-production-readiness.mjs',
  'scripts/phase13-final-review.mjs',
  'scripts/phase14-production-check.mjs',
  'scripts/phase15-final-check.mjs',
];
scripts.forEach((s) => check(`${s.split('/').pop()} موجود`, fileExists(s)));

// ── التحقق من package.json ────────────────────────────────────────────────────
console.log('\n📦 package.json Validation:');
const pkg = readJson('package.json');
if (pkg) {
  check('firebase في dependencies', Boolean(pkg.dependencies?.firebase));
  check('react 18+ في dependencies', Boolean(pkg.dependencies?.react?.startsWith('18')));
  check('vite في devDependencies', Boolean(pkg.devDependencies?.vite));
  check('typescript في devDependencies', Boolean(pkg.devDependencies?.typescript));
  check('سكربت build مُعرَّف', Boolean(pkg.scripts?.build));
  check('سكربت dev مُعرَّف', Boolean(pkg.scripts?.dev));
  check('سكربت test:phase15 مُعرَّف', Boolean(pkg.scripts?.['test:phase15']));
} else {
  check('package.json صالح للقراءة', false, 'ملف JSON تالف');
}

// ── الملخص النهائي ────────────────────────────────────────────────────────────
const total = passed + failed;
const percent = Math.round((passed / total) * 100);

console.log('\n══════════════════════════════════════════════════════════════════');
console.log(`  النتيجة النهائية: ${passed}/${total} (${percent}%)`);

if (failed === 0) {
  console.log('  🎉 المشروع اجتاز جميع الفحوصات النهائية!');
  console.log('  ✅ AI Hub Arabia جاهز للإطلاق الرسمي.');
} else {
  console.log(`\n  ⚠️  بنود تحتاج مراجعة (${failed}):`);
  issues.forEach(({ label, hint }) => {
    console.log(`  • ${label}`);
    if (hint) console.log(`    → ${hint}`);
  });
}

console.log('══════════════════════════════════════════════════════════════════\n');
process.exit(failed > 0 ? 1 : 0);
