import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const failures = [];
const checks = [];

function file(path) {
  return readFileSync(join(root, path), 'utf8');
}

function exists(path) {
  return existsSync(join(root, path));
}

function listFiles(dir) {
  const absoluteDir = join(root, dir);
  const output = [];
  for (const item of readdirSync(absoluteDir)) {
    const absolute = join(absoluteDir, item);
    const relative = join(dir, item);
    if (statSync(absolute).isDirectory()) output.push(...listFiles(relative));
    else output.push(relative);
  }
  return output;
}

function assert(condition, name, detail = 'Requirement was not met') {
  checks.push({ name, status: condition ? 'PASS' : 'FAIL', detail: condition ? '' : detail });
  if (!condition) failures.push(`${name}: ${detail}`);
}

const requiredPhase11Files = [
  'src/pages/AdminSystemPage.tsx',
  'src/pages/UserComparisonsPage.tsx',
  'src/pages/UserReviewsPage.tsx',
  'src/services/systemHealthService.ts',
  'src/services/userWorkspaceService.ts',
];
for (const path of requiredPhase11Files) assert(exists(path), `phase 11 file exists: ${path}`);

const routes = file('src/routes/AppRoutes.tsx');
for (const route of ['my-comparisons', 'my-reviews', 'system']) {
  assert(routes.includes(`path="${route}"`), `phase 11 route registered: ${route}`);
}
assert(routes.includes("roles={['admin']}"), 'admin routes remain role-protected');

const siteConfig = file('src/config/site.ts');
for (const href of ['/my-comparisons', '/my-reviews']) {
  assert(siteConfig.includes(`href: '${href}'`), `dashboard navigation includes ${href}`);
}

const adminLayout = file('src/layouts/AdminLayout.tsx');
assert(adminLayout.includes("href: '/admin/system'"), 'admin system health navigation is present');

const dashboardLayout = file('src/layouts/DashboardLayout.tsx');
assert(dashboardLayout.includes('Mobile dashboard navigation') && dashboardLayout.includes('overflow-x-auto'), 'mobile dashboard navigation is present');

const comparePage = file('src/pages/ComparePage.tsx');
assert(comparePage.includes('searchParams.getAll') && comparePage.includes('queryToolSlugs'), 'comparison page supports multiple tool query params');

const systemService = file('src/services/systemHealthService.ts');
for (const token of ['Security audit log', 'Content readiness', 'Moderation queue', 'SEO and PWA', 'Data integrity']) {
  assert(systemService.includes(token), `system health check includes ${token}`);
}

const workspaceService = file('src/services/userWorkspaceService.ts');
for (const token of ['getUserReviewsWithTools', 'getUserComparisonsWithTools', 'renameUserComparison', 'deleteUserComparison']) {
  assert(workspaceService.includes(token), `user workspace service includes ${token}`);
}

const database = file('src/services/databaseService.ts');
assert(database.includes('ai-hub-arabia-database-v11') && (database.includes("DATABASE_VERSION = '11.0.0'") || database.includes("DATABASE_VERSION = '12.0.0'") || database.includes("DATABASE_VERSION = '13.0.0'")), 'database adapter preserves phase 11 migration while supporting later versions');

const packageJson = JSON.parse(file('package.json'));
assert(packageJson.version === '0.11.0' || packageJson.version === '1.0.0' || packageJson.version === '1.0.1', 'package version is phase 11 or later production version');
assert(Boolean(packageJson.scripts['test:phase11']), 'phase 11 test script is registered');

const sourceFiles = listFiles('src').filter((path) => /\.(ts|tsx|css)$/.test(path));
const forbiddenPattern = /TODO|FIXME|console\.log|debugger/i;
const offenders = sourceFiles.filter((path) => forbiddenPattern.test(file(path)));
assert(offenders.length === 0, 'no TODO/FIXME/console.log/debugger in source', offenders.join(', '));

const pageFiles = listFiles('src/pages').filter((path) => path.endsWith('Page.tsx'));
assert(pageFiles.length >= 29, 'platform has expanded page coverage for launch readiness', `found ${pageFiles.length}`);

console.table(checks.map(({ name, status, detail }) => ({ name, status, detail })));
if (failures.length) {
  console.error('\nPhase 11 completion check failed:\n' + failures.map((item) => `- ${item}`).join('\n'));
  process.exit(1);
}
console.log(`\nPhase 11 completion check passed (${checks.length} checks).`);
