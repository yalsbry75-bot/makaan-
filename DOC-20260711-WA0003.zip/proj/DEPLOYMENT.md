# DEPLOYMENT — AI Hub Arabia
## Phase 14: Firebase Production Integration

---

## طريقة النشر الموصى بها: Firebase Hosting

### 1. إعداد بيئة الإنتاج

```bash
# نسخ ملف البيئة
cp .env.example .env

# تعبئة البيانات من Firebase Console → Project Settings
nano .env

# مثال على ملف .env المكتمل:
# VITE_USE_FIREBASE=true
# VITE_FIREBASE_API_KEY=AIzaSy...
# VITE_FIREBASE_AUTH_DOMAIN=my-project.firebaseapp.com
# VITE_FIREBASE_PROJECT_ID=my-project
# VITE_FIREBASE_STORAGE_BUCKET=my-project.appspot.com
# VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
# VITE_FIREBASE_APP_ID=1:123456789:web:abc123
```

### 2. تثبيت التبعيات والبناء

```bash
npm ci
npm run typecheck
npm run build
```

### 3. إعداد Firebase CLI

```bash
npm install -g firebase-tools
firebase login
```

### 4. تحديث `.firebaserc`

```json
{
  "projects": {
    "default": "YOUR_FIREBASE_PROJECT_ID"
  }
}
```

### 5. رفع قواعد الأمان والفهارس

```bash
# رفع Firestore Rules + Indexes + Storage Rules
firebase deploy --only firestore:rules,firestore:indexes,storage

# أو رفع الكل دفعة واحدة
firebase deploy
```

### 6. التحقق قبل النشر

```bash
npm run test:phase14
npm audit --omit=dev
```

---

## طرق النشر البديلة (Static Hosting)

إذا لم تستخدم Firebase Hosting، ارفع مجلد `dist/` إلى أي استضافة ثابتة:

### Vercel
- رفع المشروع من GitHub → Vercel يكشف Vite تلقائيًا
- أضف متغيرات `VITE_FIREBASE_*` في Vercel Dashboard → Settings → Environment Variables

### Netlify
- ارفع مجلد `dist/` أو اربط GitHub
- أضف ملف `_redirects`:
  ```
  /* /index.html 200
  ```
- أضف متغيرات البيئة في Netlify → Site settings → Environment variables

### Cloudflare Pages
- ربط GitHub → Build command: `npm run build` → Build output: `dist`
- أضف متغيرات البيئة في Settings → Environment variables

### Nginx
```nginx
location / {
    root /var/www/ai-hub-arabia/dist;
    try_files $uri /index.html;
}
```

---

## Security Headers (موصى بها على مستوى الاستضافة)

```
X-Content-Type-Options: nosniff
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob: https:; connect-src 'self' https://*.googleapis.com https://*.firebaseio.com wss://*.firebaseio.com https://securetoken.googleapis.com https://identitytoolkit.googleapis.com; frame-src 'none';
```

> ملاحظة: هذه الـ Headers مُضمَّنة في `firebase.json` عند استخدام Firebase Hosting.

---

## Firebase Services Checklist

قبل النشر، تأكد من تفعيل هذه الخدمات في Firebase Console:

- [ ] **Authentication** → Email/Password مُفعَّل
- [ ] **Firestore Database** → Created (Production mode)
- [ ] **Storage** → Enabled
- [ ] **قواعد Firestore** مرفوعة (`firestore deploy --only firestore:rules`)
- [ ] **قواعد Storage** مرفوعة (`firebase deploy --only storage`)
- [ ] **Firestore Indexes** مرفوعة (`firebase deploy --only firestore:indexes`)

---

## PWA Notes

- `public/manifest.webmanifest` — تعريف تطبيق PWA
- `public/sw.js` — Service Worker مع offline shell
- `public/offline.html` — صفحة الخطأ offline

---

## SEO Notes

- `index.html` يحتوي على meta tags، Open Graph، Twitter Cards، وStructured Data
- `public/sitemap.xml` و `public/robots.txt` مُضمَّنان
- **حدِّث** `siteUrl` في `sitemap.xml` و `robots.txt` و `index.html` بعد معرفة النطاق النهائي

---

## Final Verification Before Release

```bash
# فحص شامل
npm run test:all

# مراجعة أمان التبعيات
npm audit --omit=dev

# اختبار يدوي في المتصفح:
# ✓ التنقل العام
# ✓ تسجيل الدخول / الإنشاء / الخروج (Firebase Auth)
# ✓ لوحة المستخدم والمفضلة
# ✓ لوحة الإدارة
# ✓ البحث والفلاتر والمقارنة والمراجعات
# ✓ الاستجابة على الجوال والتابلت والمكتب
# ✓ تثبيت PWA وصفحة offline
```
