# INSTALL — AI Hub Arabia

## Requirements

- Node.js 20 or newer
- npm 10 or newer
- Modern browser for local preview

## Install Dependencies

```bash
npm install
```

For a deterministic CI install, use:

```bash
npm ci
```

## Run Development Server

```bash
npm run dev
```

Default development URL:

```text
http://localhost:5173
```

## Production Build

```bash
npm run build
```

Generated output:

```text
dist/
```

## Preview Production Build

```bash
npm run preview
```

Default preview URL:

```text
http://localhost:4173
```

## Final Validation Commands

```bash
npm run typecheck
npm run build
npm run test:phase10
npm run test:phase11
npm run test:phase12
npm run test:phase13
npm run test:routes
npm audit --omit=dev
```

## Demo Accounts

```text
Admin:
admin@aihubarabia.com / Admin@12345

User:
user@aihubarabia.com / User@12345
```

## Local Data Reset

The project uses a local browser storage adapter. To reset demo data, clear site data/localStorage in the browser, then reload the app. The database will reseed automatically.

## External Services Not Included

This final ZIP does not include Firebase, Supabase, analytics, email, payment, or hosting credentials. Add those only through secure environment variables and provider dashboards during real deployment.
